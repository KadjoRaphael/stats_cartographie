<?xml version="1.0" encoding="utf-8" ?>
<ogr:FeatureCollection
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
     xsi:schemaLocation="http://ogr.maptools.org/ world.xsd"
     xmlns:ogr="http://ogr.maptools.org/"
     xmlns:gml="http://www.opengis.net/gml">
  <gml:boundedBy>
    <gml:Box>
      <gml:coord><gml:X>-179.958548764</gml:X><gml:Y>-55.997252745</gml:Y></gml:coord>
      <gml:coord><gml:X>179.9958605798</gml:X><gml:Y>83.61347077000001</gml:Y></gml:coord>
    </gml:Box>
  </gml:boundedBy>
                                                                                                          
  <gml:featureMember>
    <ogr:world fid="world.0">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>11.322078491,2.165760396 11.336341187,0.999164937 9.8043711812,0.9983539399 9.3466903,1.181708075 9.7995711595,2.341742255 11.322078491,2.165760396</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>8.716263572,3.8005714793 9.0540947754,3.730741899 8.6959638551,3.1151094157 8.2340380942,3.3118323379 8.716263572,3.8005714793</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GQ</ogr:ISO2>
      <ogr:ISO3>GNQ</ogr:ISO3>
      <ogr:ISONUM>226</ogr:ISONUM>
      <ogr:NAMEen>Equatorial Guinea</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.1">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>179.0838195273,-8.3563170615 179.1691805941,-8.2617439936 179.3104495364,-8.4408104337 179.3306840882,-8.6477270928 179.2130708087,-8.646872982 179.0838195273,-8.3563170615</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>179.1780959084,-7.9959168913 178.9887678387,-8.1843378625 178.8209218136,-8.0140406535 179.0235435121,-7.7935851716 179.1780959084,-7.9959168913</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TV</ogr:ISO2>
      <ogr:ISO3>TUV</ogr:ISO3>
      <ogr:ISONUM>798</ogr:ISONUM>
      <ogr:NAMEen>Tuvalu</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.2">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>73.7071080231,4.2257058893 73.6958421474,4.1246443555 73.5915375146,4.048564614 73.4060566471,4.0513634912 73.3071616111,4.1331953919 73.3256411766,4.245199387 73.4553617467,4.3245631485 73.6090490593,4.3205949097 73.7071080231,4.2257058893</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>73.411064328,5.1886020614 73.5911101793,5.2409183546 73.7877062354,5.1644569623 73.8005501999,5.0135625307 73.6532236937,4.8799965744 73.4344273044,4.9041353175 73.3562955002,5.0489788987 73.411064328,5.1886020614</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>73.3720334941,3.5254680386 73.6027862706,3.5410412615 73.7180696098,3.4445902601 73.7643965528,3.2999247321 73.6774451452,3.2155423951 73.4739831569,3.1914339324 73.32398382,3.2637603518 73.2933922534,3.3722558772 73.3720334941,3.5254680386</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MV</ogr:ISO2>
      <ogr:ISO3>MDV</ogr:ISO3>
      <ogr:ISONUM>462</ogr:ISONUM>
      <ogr:NAMEen>Maldives</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.3">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>1.7203321516,42.4696252858 1.4489628094,42.3671623299 1.2877274765,42.5447354959 1.5608597184,42.6567593274 1.7203321516,42.4696252858</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AD</ogr:ISO2>
      <ogr:ISO3>AND</ogr:ISO3>
      <ogr:ISONUM>20</ogr:ISONUM>
      <ogr:NAMEen>Andorra</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.4">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-61.773019986,17.126532294 -61.672189908,17.057562567 -61.7082196496,16.9872843463 -61.851714648,17.007635809 -61.8810143982,17.0932510638 -61.773019986,17.126532294</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AG</ogr:ISO2>
      <ogr:ISO3>ATG</ogr:ISO3>
      <ogr:ISONUM>28</ogr:ISONUM>
      <ogr:NAMEen>Antigua and Barbuda</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.5">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>16.945042766,48.604166158 17.14833785,48.005443014 16.094035278,46.862773743 14.540331665,46.378643087 13.6943058283,46.519745586 12.111177612,46.992998352 10.453811076,46.864427389 10.0420878003,47.0620797231 9.6984700199,47.0581958757 9.5086072213,47.3038948207 9.5394414547,47.441565977 9.5545057867,47.5101991364 9.7139058634,47.544405597 11.258826538,47.400725403 12.176599976,47.705823059 12.9635225181,47.4904161682 13.0983360746,47.6693476239 12.9379600764,48.0994331201 13.815724731,48.766430156 14.69567102,48.589541728 14.982061808,49.007914124 16.945042766,48.604166158</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AT</ogr:ISO2>
      <ogr:ISO3>AUT</ogr:ISO3>
      <ogr:ISONUM>40</ogr:ISONUM>
      <ogr:NAMEen>Austria</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.6">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>5.994910116,50.749926656 6.117486613,50.120456035 5.790684855,49.537752585 4.139622843,49.97452179 2.5217999277,51.0875408835 3.37610269,51.4675394824 3.7902017123,51.452446665 3.9028219865,51.4498969326 5.012127727,51.474326884 5.994910116,50.749926656</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BE</ogr:ISO2>
      <ogr:ISO3>BEL</ogr:ISO3>
      <ogr:ISONUM>56</ogr:ISONUM>
      <ogr:NAMEen>Belgium</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.7">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>50.4157260151,26.5987895465 50.965465382,26.6263870288 50.7380839952,25.9153093664 50.3745202016,26.0348205275 50.4157260151,26.5987895465</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BH</ogr:ISO2>
      <ogr:ISO3>BHR</ogr:ISO3>
      <ogr:ISONUM>48</ogr:ISONUM>
      <ogr:NAMEen>Bahrain</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.8">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-78.1486516232,25.2566411579 -77.7512350653,24.8909211918 -77.5716100935,24.5341297627 -77.2886852325,24.1741208273 -77.3093210608,23.9956434804 -77.7281281543,23.9958446033 -77.9200278006,24.3790932888 -78.2204458619,24.589514818 -78.4960090135,24.7821763782 -78.2759704562,24.9861697787 -78.3905704186,25.2544009626 -78.1486516232,25.2566411579</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-77.252622429,25.1318411946 -77.0129133953,25.2075614292 -76.6628548564,25.1583881283 -76.6387718225,25.0046634781 -77.0618383243,24.986554985 -77.252622429,25.1318411946</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BS</ogr:ISO2>
      <ogr:ISO3>BHS</ogr:ISO3>
      <ogr:ISONUM>44</ogr:ISONUM>
      <ogr:NAMEen>Bahamas</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.9">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-59.5314659745,13.0605164326 -59.6841793753,13.1797395072 -59.6715791819,13.3100980319 -59.5554311936,13.2743348943 -59.4822268251,13.1787747392 -59.4096088843,13.1563877512 -59.2778915046,13.1675049793 -59.3610101398,13.0719158841 -59.5314659745,13.0605164326</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BB</ogr:ISO2>
      <ogr:ISO3>BRB</ogr:ISO3>
      <ogr:ISONUM>52</ogr:ISONUM>
      <ogr:NAMEen>Barbados</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.10">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>9.5545057867,47.5101991364 9.5394414547,47.441565977 9.5086072213,47.3038948207 9.4440495812,47.0423307452 9.6984700199,47.0581958757 10.0420878003,47.0620797231 10.453811076,46.864427389 9.437852417,46.492047018 8.900004109,45.826402893 8.07307784,46.253611959 7.02208256,45.925259909 6.7872818778,46.4122156441 6.2240956714,46.2947009103 6.131852661,46.595606588 7.586028488,47.584618544 9.184506306,47.670424704 9.5545057867,47.5101991364</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CH</ogr:ISO2>
      <ogr:ISO3>CHE</ogr:ISO3>
      <ogr:ISONUM>756</ogr:ISONUM>
      <ogr:NAMEen>Switzerland</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.11">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>43.8656231314,-12.1977641095 43.4525328031,-12.0590408654 43.262868686,-11.818047784 43.2230195978,-11.351919314 43.5217316047,-11.324269202 43.8706158961,-11.9016345424 43.8656231314,-12.1977641095</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>KM</ogr:ISO2>
      <ogr:ISO3>COM</ogr:ISO3>
      <ogr:ISONUM>174</ogr:ISONUM>
      <ogr:NAMEen>Comoros</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.12">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-23.8964371722,15.8047217656 -23.1309663858,15.6812981018 -22.8484817802,15.306115519 -23.3300065111,14.9393678704 -24.0804637262,15.0404069874 -24.2813631511,15.4194551638 -23.8964371722,15.8047217656</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CV</ogr:ISO2>
      <ogr:ISO3>CPV</ogr:ISO3>
      <ogr:ISONUM>132</ogr:ISONUM>
      <ogr:NAMEen>Cape Verde</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.13">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>9.4375030265,54.8104111271 11.0700348269,54.0795824274 12.501963738,54.473578192 14.2620399341,54.1549113173 14.123922973,52.850651144 14.644821411,52.576921082 14.8103927,50.858447164 12.510223022,50.388760071 12.797750692,49.327842917 13.815724731,48.766430156 12.9379600764,48.0994331201 13.0983360746,47.6693476239 12.9635225181,47.4904161682 12.176599976,47.705823059 11.258826538,47.400725403 9.7139058634,47.544405597 9.5545057867,47.5101991364 9.184506306,47.670424704 7.586028488,47.584618544 8.200305216,48.958563131 6.345307071,49.455348652 6.4248140639,49.7598236407 6.117486613,50.120456035 5.994910116,50.749926656 5.928040812,51.806735535 7.026320027,52.230637309 7.194590691,53.245021877 7.226084832,53.666489976 8.565765821,53.546698309 9.007823113,53.892482815 8.6608161325,54.8963039111 9.4375030265,54.8104111271</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>DE</ogr:ISO2>
      <ogr:ISO3>DEU</ogr:ISO3>
      <ogr:ISONUM>276</ogr:ISONUM>
      <ogr:NAMEen>Germany</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.14">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-61.4475382386,15.564426858 -61.267160611,15.50779857 -61.1965095105,15.3643293179 -61.179120309,15.2372712206 -61.316684508,15.17265851 -61.4119071911,15.3020802065 -61.5463981908,15.4731177653 -61.5830272399,15.6330996391 -61.4475382386,15.564426858</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>DM</ogr:ISO2>
      <ogr:ISO3>DMA</ogr:ISO3>
      <ogr:ISONUM>212</ogr:ISONUM>
      <ogr:NAMEen>Dominica</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.15">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>11.9531588807,55.9876764718 12.3715693938,55.385210234 12.2378432215,54.9163290596 11.6856894522,54.6920797189 11.5182746286,55.023149927 11.0436839189,55.0928758009 10.6391784431,55.5725118676 11.1750292822,55.9589025985 11.9531588807,55.9876764718</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>9.4375030265,54.8104111271 8.6608161325,54.8963039111 8.122406446,56.551662502 8.8366045866,57.077971536 9.658851361,57.259875599 10.596039259,57.751166083 10.4886184808,56.8828665156 10.964121941,56.448431708 9.498057488,55.489447333 9.4375030265,54.8104111271</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>DK</ogr:ISO2>
      <ogr:ISO3>DNK</ogr:ISO3>
      <ogr:ISONUM>208</ogr:ISONUM>
      <ogr:NAMEen>Denmark</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.16">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-16.134251017,28.5994090863 -15.9983074506,28.3595267762 -16.0740257709,28.1377167349 -16.2590633912,27.9866866907 -16.6078357292,27.9698713432 -16.8740965543,28.1145620705 -16.91605809,28.354969806 -16.8250979933,28.5984608169 -16.4762863347,28.6927378259 -16.134251017,28.5994090863</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>3.2049087278,39.8811034162 3.5837858728,39.6713560432 3.12297625,39.3450017866 2.6683374338,39.6831839458 3.2049087278,39.8811034162</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-1.7940747449,43.3860153322 -0.038933472,42.685147604 1.2877274765,42.5447354959 1.4489628094,42.3671623299 1.7203321516,42.4696252858 3.1809696567,42.4314841477 3.235687696,41.965521552 2.060313347,41.274603583 0.990407748,41.039699611 -0.323353645,39.516221421 0.227712436,38.73456452 -2.126698371,36.736395575 -4.433257616,36.710679429 -5.3375052378,36.1331436976 -5.8874897447,36.0362434776 -6.499582486,36.959662177 -7.414418098,37.192816473 -7.023985149,38.022563985 -7.359210164,38.446362407 -6.942491415,41.01599884 -6.205947225,41.570280253 -6.567630575,41.92607249 -8.750803189,41.96898021 -9.291981575,42.922634182 -7.880848762,43.763251044 -7.230091926,43.568630276 -4.385568814,43.383612372 -1.7940747449,43.3860153322</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>ES</ogr:ISO2>
      <ogr:ISO3>ESP</ogr:ISO3>
      <ogr:ISONUM>724</ogr:ISONUM>
      <ogr:NAMEen>Spain</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.17">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-7.4136184021,62.1384033079 -6.5943513606,62.5697138837 -6.3573302841,62.2845982211 -6.7810694831,61.4205236687 -7.4136184021,62.1384033079</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>FO</ogr:ISO2>
      <ogr:ISO3>FRO</ogr:ISO3>
      <ogr:ISONUM>234</ogr:ISONUM>
      <ogr:NAMEen>Faeroe Islands</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.18">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>158.0626832156,6.9811867198 158.2002091787,7.1418931781 158.4830777524,7.1514821788 158.529157335,6.9794476101 158.4328636065,6.7711182331 158.1635399875,6.722854945 158.0102137789,6.8376663714 158.0626832156,6.9811867198</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>FM</ogr:ISO2>
      <ogr:ISO3>FSM</ogr:ISO3>
      <ogr:ISONUM>583</ogr:ISONUM>
      <ogr:NAMEen>Micronesia</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.19">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-2.5116463957,49.4149612993 -2.7560571432,49.425582906 -2.6573888179,49.4879485561 -2.4852277052,49.5394625335 -2.5116463957,49.4149612993</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GG</ogr:ISO2>
      <ogr:ISO3>GGY</ogr:ISO3>
      <ogr:ISONUM>831</ogr:ISONUM>
      <ogr:NAMEen>Guernsey</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.20">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-61.55917038,12.0313327462 -61.749501106,12.036322333 -61.671457486,12.236070054 -61.4869910208,12.4661015425 -61.3087427047,12.4540144174 -61.3991670798,12.1981742257 -61.55917038,12.0313327462</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GD</ogr:ISO2>
      <ogr:ISO3>GRD</ogr:ISO3>
      <ogr:ISONUM>308</ogr:ISONUM>
      <ogr:NAMEen>Grenada</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.21">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-4.6047654877,54.091050523 -4.530995246,54.366115627 -4.311919726,54.287176825 -4.4615801169,54.0027042272 -4.6047654877,54.091050523</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>IM</ogr:ISO2>
      <ogr:ISO3>IMN</ogr:ISO3>
      <ogr:ISONUM>833</ogr:ISONUM>
      <ogr:NAMEen>Isle of Man</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.22">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>15.6552396558,38.4224846781 15.6546240018,37.9916449482 15.1200772356,37.4035997858 15.3165266615,37.1685775633 15.073578321,36.659125067 12.427419467,37.809271552 12.760915561,38.180975653 14.0690498857,38.0534967361 15.6552396558,38.4224846781</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>9.1189520583,41.2439368417 9.3621724236,41.2757415416 9.826670769,40.5195987 9.557790561,39.139715887 8.853282097,38.877997137 8.371755405,39.23061758 8.4333230546,39.9464422248 8.23316491,40.91010163 9.1189520583,41.2439368417</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>13.6943058283,46.519745586 13.5331741824,46.2217184825 13.7097930591,45.9008391125 13.7051558128,45.593207098 12.410329623,45.436224677 12.368825717,44.250677802 13.616953972,43.53131745 14.075368686,42.598822333 15.123383009,41.934271552 16.027110222,41.944077867 16.021657748,41.427801825 17.2187345428,41.0583464742 18.4229102281,40.5105601531 18.2287518677,40.1374199424 17.2742811976,40.4607679669 16.7712422185,39.6432838471 17.4279990546,39.3484498289 16.5495649617,37.9377867618 16.090017123,37.94920482 16.179209832,38.748277085 15.610199415,40.073187567 13.721853061,41.252386786 13.044606967,41.227525132 11.094493035,42.402736721 10.105804884,44.016750393 8.724782748,44.423976955 7.502289259,43.792222398 6.602728312,45.103449606 7.02208256,45.925259909 8.07307784,46.253611959 8.900004109,45.826402893 9.437852417,46.492047018 10.453811076,46.864427389 12.111177612,46.992998352 13.6943058283,46.519745586</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs><gml:innerBoundaryIs><gml:LinearRing><gml:coordinates>12.3933641273,43.9120671524 12.4332877042,43.8846420415 12.4950334521,43.8944818867 12.5200114494,43.9376700816 12.5060500845,43.9799098218 12.4568522694,43.9827698536 12.4059826626,43.9536110312 12.3933641273,43.9120671524</gml:coordinates></gml:LinearRing></gml:innerBoundaryIs><gml:innerBoundaryIs><gml:LinearRing><gml:coordinates>12.3937276832,41.8697747775 12.5057550812,41.8641534942 12.5220233075,41.9411404084 12.4101733491,41.946317302 12.3937276832,41.8697747775</gml:coordinates></gml:LinearRing></gml:innerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>IT</ogr:ISO2>
      <ogr:ISO3>ITA</ogr:ISO3>
      <ogr:ISONUM>380</ogr:ISONUM>
      <ogr:NAMEen>Italy</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.23">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-2.121978319,49.258286851 -1.9485517522,49.221635227 -1.9643268683,49.1451868387 -2.233631965,49.184515692 -2.121978319,49.258286851</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>JE</ogr:ISO2>
      <ogr:ISO3>JEY</ogr:ISO3>
      <ogr:ISONUM>832</ogr:ISONUM>
      <ogr:NAMEen>Jersey</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.24">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-158.9586243373,2.1981997994 -158.7030330396,2.3083846942 -158.3307717147,2.2767693504 -158.1490784501,2.0487082619 -158.3367460598,1.832543978 -158.7143045205,1.7568618106 -158.9553225174,1.9403985389 -158.9586243373,2.1981997994</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>KI</ogr:ISO2>
      <ogr:ISO3>KIR</ogr:ISO3>
      <ogr:ISONUM>296</ogr:ISONUM>
      <ogr:NAMEen>Kiribati</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.25">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-62.6683249718,17.3403057386 -62.495969836,17.1813919667 -62.5064786859,17.0856303369 -62.6227405958,17.1073605367 -62.6783191871,17.2068590366 -62.8358355218,17.2874612181 -62.8806497744,17.3823110073 -62.8319370543,17.4312594929 -62.6683249718,17.3403057386</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>KN</ogr:ISO2>
      <ogr:ISO3>KNA</ogr:ISO3>
      <ogr:ISONUM>659</ogr:ISONUM>
      <ogr:NAMEen>Saint Kitts and Nevis</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.26">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-60.950103319,13.714667059 -61.078114387,13.806301174 -61.0766232714,14.0163491585 -60.8765103686,14.14263803 -60.7863400265,14.0150009148 -60.8039058234,13.756048721 -60.950103319,13.714667059</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LC</ogr:ISO2>
      <ogr:ISO3>LCA</ogr:ISO3>
      <ogr:ISONUM>662</ogr:ISONUM>
      <ogr:NAMEen>Saint Lucia</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.27">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>9.6984700199,47.0581958757 9.4440495812,47.0423307452 9.5086072213,47.3038948207 9.6984700199,47.0581958757</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LI</ogr:ISO2>
      <ogr:ISO3>LIE</ogr:ISO3>
      <ogr:ISONUM>438</ogr:ISONUM>
      <ogr:NAMEen>Liechtenstein</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.28">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>6.117486613,50.120456035 6.4248140639,49.7598236407 6.345307071,49.455348652 5.790684855,49.537752585 6.117486613,50.120456035</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LU</ogr:ISO2>
      <ogr:ISO3>LUX</ogr:ISO3>
      <ogr:ISONUM>442</ogr:ISONUM>
      <ogr:NAMEen>Luxembourg</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.29">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>7.4374540321,43.7433605409 7.2139083836,43.6545644152 7.1877585717,43.7436223027 7.2986784884,43.8050969645 7.4175644716,43.8089464419 7.4374540321,43.7433605409</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MC</ogr:ISO2>
      <ogr:ISO3>MCO</ogr:ISO3>
      <ogr:ISONUM>492</ogr:ISONUM>
      <ogr:NAMEen>Monaco</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.30">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>171.0509675688,7.1449828335 171.1720942043,7.100308583 171.4183023033,7.1032488539 171.4781228716,7.1665723347 171.4157379169,7.2729935475 171.543478994,7.1944702786 171.5298659447,7.1182139913 171.4511970212,7.0643874994 171.1484027979,7.0404662342 170.9496184951,7.0922554654 170.8964373819,7.262948467 171.0509675688,7.1449828335</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MH</ogr:ISO2>
      <ogr:ISO3>MHL</ogr:ISO3>
      <ogr:ISONUM>584</ogr:ISONUM>
      <ogr:NAMEen>Marshall Islands</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.31">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>14.5464265872,35.755137911 14.2235098399,35.7648607612 14.0977562381,35.9908011391 14.3029488338,36.1589963262 14.6920406145,35.9888693222 14.5464265872,35.755137911</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MT</ogr:ISO2>
      <ogr:ISO3>MLT</ogr:ISO3>
      <ogr:ISONUM>470</ogr:ISONUM>
      <ogr:NAMEen>Malta</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.32">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>57.7138778,-20.096123956 57.8036985321,-20.2845496229 57.672211134,-20.479668878 57.3642983856,-20.4592900076 57.3062898551,-20.2580589153 57.4757681969,-20.1097234945 57.7138778,-20.096123956</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MU</ogr:ISO2>
      <ogr:ISO3>MUS</ogr:ISO3>
      <ogr:ISONUM>480</ogr:ISONUM>
      <ogr:NAMEen>Mauritius</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.33">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>167.020880478,-0.5547610896 166.9461814001,-0.5777578507 166.8760809164,-0.5602027637 166.8490033066,-0.5119840123 166.8815049746,-0.4656366588 166.9452514445,-0.4514047362 167.014020661,-0.4686977592 167.0328127012,-0.5112265593 167.020880478,-0.5547610896</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>NR</ogr:ISO2>
      <ogr:ISO3>NRU</ogr:ISO3>
      <ogr:ISONUM>520</ogr:ISONUM>
      <ogr:NAMEen>Nauru</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.34">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>134.658213738,7.591050523 134.7464337662,7.8003962326 134.9169317921,7.9702289476 134.8842833585,7.7073472864 134.7413461401,7.3845331717 134.4537427748,7.0360499678 134.2888526393,6.9843627505 134.4204794561,7.3025965533 134.658213738,7.591050523</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PW</ogr:ISO2>
      <ogr:ISO3>PLW</ogr:ISO3>
      <ogr:ISONUM>585</ogr:ISONUM>
      <ogr:NAMEen>Palau</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.35">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>104.2775580023,1.3706249219 104.1608589388,1.2377951956 103.8968093729,1.2014001273 103.6354824244,1.274331275 103.4583561103,1.4478529701 104.2775580023,1.3706249219</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SG</ogr:ISO2>
      <ogr:ISO3>SGP</ogr:ISO3>
      <ogr:ISONUM>702</ogr:ISONUM>
      <ogr:NAMEen>Singapore</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.36">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>12.3933641273,43.9120671524 12.4059826626,43.9536110312 12.4568522694,43.9827698536 12.5060500845,43.9799098218 12.5200114494,43.9376700816 12.4950334521,43.8944818867 12.4332877042,43.8846420415 12.3933641273,43.9120671524</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SM</ogr:ISO2>
      <ogr:ISO3>SMR</ogr:ISO3>
      <ogr:ISONUM>674</ogr:ISONUM>
      <ogr:NAMEen>San Marino</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.37">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>6.6852947789,0.0710740386 6.4898965358,0.1177431675 6.3965889712,0.2809625168 6.4508139842,0.4521969227 6.6592619,0.5284120205 6.9112099219,0.472267007 6.95298923,0.2905653529 6.8554024605,0.1549696689 6.6852947789,0.0710740386</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>ST</ogr:ISO2>
      <ogr:ISO3>STP</ogr:ISO3>
      <ogr:ISONUM>678</ogr:ISONUM>
      <ogr:NAMEen>Sao Tome and Principe</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.38">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>55.4867642614,-4.5241340002 55.6302425336,-4.6502312735 55.6821588839,-5.002472421 55.4992516562,-4.9289988848 55.3504862374,-4.6944448157 55.4867642614,-4.5241340002</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SC</ogr:ISO2>
      <ogr:ISO3>SYC</ogr:ISO3>
      <ogr:ISONUM>690</ogr:ISONUM>
      <ogr:NAMEen>Seychelles</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.39">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-175.2494365987,-20.9885678765 -174.8252064855,-21.0871759916 -175.1395160257,-21.3632826847 -175.4099863992,-21.1054868538 -175.2494365987,-20.9885678765</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TO</ogr:ISO2>
      <ogr:ISO3>TON</ogr:ISO3>
      <ogr:ISONUM>776</ogr:ISONUM>
      <ogr:NAMEen>Tonga</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.40">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>12.3937276832,41.8697747775 12.4101733491,41.946317302 12.5220233075,41.9411404084 12.5057550812,41.8641534942 12.3937276832,41.8697747775</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>VA</ogr:ISO2>
      <ogr:ISO3>VAT</ogr:ISO3>
      <ogr:ISONUM>336</ogr:ISONUM>
      <ogr:NAMEen>Vatican</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.41">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-61.201902145,13.0984110531 -61.2008444991,13.2720668088 -61.1851649589,13.3734890754 -61.0787470968,13.3917395978 -60.9837090632,13.351563691 -61.0323140432,13.1056974266 -61.1540929572,12.9142630687 -61.201902145,13.0984110531</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>VC</ogr:ISO2>
      <ogr:ISO3>VCT</ogr:ISO3>
      <ogr:ISONUM>670</ogr:ISONUM>
      <ogr:NAMEen>Saint Vincent and the Grenadines</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.42">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-172.2661494317,-13.4431585193 -171.3635849804,-13.9799363507 -171.6783171172,-14.0561788191 -172.5512125976,-13.8272676002 -172.782582161,-13.520277602 -172.2661494317,-13.4431585193</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>WS</ogr:ISO2>
      <ogr:ISO3>WSM</ogr:ISO3>
      <ogr:ISONUM>882</ogr:ISONUM>
      <ogr:NAMEen>Samoa</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.43">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-51.683216926,4.039374091 -52.707708293,2.358926901 -54.134908,2.11067332 -54.615292115,2.326267396 -54.003029745,3.455397441 -54.482121949,4.912802022 -54.170969205,5.348374742 -53.944349617,5.744640779 -52.994580567,5.457623554 -51.996327278,4.65228913 -51.683216926,4.039374091</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>9.4387834537,42.772068357 9.4573334991,42.007045496 9.3759273836,41.4315098442 9.167202308,41.411839059 8.8892280845,41.5760008765 8.6430622223,42.2527199557 8.7481601196,42.5406258608 9.1636602555,42.6309601214 9.1827991559,42.8143708824 9.4387834537,42.772068357</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>5.790684855,49.537752585 6.345307071,49.455348652 8.200305216,48.958563131 7.586028488,47.584618544 6.131852661,46.595606588 6.2240956714,46.2947009103 6.7872818778,46.4122156441 7.02208256,45.925259909 6.602728312,45.103449606 7.502289259,43.792222398 7.4374540321,43.7433605409 7.4175644716,43.8089464419 7.2986784884,43.8050969645 7.1877585717,43.7436223027 7.2139083836,43.6545644152 5.856605081,43.044828515 3.939300977,43.532538153 3.114024285,43.106309312 3.1809696567,42.4314841477 1.7203321516,42.4696252858 1.5608597184,42.6567593274 1.2877274765,42.5447354959 -0.038933472,42.685147604 -1.7940747449,43.3860153322 -1.16535397,44.778713283 -1.110747851,46.259222723 -1.992583788,47.052313544 -3.7248833867,47.9857204746 -4.77464759,48.491278387 -4.8127083826,48.8824138312 -3.091460741,48.87128327 -2.682362434,48.509019273 -1.37230384,48.660589911 -1.8717756803,49.6043469717 -1.1608496305,49.6699274474 -0.219471809,49.280096747 1.555349155,50.217718817 1.580577019,50.868801174 2.5217999277,51.0875408835 4.139622843,49.97452179 5.790684855,49.537752585</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-61.8975036775,16.2180692568 -61.7322051452,16.3779277414 -61.4725811365,16.2384829604 -61.3072157417,16.4688079041 -61.186683426,16.2194433769 -61.2178820046,16.0047385139 -61.5528692252,16.08580055 -61.7256684783,15.9658973255 -61.8975036775,16.2180692568</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-60.6038828663,14.5119612222 -60.717339333,14.371847246 -60.9967951389,14.4254291579 -61.1063417232,14.5572319455 -61.1575829949,14.7571106877 -61.0147834904,14.8522839093 -60.7558931547,14.7080864345 -60.6038828663,14.5119612222</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>55.7462660265,-20.5767942516 56.0379885494,-20.6270233729 56.1787533759,-20.790398489 56.1340769369,-20.969968371 55.7756466975,-20.9443075143 55.5928076607,-20.8245922062 55.5564453902,-20.6536706996 55.7462660265,-20.5767942516</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>FR</ogr:ISO2>
      <ogr:ISO3>FRA</ogr:ISO3>
      <ogr:ISONUM>250</ogr:ISONUM>
      <ogr:NAMEen>France</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.44">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>143.0999692189,54.4033128549 143.6323623568,52.8367027333 143.4228484805,51.9789536503 144.4803734291,49.2881246936 143.258636915,49.393377997 142.7522158267,48.0504465538 143.5785207448,46.5478492629 142.7161129012,46.7651953368 142.5869922633,46.0597248044 142.094248894,45.902777411 141.822276238,46.602280992 142.191091342,47.966742255 142.0779774144,48.8370793349 142.5350219152,51.1910436195 142.1056525894,51.935616373 142.1491667168,53.5001345718 142.598728772,53.6575228913 142.7648082367,54.1787867014 143.0999692189,54.4033128549</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>22.767219686,54.356269837 19.7579288966,54.4342658307 19.3094839524,54.588041797 19.9262251318,55.1029148982 21.0364811833,55.3006228883 22.808870891,54.893756409 22.767219686,54.356269837</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-179.958548764,65.1301897008 -179.9445302059,67.2437077142 -179.9437799227,68.9344873574 -174.4794874161,67.0227912164 -171.5170382335,66.8768826135 -170.0069842591,66.0853214535 -170.5105598867,65.6609711166 -171.9830847145,65.4506563706 -173.0330342958,64.2131184436 -175.2783428403,64.8039157749 -176.026405631,65.4739647801 -178.3820567385,65.4972880748 -179.958548764,65.1301897008</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>50.5909877184,69.3313758282 49.4827024546,68.6304180886 48.4578647705,68.6169444119 48.3952924921,69.3932701869 49.4169847817,70.0349239802 50.4364632572,69.8757017211 50.5909877184,69.3313758282</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-179.9245167468,70.9947039179 -179.9208367433,71.5118955909 -178.6830455647,71.5730525617 -177.2322995786,71.1843227671 -179.9245167468,70.9947039179</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>143.0241584133,74.2879934538 144.5093127011,74.1152694886 143.4088526844,73.3453631031 140.493302439,73.485043916 143.0241584133,74.2879934538</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>146.7295028,75.48822663 150.2338641458,75.3970064777 153.0314203177,75.3243501256 148.172129754,74.803534247 146.7295028,75.48822663</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>139.109629754,76.096869208 141.366953972,76.181219794 145.380869988,75.512274481 143.707774285,74.947455145 139.343435092,74.68740469 137.149099155,75.134222723 137.067637566,75.725775458 139.109629754,76.096869208</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>67.146494988,76.104641018 61.379649285,75.334173895 59.145762566,74.444037177 58.4767142976,74.180883573 57.0897006824,73.5623496972 55.6065029497,72.3548362173 56.105723504,71.258978583 57.638682488,70.729885158 55.162608269,70.553127346 53.187914248,70.8315318517 52.2276395091,71.683835144 53.631114129,73.759588934 58.931000196,75.867621161 62.956797722,76.20693594 65.5288229601,76.581735762 66.653977997,76.5290906758 67.146494988,76.104641018</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>130.699961785,42.295111395 130.530771119,42.530480042 131.28090621,43.380221456 130.933433879,44.841708476 131.9919443364,45.2293538981 132.3536218555,44.527986561 133.2575604354,45.5403816751 133.90245162,46.258986308 134.154115845,47.257891744 134.772579387,47.710732321 134.386349732,48.381337383 132.524654582,47.707528381 131.023350871,47.682284445 130.822122843,48.333769226 129.502410116,49.41078359 128.092470338,49.54157664 126.931765992,51.063783468 126.531170288,52.152657572 125.9497198547,53.1685824973 124.5287569115,53.7331411849 122.581510365,53.6845503734 120.874254598,53.280159811 120.03296228,52.760656637 120.779169963,52.117595114 119.141233765,50.37661611 119.316210165,50.092654114 117.758837525,49.512741191 116.684277792,49.823264873 115.368699179,49.895405172 114.286284628,50.276880595 113.043673137,49.588602194 110.731359497,49.137673646 108.538056681,49.327429505 107.946516561,49.933490703 105.328640178,50.476454977 103.668069703,50.131204733 102.327634726,50.545546366 102.18387089,51.32389679 100.005967652,51.731727193 98.886397746,52.128550517 97.806360311,51.001125794 98.293462362,50.518622946 97.301688274,49.725544739 94.624539022,50.015191142 94.237585897,50.565235087 92.301683391,50.843357646 87.816324097,49.165837301 87.323796021,49.085273743 86.591799357,49.58720693 85.26309493,49.581522522 83.433955933,50.992650859 81.460226277,50.730341289 80.682754354,51.30201182 79.990083456,50.78811554 77.866802206,53.272330832 76.9598554934,53.8425845084 76.85239384,54.461172995 73.424075968,53.432553609 73.485260864,53.874852193 71.182300659,54.101556702 70.820358928,55.294145406 68.943160848,55.434550273 68.166050659,54.956129863 65.212949259,54.34304067 61.60050826,53.950248108 61.007572876,53.635745342 61.058422485,52.922171326 61.039922323,52.334997864 60.138065226,51.888875224 61.66365686,51.258396912 61.37209843,50.782482808 58.92594283,50.678148092 58.308409465,51.150031434 56.508002564,51.066263937 55.1045814792,50.763168457 53.346335083,51.503033142 50.581697632,51.635298971 48.67339034,50.57954946 48.3054787052,50.1074706112 47.556921021,50.452580465 46.899906861,49.820319316 46.756988397,49.201494039 46.479312378,48.410224508 47.119480021,47.819769592 48.044488159,47.769695129 49.2271305193,46.327879184 47.619476759,45.758937893 46.700938347,44.446193752 47.245941602,44.211981512 47.461924675,43.020819403 48.578949415,41.845282294 47.871113729,41.208183492 46.430891561,41.89044159 44.859359579,42.75950999 43.939725789,42.552209982 42.422867473,43.228990377 40.651916138,43.538971456 39.9859763554,43.3889896097 38.978282097,44.148260809 36.5123596731,45.0942448337 36.6451264137,45.3476870797 37.738291863,45.310695705 37.737559441,46.676336981 39.261892123,47.008612372 38.216644727,47.103257554 38.830942017,47.848243306 39.759050741,47.832947083 39.681122681,49.020316468 40.141663045,49.245780741 39.182755168,49.858508199 37.435264933,50.424933573 35.696869751,50.345145162 35.099180135,51.183181865 34.185954224,51.248914286 33.804065389,52.35460907 31.76434493,52.100567729 31.6751584926,52.9736195622 32.3261551137,53.0397164888 32.719532104,53.439478252 31.744656209,53.794857076 30.770607137,54.786011048 30.468816773,55.79352061 28.148906697,56.142414043 27.352934611,57.52760081 27.6414384538,58.0020489524 27.7152305574,58.9957844089 27.8426052139,59.1616595139 28.1800455088,59.3566509454 28.019053582,59.481756903 29.2632363827,59.9935499801 28.7447407901,60.3911417293 27.807871941,60.553045966 29.203157593,61.245900981 31.56952478,62.905928854 29.980784546,63.741536764 30.558475382,64.219698792 29.588147013,64.991434632 29.900169311,66.108058981 29.089159383,66.837549337 30.00941329,67.685843812 28.663758993,68.204003398 28.954077189,69.027260641 30.8409538907,69.8058419025 33.620453321,69.327704169 35.966970248,69.176825262 41.016612175,67.697902736 40.9430036112,66.7455336249 39.9561877874,66.109290685 37.927093946,66.088771877 33.48324629,66.73041413 34.496836785,66.116156317 34.773203972,64.556301174 37.291026238,63.818182684 38.088063998,64.034898179 36.439952019,64.917059637 37.007677058,65.172976826 40.517100457,64.541449286 39.712087436,65.401841539 42.200938347,66.532171942 44.167165561,65.885443427 43.815329312,67.177452523 44.1113696142,67.927810549 43.325694207,68.613674221 45.943858269,68.446234442 46.722015821,67.844916083 45.5240108432,67.4901692004 45.853200717,66.887030341 47.72559655,67.000921942 47.824717644,67.560288804 53.437022332,68.91815827 54.864024285,68.185126044 58.878754102,69.003119208 60.770274285,69.849107164 64.12761478,69.550116278 68.258636915,68.333889065 69.109060092,68.8789737 67.101817254,69.692775783 66.927012566,71.298407294 68.478851759,71.83616771 68.989105665,72.705877997 71.6039799322,73.5170400517 72.836924675,72.709906317 72.3825613902,71.7861913638 72.67074629,71.108954169 72.9449137254,69.1248265901 73.2301597037,68.167710609 71.5289834806,66.7659510143 69.112640821,66.618841864 70.3035194364,66.0107031512 71.990082227,66.230780341 74.2929902501,67.598078205 75.1509061618,68.9091686526 76.6101015863,68.6391399 77.6826278,68.885809637 76.2993586863,69.494702453 74.2068641182,69.4863594474 74.316172722,70.520331122 74.2442771997,72.2396363085 75.4407253428,71.9653289822 75.7261072156,71.3046567933 76.7730445119,71.222044046 77.0993026917,71.893570582 78.2686231865,72.0603155091 79.391449415,72.385565497 81.736664259,71.699896552 83.628184441,71.610907294 80.704112175,72.545355536 80.832204623,73.571763414 86.783213738,73.90224844 86.020030144,74.262518622 89.22925866,75.502671617 95.872894727,76.138128973 96.835215691,75.888983466 102.0267307832,77.2205538264 104.345713738,77.135484117 107.946055535,76.737290757 111.137054884,76.746812242 113.45972741,76.14838288 112.879649285,74.992905992 106.359873894,73.194281317 110.898610873,73.685858466 113.493662957,73.510646877 118.450205925,73.588771877 118.462412957,73.209418036 121.0378629959,72.978041673 124.383067254,73.806382554 127.987559441,73.470851955 129.443508491,73.028944249 128.3912924296,71.984408341 129.392100457,71.346828518 130.5696359456,70.9621340428 132.539317254,71.883612372 133.650075717,71.436509507 135.985118035,71.634833075 138.067230665,71.224920966 139.6647456711,71.4257782764 139.54175866,72.497626044 141.550629102,72.774318752 146.9448884785,72.3543957903 149.005218946,71.70311107 152.210948113,70.880560614 157.989105665,71.047512111 159.689463738,70.670965887 159.688975457,69.89077383 160.5416702042,69.3604361918 162.407969597,69.676581122 167.802012566,69.775213934 169.228464248,68.9891346981 170.2384575196,69.0259692762 170.610850457,70.116278387 175.529736586,69.856304017 179.9496244944,68.9672499244 179.9429154177,67.0809314552 179.9326637524,65.0800371578 178.282562696,64.353989976 179.2014805566,63.7393021534 179.609060092,62.705633856 178.938161655,62.366034247 176.471503713,62.2667522013 174.2124413602,61.8440731948 171.6469551684,60.8706096153 170.8907963679,60.1297338596 170.400645379,59.965643622 169.247813347,60.567328192 165.129649285,60.084173895 163.3935466464,59.6170492671 163.077757778,59.007594079 161.993228165,58.087392175 163.329510112,57.708944701 162.783500266,56.763028714 163.366068623,56.180658663 162.142100457,56.12905508 162.153168165,54.849920966 160.052989129,54.17572663 159.632497592,53.257147528 158.64714603,52.899359442 157.759192434,51.543983029 156.719697509,50.886453751 156.11119584,52.935420328 155.551177167,55.284204852 156.047615999,56.765090664 157.469899936,57.803941148 159.023773634,58.414780992 159.864431186,59.14057038 164.028819207,61.346625067 164.597937066,62.673065416 163.26705047,62.521994642 162.417246941,61.6758487 160.154392683,60.576336133 160.345713738,61.944728908 158.1504341365,61.8208221376 155.4195593624,60.263258053 155.19410241,59.17576732 153.4499014,58.8456798105 152.311827469,59.226648758 150.5897616213,59.8364875625 148.934522469,59.233272922 146.3323713657,59.7141737141 143.159678582,59.353908596 140.904307488,58.38275788 138.661615027,56.977942647 137.571950717,56.116522528 135.219571451,54.894120841 136.883311394,54.591376044 136.684743686,53.80849844 138.738536004,54.315985419 140.6610366822,54.2430027649 141.5280492826,53.1756116405 141.429535352,51.941961981 140.442881707,50.544378973 140.660655144,50.058010158 140.165049675,48.44940827 139.261729363,47.787909247 138.10035241,46.227972723 135.888682488,44.401516018 135.139903191,43.508368231 133.157725457,42.688421942 131.730723504,43.174139716 130.699961785,42.295111395</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>102.929942254,79.275702216 104.8062975842,78.676522481 98.8895640611,77.5564509416 101.309906446,79.238755601 102.929942254,79.275702216</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>97.774261915,80.131415106 100.2967188249,79.6236628453 99.4546147914,78.5263716346 94.8708261545,78.592612045 93.28028405,79.552476304 97.774261915,80.131415106</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>48.8288806845,80.813267381 51.700938347,80.676947333 54.9575882137,80.7798773664 57.1032293396,80.9491227208 59.4208915401,80.9655980592 54.4423985438,79.361318318 51.7338589338,79.0886497484 49.8977433695,79.5506232797 48.8288806845,80.813267381</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>96.4888923392,81.6369540059 98.4557510585,80.9369897721 92.9561828674,80.2204272268 96.4888923392,81.6369540059</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>RU</ogr:ISO2>
      <ogr:ISO3>RUS</ogr:ISO3>
      <ogr:ISONUM>643</ogr:ISONUM>
      <ogr:NAMEen>Russia</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.45">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>74.892306763,37.231113587 74.542353963,37.021669006 72.565213664,36.820596008 71.16591923,36.045707906 71.633694296,35.203123678 71.062618042,34.054253235 70.002837769,34.043788758 70.294447876,33.31894928 69.547516724,33.075010682 69.298849731,31.937689922 68.159126018,31.825913798 66.366263876,30.922868144 66.195628296,29.835337627 64.086092977,29.386605326 62.477508993,29.407818502 60.844378703,29.85817861 61.785199829,30.831400859 61.661176391,31.381909892 60.821744425,31.494667868 60.511789185,33.638387146 61.269675741,35.61849884 62.302015828,35.147519837 63.342934204,35.856262106 64.444572388,36.249984843 65.063087606,37.233232321 65.761442912,37.578379212 66.51958785,37.3641804 67.780544475,37.188868103 68.011124715,36.930873516 69.528654826,37.586027324 70.157867065,37.541430562 70.76108606,38.443520203 71.597727499,37.898359681 71.611060018,36.7048408 73.276074667,37.459471741 74.892306763,37.231113587</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AF</ogr:ISO2>
      <ogr:ISO3>AFG</ogr:ISO3>
      <ogr:ISONUM>4</ogr:ISONUM>
      <ogr:NAMEen>Afghanistan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.46">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>23.9676076164,-10.8770496782 24.000632772,-13.001479187 21.979877563,-13.001479187 21.983804972,-16.165885519 22.108138469,-16.543950297 23.381652466,-17.641144307 20.806202433,-18.031404724 18.761986124,-17.747701111 18.453581177,-17.389893494 13.942745402,-17.408186951 13.166307006,-16.951057231 11.766123894,-17.252699477 11.751800977,-15.799086196 12.272715691,-14.750583592 12.512705925,-13.442071222 13.639821811,-12.248711847 13.7529403,-10.646172784 12.996348504,-9.09384531 13.369395379,-8.323500258 12.828786655,-6.904554946 12.275060383,-6.114769138 13.1838927169,-5.861165405 16.3157818715,-5.8593347537 17.5443642728,-8.0894963807 19.3556307093,-8.0067101558 19.5219148285,-7.006661305 20.6115674262,-6.9206712009 20.520620974,-7.2910901553 21.7850451703,-7.2880929033 21.9400907528,-8.5046678436 21.8542185417,-9.622541295 22.3135312065,-10.3733030991 22.2377848658,-11.2542913211 23.9676076164,-10.8770496782</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>13.07370284,-4.635323181 12.444387248,-5.055090841 12.210541212,-5.763441665 12.009607691,-5.019630836 12.854284709,-4.403089295 13.07370284,-4.635323181</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AO</ogr:ISO2>
      <ogr:ISO3>AGO</ogr:ISO3>
      <ogr:ISONUM>24</ogr:ISONUM>
      <ogr:NAMEen>Angola</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.47">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>20.064955688,42.546758118 20.567147258,41.873181662 20.633525624,41.0826440979 20.7245659003,40.9084800643 20.9410466833,40.906252751 20.9645643201,40.841981383 21.0212289216,40.6872807501 19.999847852,39.693508205 19.309825066,40.644354559 19.365082227,41.852362372 19.3710404475,42.0884163441 19.4004744743,42.3263247431 20.064955688,42.546758118</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AL</ogr:ISO2>
      <ogr:ISO3>ALB</ogr:ISO3>
      <ogr:ISONUM>8</ogr:ISONUM>
      <ogr:NAMEen>Albania</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.48">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>56.2790552346,25.6274456978 56.383311394,24.978216864 55.788666626,24.855202332 55.755697062,24.230330912 55.186842895,22.703576559 52.583074178,22.93110789 51.56934655,24.256170966 51.9608567642,24.0208899771 54.122569207,24.14472077 55.8863373911,25.884154699 56.1159005342,25.6215553345 56.2790552346,25.6274456978</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AE</ogr:ISO2>
      <ogr:ISO3>ARE</ogr:ISO3>
      <ogr:ISONUM>784</ogr:ISONUM>
      <ogr:NAMEen>United Arab Emirates</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.49">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-68.6276167765,-52.639571699 -68.451350729,-53.297717399 -66.482213314,-54.465800355 -65.155588345,-54.64055755 -66.540507726,-55.05104603 -68.6541354319,-54.8862445646 -68.641997851,-54.799167576 -68.6364837741,-54.7829713158 -68.6276167765,-52.639571699</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-62.650357219,-22.234455668 -61.00634904,-23.805470886 -60.033669393,-24.007008972 -57.556921346,-25.45984019 -58.653288534,-27.156274109 -57.180096802,-27.487313334 -55.754731608,-27.443698425 -54.793059042,-26.644987488 -54.600202613,-25.574944884 -53.90996049,-25.629235534 -53.666719523,-26.219173686 -53.842005981,-27.16350881 -55.772534139,-28.231970724 -57.611698365,-30.182962748 -58.2001118521,-32.4471299123 -58.570423957,-34.288181248 -57.144908527,-35.484200289 -57.248036262,-36.170342706 -56.664865689,-36.851006769 -57.593576627,-38.152764581 -59.063221809,-38.693780206 -61.518055793,-39.01148854 -62.390207486,-38.814711196 -62.023915168,-39.364841404 -62.490061002,-40.307875258 -62.337798632,-40.872735284 -63.779408332,-41.158786717 -64.890451627,-40.705987238 -65.069569465,-41.985772394 -63.809959888,-42.070174455 -63.620269335,-42.751234633 -64.437733528,-42.506931248 -64.433461067,-42.97633229 -65.334055142,-43.672621352 -65.602642605,-45.027686553 -66.200366619,-44.992919197 -67.331924501,-45.613491405 -67.622466601,-46.163750909 -66.78644772,-47.006605727 -65.979562955,-47.06617604 -65.968445,-48.047168108 -67.556548698,-49.015816864 -67.833207006,-49.954540456 -68.876429324,-50.330572019 -69.167778305,-50.978224848 -68.4484404191,-52.3468881602 -69.952753866,-52.007418722 -71.917698528,-51.99005544 -72.450069133,-51.552666118 -72.302842978,-50.648896994 -73.177724976,-50.74945933 -73.586588908,-49.529998881 -72.295091512,-48.333276062 -72.543913534,-47.914800313 -71.687169963,-46.690068868 -71.798532675,-45.739945984 -71.311533977,-45.299456075 -72.047819784,-44.754786478 -71.659884807,-43.926309916 -72.148537151,-42.998717956 -71.955577353,-40.720355733 -71.41576534,-38.935348409 -70.873834595,-38.691435649 -71.18503007,-37.706069437 -71.043281616,-36.484335225 -70.380324667,-36.046015727 -70.227827515,-34.585329691 -69.83276119,-34.24323171 -70.172482057,-32.464942322 -70.591371216,-31.549597676 -70.042619181,-29.363064474 -69.653030559,-28.397852071 -68.801092896,-27.112762553 -68.330475627,-27.044963073 -68.572373007,-24.769856466 -67.362369345,-24.030366719 -67.193904175,-22.822223409 -66.240008911,-21.792415466 -65.744612794,-22.114049581 -64.586879842,-22.212751567 -64.343897258,-22.863667907 -63.947590699,-22.00759613 -62.650357219,-22.234455668</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AR</ogr:ISO2>
      <ogr:ISO3>ARG</ogr:ISO3>
      <ogr:ISONUM>32</ogr:ISONUM>
      <ogr:NAMEen>Argentina</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.50">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>45.002399944,41.290452373 45.979239543,40.223592428 45.639570353,40.02541331 46.2729202574,39.5303916442 46.51403894,38.882175599 46.135870809,38.863701274 45.78808842,39.548956604 44.774558553,39.702797343 43.665427287,40.110162659 43.4404281,41.106587626 45.002399944,41.290452373</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AM</ogr:ISO2>
      <ogr:ISO3>ARM</ogr:ISO3>
      <ogr:ISONUM>51</ogr:ISONUM>
      <ogr:NAMEen>Armenia</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.51">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>144.3974099254,-40.4584400306 146.1287870521,-41.0635348418 148.023682957,-40.6022008794 148.4845676019,-40.9823390545 148.3085495567,-42.2716457328 147.964040561,-43.22242604 147.3677334474,-43.2771388133 146.855723504,-43.639580988 146.024180535,-43.552504165 145.265472852,-42.604261977 144.3974099254,-40.4584400306</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>137.5624963957,-35.6361552112 137.8433733984,-36.2467168365 136.4441444799,-36.1750681684 136.2386093927,-35.5169313328 137.5624963957,-35.6361552112</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>130.2370182802,-11.0948062582 131.2642446173,-10.9897448046 131.8686139183,-11.474786066 130.9866889334,-11.8376049483 129.9668569822,-11.7128625257 130.2370182802,-11.0948062582</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>142.54957116,-10.708184503 143.07715905,-12.328789972 143.433929884,-12.61305104 143.53012129,-13.750176691 143.941172722,-14.511163019 144.478851759,-14.15992604 145.345713738,-14.942559503 145.400401238,-16.443291925 146.147715691,-17.63258229 146.276621941,-18.874281508 147.684255405,-19.82805755 148.560069207,-20.052666925 149.231211785,-21.0897763 149.9352652929,-22.206668352 150.826426629,-22.697930597 150.814219597,-23.411309503 151.780446811,-24.022556248 153.205577019,-25.934991144 153.206228061,-27.046075128 153.605967644,-28.867445571 152.539886296,-32.442091941 151.834033071,-32.864967129 150.924918127,-34.330418881 150.759450717,-35.178887628 150.152598504,-35.893731378 150.0088072624,-37.6982250203 148.306407097,-37.823418878 146.7716308898,-38.6210001307 146.425547722,-39.136407159 145.373057488,-38.530531508 143.536957227,-38.858330988 142.397715691,-38.36712005 141.653981967,-38.399834894 140.359873894,-37.882094008 139.741547071,-37.180840753 139.853688998,-36.621758722 139.260747399,-35.8741895703 138.201670769,-35.67164479 138.536306186,-34.740899347 138.3036465816,-34.1822144647 137.6238028303,-34.967622319 137.1725233184,-33.2230005569 136.1830718592,-33.7800701795 135.604014519,-34.880140883 134.9127910527,-33.8022180276 134.0983598316,-32.5459577704 132.233734571,-32.032972915 131.177500847,-31.477634373 128.990000847,-31.690524998 127.288747592,-32.27337005 126.185720248,-32.232517185 124.116547071,-33.121514581 123.526621941,-33.938653253 121.532888217,-33.819512628 120.002207879,-33.926039321 118.385101759,-34.908379816 116.637868686,-35.050225519 115.118825717,-34.36337656 114.988536004,-33.521091404 115.66684004,-33.287692967 115.680349155,-31.648614191 114.974864129,-30.214043878 114.978770379,-29.479913019 114.166026238,-28.106703383 114.012543165,-27.315362238 113.6935018179,-26.9079239544 113.1790271486,-26.3492933095 112.8220127462,-25.5417143502 113.6514992815,-25.8208940289 114.0469567997,-25.6994925941 113.713063998,-25.12493255 113.414561394,-24.049411717 113.749847852,-23.5116513 113.646657748,-22.577732029 114.011485222,-21.859958592 114.3703324162,-22.0035434043 114.646739129,-21.843357029 115.454600457,-21.513767185 116.820323113,-20.549899998 117.353770379,-20.727715753 118.13559004,-20.362074477 120.954356316,-19.633721613 121.823741082,-18.451836847 122.323985222,-18.150567316 122.172048373,-17.261163019 122.95980879,-16.580336196 123.553965691,-17.518975519 123.860850457,-17.210381769 123.539724155,-16.265232029 124.2162097465,-16.1615150875 124.389903191,-15.522556248 124.928884311,-15.338148696 125.356455925,-14.504327081 127.1817748302,-13.7004677578 128.175303582,-14.698418878 129.611827019,-14.942559503 129.35808353,-14.408786717 130.129893425,-12.940524998 130.9948529241,-12.2351488407 132.679047071,-12.13681406 132.5740499429,-11.4864307505 133.0992212515,-11.3984508268 133.524668816,-11.858330988 134.4270561543,-11.9837488933 135.5802592213,-12.1425515015 136.450713101,-11.942333451 136.927816273,-12.348983402 136.652028842,-13.013441665 135.942838503,-13.256149132 135.909434441,-14.19524505 135.378265821,-14.712334894 136.704600457,-15.915215753 139.037282748,-16.915622654 139.999522332,-17.706149998 140.833262566,-17.450778904 141.431162957,-16.061781508 141.594737175,-12.526055597 142.17457116,-10.930108331 142.54957116,-10.708184503</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AU</ogr:ISO2>
      <ogr:ISO3>AUS</ogr:ISO3>
      <ogr:ISONUM>36</ogr:ISONUM>
      <ogr:NAMEen>Australia</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.52">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>46.135870809,38.863701274 45.2491653187,38.9452682836 44.8346988445,39.561142994 44.774558553,39.702797343 45.78808842,39.548956604 46.135870809,38.863701274</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>46.430891561,41.89044159 47.871113729,41.208183492 48.578949415,41.845282294 49.89340254,40.369045315 49.442637566,40.078436591 48.874278191,38.434068101 48.012965535,38.821559143 48.338940471,39.378941142 47.846877482,39.685279032 46.51403894,38.882175599 46.2729202574,39.5303916442 45.639570353,40.02541331 45.979239543,40.223592428 45.002399944,41.290452373 46.496779012,41.04483429 46.430891561,41.89044159</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>AZ</ogr:ISO2>
      <ogr:ISO3>AZE</ogr:ISO3>
      <ogr:ISONUM>31</ogr:ISONUM>
      <ogr:NAMEen>Azerbaijan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.53">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>30.55459965,-2.400627543 30.825487508,-2.978576761 30.003005411,-4.271934509 29.6543531249,-4.4505910788 29.2066786417,-3.3344242464 29.015365438,-2.720711365 29.697546021,-2.808251241 29.931691935,-2.316911723 30.55459965,-2.400627543</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BI</ogr:ISO2>
      <ogr:ISO3>BDI</ogr:ISO3>
      <ogr:ISONUM>108</ogr:ISONUM>
      <ogr:NAMEen>Burundi</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.54">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>3.596400187,11.69577301 3.837419067,10.599896749 2.722861776,8.772308045 2.7038412893,6.3683516726 1.619639519,6.213893947 1.601173136,9.049526266 1.331008748,9.996471049 0.768769164,10.367094421 0.901474243,10.992740987 1.439632609,11.473771057 2.010760538,11.426900533 2.390168904,11.89653595 2.6025122308,12.2310288425 3.1116627147,12.1491879924 3.596400187,11.69577301</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BJ</ogr:ISO2>
      <ogr:ISO3>BEN</ogr:ISO3>
      <ogr:ISONUM>204</ogr:ISONUM>
      <ogr:NAMEen>Benin</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.55">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>0.218466838,14.910977275 0.152941121,14.546710103 0.971754191,13.0673172 2.109049113,12.705633851 2.390168904,11.89653595 2.010760538,11.426900533 1.439632609,11.473771057 0.901474243,10.992740987 -0.166109171,11.134980367 -0.695999309,10.994032898 -2.750705933,10.985842184 -2.689210978,9.488724263 -3.202564657,9.908233541 -4.681079061,9.682071635 -5.522578085,10.42548879 -5.28248938,11.836436259 -4.560466268,12.149492086 -3.971613322,13.469954122 -3.3208293581,13.5175966081 -2.840855469,14.04299408 -2.023411825,14.198643494 -0.75289506,15.069727274 0.218466838,14.910977275</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BF</ogr:ISO2>
      <ogr:ISO3>BFA</ogr:ISO3>
      <ogr:ISONUM>854</ogr:ISONUM>
      <ogr:NAMEen>Burkina Faso</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.56">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>92.57587854,21.977574362 92.265147332,21.061102606 91.6170062003,22.539555645 90.954925977,22.575832424 90.6502534028,22.856411745 90.613454623,22.314886786 89.1214720516,21.5961373196 88.954704224,23.183805644 88.540104208,23.649952901 88.74980717,24.223251242 88.021789592,24.645602722 88.924163452,25.167870585 88.0743962,25.908135478 88.461142619,26.45389028 89.83439213,25.931751608 89.79501469,25.374162903 90.364644003,25.14999054 92.001753377,25.182960104 92.107586711,24.405979106 91.140824015,23.612099915 91.586068156,22.944466248 92.150788208,23.731653341 92.57587854,21.977574362</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BD</ogr:ISO2>
      <ogr:ISO3>BGD</ogr:ISO3>
      <ogr:ISONUM>50</ogr:ISONUM>
      <ogr:NAMEen>Bangladesh</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.57">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>28.578379754,43.741278387 27.629405144,42.458644924 28.016774936,41.97256094 27.273352906,42.091747132 26.333358602,41.713036397 25.28572229,41.239396057 24.510162395,41.561650289 22.916977986,41.335772604 22.8565652991,41.9077564398 22.345023234,42.313439026 22.981366822,43.198992208 22.349467407,43.807921448 22.691640373,44.228434539 23.325150732,43.886592281 25.359619588,43.654287415 27.027476441,44.177046204 28.578379754,43.741278387</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BG</ogr:ISO2>
      <ogr:ISO3>BGR</ogr:ISO3>
      <ogr:ISONUM>100</ogr:ISONUM>
      <ogr:NAMEen>Bulgaria</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.58">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>19.01582076,44.865634664 19.36866744,44.88713206 19.240471937,44.4457522097 19.3904035405,44.0055586499 19.195344686,43.532796122 18.437354777,42.559212138 17.653330925,42.890936591 17.580658399,42.942084052 17.0680060084,43.5347114139 15.9833981709,44.5932791617 16.0143286918,45.0689690795 16.924372193,45.284523825 19.01582076,44.865634664</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BA</ogr:ISO2>
      <ogr:ISO3>BIH</ogr:ISO3>
      <ogr:ISONUM>70</ogr:ISONUM>
      <ogr:NAMEen>Bosnia and Herzegovina</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.59">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>28.148906697,56.142414043 30.468816773,55.79352061 30.770607137,54.786011048 31.744656209,53.794857076 32.719532104,53.439478252 32.3261551137,53.0397164888 31.6751584926,52.9736195622 31.76434493,52.100567729 30.959329467,52.074677836 30.148629598,51.484429627 27.25402592,51.595378927 25.76791508,51.928511047 24.390789836,51.880012716 23.606238241,51.517399191 23.165644979,52.289393413 23.868961222,52.670042013 23.485625448,53.939292704 24.788698365,53.969678447 25.782694539,54.869675192 26.585069889,55.2483949451 26.594531291,55.666990866 28.148906697,56.142414043</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BY</ogr:ISO2>
      <ogr:ISO3>BLR</ogr:ISO3>
      <ogr:ISONUM>112</ogr:ISONUM>
      <ogr:NAMEen>Belarus</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.60">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-88.091542121,18.371730861 -88.283314582,17.580267645 -88.217437304,16.955471096 -88.6941161154,15.8429139169 -89.234135092,15.95494456 -89.160496175,17.81431427 -88.303822395,18.481350002 -88.091542121,18.371730861</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BZ</ogr:ISO2>
      <ogr:ISO3>BLZ</ogr:ISO3>
      <ogr:ISONUM>84</ogr:ISONUM>
      <ogr:NAMEen>Belize</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.61">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-58.158796753,-20.165124613 -58.175281535,-19.821372985 -59.089540975,-19.286728617 -60.006384237,-19.298097432 -61.761212525,-19.657765401 -62.277305054,-20.579776306 -62.650357219,-22.234455668 -63.947590699,-22.00759613 -64.343897258,-22.863667907 -64.586879842,-22.212751567 -65.744612794,-22.114049581 -66.240008911,-21.792415466 -67.193904175,-22.822223409 -67.87634314,-22.833592224 -68.207537395,-21.284332784 -68.7755389,-20.089677022 -68.496356975,-19.458397725 -68.989608521,-18.946490987 -69.510088752,-17.506588198 -69.0377217651,-16.551258157 -68.6175986611,-16.2128736161 -69.3689075755,-15.5197582472 -69.390669312,-14.964408467 -68.883723511,-14.211482849 -68.980952718,-12.867947286 -68.684252483,-12.502491557 -69.577634644,-10.952301941 -68.293320272,-10.97896698 -66.631871298,-9.904303894 -65.304381267,-9.825652364 -65.394737509,-11.153426615 -64.997449097,-11.996269226 -64.395728719,-12.457326355 -63.07503414,-12.652663269 -61.847977254,-13.530800882 -61.047225098,-13.464551697 -60.472634847,-13.797864685 -60.129839234,-16.273062439 -58.464721233,-16.331250102 -58.381160442,-17.267213643 -57.790757203,-17.555774841 -57.55108191,-18.183643493 -58.158796753,-20.165124613</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BO</ogr:ISO2>
      <ogr:ISO3>BOL</ogr:ISO3>
      <ogr:ISONUM>68</ogr:ISONUM>
      <ogr:NAMEen>Bolivia</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.62">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-54.615292115,2.326267396 -54.134908,2.11067332 -52.707708293,2.358926901 -51.683216926,4.039374091 -51.3314490787,3.9107245895 -51.092741743,3.376328545 -50.466542121,1.815415757 -49.910158911,1.664262758 -49.890044726,1.165228583 -51.0504846204,-0.0653241127 -52.0829316167,-0.9390682876 -51.2641316296,-0.7363431545 -50.3951131941,-0.0730737804 -49.5737560459,-0.0758142792 -48.548348097,-0.3580036694 -48.8969440887,-1.8929388465 -48.421457486,-1.645114842 -48.037912564,-0.661716404 -46.171783007,-0.920993748 -44.521717903,-1.847263279 -44.368072069,-2.549574477 -43.31176641,-2.346467357 -42.23940996,-2.834161066 -39.985707161,-2.848402602 -38.477406379,-3.697442316 -37.182932095,-4.910902602 -35.510568814,-5.143731378 -34.797352668,-7.158461196 -34.811634895,-7.905857029 -35.305083788,-9.193047784 -36.408070442,-10.502129816 -36.903065559,-10.772881769 -38.050892707,-12.641045831 -38.722075976,-12.622491144 -39.039784309,-13.366631769 -39.067128059,-14.674981378 -38.86436927,-15.843357029 -39.137115038,-17.67962005 -39.724680142,-18.518731378 -39.709787564,-19.416110935 -41.071867556,-21.523338532 -40.967274543,-21.947523696 -41.966297981,-22.535414321 -42.058216926,-22.953789972 -43.86436927,-22.905938409 -44.70051022,-23.107679946 -45.433501757,-23.664727472 -46.966460741,-24.299086196 -47.825550911,-24.894138279 -48.578521288,-25.872816665 -48.815337694,-28.610446873 -49.810658332,-29.443129165 -50.315663215,-30.461521092 -52.4483263127,-33.0146309677 -52.2708278513,-32.6674692721 -51.2356551218,-31.4223049168 -50.841842947,-30.6527551265 -51.2691858126,-30.6260118065 -51.5355557875,-31.1245824902 -51.9598946217,-31.6789546911 -52.621693489,-33.101983331 -53.3790945694,-33.7406759724 -53.5367920278,-33.5597688778 -53.1724546853,-32.6592425794 -54.591520956,-31.471049499 -56.011356771,-30.798222351 -56.831280885,-30.102037455 -57.611698365,-30.182962748 -55.772534139,-28.231970724 -53.842005981,-27.16350881 -53.666719523,-26.219173686 -53.90996049,-25.629235534 -54.600202613,-25.574944884 -54.6094558586,-25.4316939044 -54.2666745135,-24.0662345087 -55.398035034,-23.976829936 -55.874388387,-22.317344665 -57.986817586,-22.035294698 -57.81757727,-20.953603617 -58.158796753,-20.165124613 -57.55108191,-18.183643493 -57.790757203,-17.555774841 -58.381160442,-17.267213643 -58.464721233,-16.331250102 -60.129839234,-16.273062439 -60.472634847,-13.797864685 -61.047225098,-13.464551697 -61.847977254,-13.530800882 -63.07503414,-12.652663269 -64.395728719,-12.457326355 -64.997449097,-11.996269226 -65.394737509,-11.153426615 -65.304381267,-9.825652364 -66.631871298,-9.904303894 -68.293320272,-10.97896698 -69.577634644,-10.952301941 -70.641342326,-11.010799662 -70.624418295,-9.565823263 -71.391425741,-10.006829935 -72.195666057,-10.005589701 -72.306770386,-9.540915222 -73.214983684,-9.409036967 -72.95939205,-9.085645854 -74.018474691,-7.543517761 -73.765492717,-6.90417694 -73.131784628,-6.435264995 -72.917947551,-5.132088725 -70.832235067,-4.179433695 -69.964949504,-4.236484477 -69.399454305,-1.182717387 -70.073805908,-0.124900818 -70.054246379,0.588130595 -69.2621331282,0.5928460528 -69.1880284905,0.8297056584 -69.852191529,1.059419657 -69.856170614,1.707674663 -67.998247843,1.749971823 -67.5883731345,1.9598459941 -66.875060588,1.222510478 -66.156344767,0.733031311 -64.080864218,1.647394104 -63.384834351,2.420576884 -64.047972169,2.47132314 -64.202975627,3.594717102 -64.58967037,4.118871155 -63.42540035,3.968363546 -62.931011923,3.563762919 -62.76621578,4.020711772 -61.567270875,4.248527324 -60.612626303,4.900580546 -60.739853679,5.202138367 -59.983104005,5.085943909 -60.148778646,4.513007304 -59.5292299,3.931905823 -60.000079712,2.694048564 -59.74968156,1.851309306 -59.24214148,1.377798157 -57.104494182,2.021453959 -56.4944124319,2.0374662082 -56.116802531,2.333088684 -54.978577434,2.543050029 -54.615292115,2.326267396</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BR</ogr:ISO2>
      <ogr:ISO3>BRA</ogr:ISO3>
      <ogr:ISONUM>76</ogr:ISONUM>
      <ogr:NAMEen>Brazil</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.63">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>113.99878991,4.601141669 115.1117252181,4.9900154729 115.6069422041,4.6450282549 114.586628052,4.021435242 113.99878991,4.601141669</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BN</ogr:ISO2>
      <ogr:ISO3>BRN</ogr:ISO3>
      <ogr:ISONUM>96</ogr:ISONUM>
      <ogr:NAMEen>Brunei</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.64">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>91.632887004,27.759443665 92.035859822,26.854847718 89.817287232,26.69620107 89.096504354,26.821413066 88.89233077,27.315543111 89.561488891,28.134640401 90.2255906943,28.3583989308 91.632887004,27.759443665</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BT</ogr:ISO2>
      <ogr:ISO3>BTN</ogr:ISO3>
      <ogr:ISONUM>64</ogr:ISONUM>
      <ogr:NAMEen>Bhutan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.65">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>25.259780721,-17.794106547 26.130270223,-19.501082459 27.698133179,-20.509082947 28.032893107,-21.577854919 29.038723186,-21.797893168 29.350073689,-22.186706645 28.338559204,-22.584615173 27.00417037,-23.645842387 26.849709513,-24.248131205 25.868374064,-24.748152364 25.587254272,-25.619520365 24.798620239,-25.829223327 23.006998332,-25.310805359 22.719367309,-25.984252625 21.687182251,-26.855207214 20.690757283,-26.891794128 20.84144576,-26.131323751 19.981446574,-24.752493184 19.978345988,-22.000671489 20.971980428,-22.000671489 20.975081014,-18.319345805 23.31147587,-18.009803975 23.592182251,-18.478199157 24.183050578,-18.029441019 25.259780721,-17.794106547</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>BW</ogr:ISO2>
      <ogr:ISO3>BWA</ogr:ISO3>
      <ogr:ISONUM>72</ogr:ISONUM>
      <ogr:NAMEen>Botswana</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.66">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>22.861064087,10.919153747 23.624014934,9.907768453 23.482318156,8.783392639 24.170328031,8.68932733 25.360032999,7.335574036 26.378007039,6.6532901 26.481049846,6.104951477 27.123801311,5.768744608 27.44130131,5.070725199 26.4625765337,5.0549382287 25.3956123053,5.3292613374 23.388370402,4.587266337 22.898374471,4.823582663 22.422641235,4.134787496 20.603114054,4.409731954 19.719550415,5.135966695 18.537090291,4.306069031 18.626387166,3.476868998 17.458913208,3.708276062 16.567701457,3.46438914 16.196664673,2.236453756 16.092381633,2.86328888 15.171300904,3.758970642 14.717271769,4.622018738 14.584773396,5.92341217 15.481049439,7.523262838 16.54868453,7.870011699 16.768619425,7.550237936 17.67977828,7.985198466 18.589283488,8.047881979 19.100570109,9.015264791 20.435165649,9.138125509 22.460468384,11.000828349 22.861064087,10.919153747</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CF</ogr:ISO2>
      <ogr:ISO3>CAF</ogr:ISO3>
      <ogr:ISONUM>140</ogr:ISONUM>
      <ogr:NAMEen>Central African Republic</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.67">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-66.843690129,-55.1779219139 -67.6118945404,-55.4766025293 -68.4994971943,-55.4959694704 -68.9697078382,-55.8982829182 -69.4795989852,-55.997252745 -69.8655199333,-55.7795137033 -70.3325811213,-55.5791390229 -70.6871350629,-55.0456365648 -69.5113207763,-55.0562101475 -68.6238718021,-55.0723490096 -66.843690129,-55.1779219139</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-73.1654244434,-53.5154244725 -71.4502270699,-53.9544929742 -72.2263327604,-54.1846769434 -73.1654244434,-53.5154244725</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-68.6276167765,-52.639571699 -68.6364837741,-54.7829713158 -68.641997851,-54.799167576 -68.6541354319,-54.8862445646 -70.75877845,-54.840590102 -71.725005663,-54.405450128 -70.5504334359,-54.012215763 -70.418992611,-53.011716396 -69.417565116,-52.451472416 -68.6276167765,-52.639571699</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-74.6751597742,-50.0026617768 -75.1569460369,-50.2674679989 -75.645387995,-49.2586301822 -75.5985833161,-48.1645324733 -75.0019970894,-48.0101735688 -74.9582310314,-48.9973278786 -74.6751597742,-50.0026617768</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-73.8917242027,-42.060203142 -73.2888344169,-41.932489977 -73.7703110695,-43.7077941156 -74.471668081,-43.6443667129 -73.8917242027,-42.060203142</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-67.193904175,-22.822223409 -67.362369345,-24.030366719 -68.572373007,-24.769856466 -68.330475627,-27.044963073 -68.801092896,-27.112762553 -69.653030559,-28.397852071 -70.042619181,-29.363064474 -70.591371216,-31.549597676 -70.172482057,-32.464942322 -69.83276119,-34.24323171 -70.227827515,-34.585329691 -70.380324667,-36.046015727 -71.043281616,-36.484335225 -71.18503007,-37.706069437 -70.873834595,-38.691435649 -71.41576534,-38.935348409 -71.955577353,-40.720355733 -72.148537151,-42.998717956 -71.659884807,-43.926309916 -72.047819784,-44.754786478 -71.311533977,-45.299456075 -71.798532675,-45.739945984 -71.687169963,-46.690068868 -72.543913534,-47.914800313 -72.295091512,-48.333276062 -73.586588908,-49.529998881 -73.177724976,-50.74945933 -72.302842978,-50.648896994 -72.450069133,-51.552666118 -71.917698528,-51.99005544 -69.952753866,-52.007418722 -68.4484404191,-52.3468881602 -69.442005989,-52.252129816 -70.856841601,-52.733982029 -71.034250455,-53.809747003 -73.199086067,-53.240817967 -73.9727083247,-52.7836799109 -74.6765001014,-51.6985930301 -75.0632138951,-50.4681482196 -74.347645637,-50.086114191 -74.628407356,-47.767754816 -73.7827113302,-46.8685544548 -74.890139512,-47.3345643262 -75.4307534253,-47.2545679606 -75.3668629008,-46.448458898 -74.9104289727,-45.4953391178 -74.4142491159,-44.4318127862 -73.8551737575,-44.5192910452 -73.9931477893,-45.7205330535 -74.310517304,-46.3954540527 -73.687855598,-46.322035415 -73.348255989,-44.957777602 -73.283599413,-44.174086196 -72.462554491,-41.985528253 -72.957264778,-41.483575128 -73.759946026,-41.748841349 -73.946904238,-40.972840598 -73.714182095,-39.978448175 -73.241566536,-39.489515883 -73.668080207,-37.719414972 -73.209055142,-37.16025156 -72.646595832,-35.566582941 -72.230580207,-35.116143488 -71.624663866,-33.541436456 -71.412464973,-32.369561456 -71.634632942,-30.2382138 -71.286610481,-29.91025156 -71.521962043,-28.940118097 -71.173939582,-28.360609633 -70.444813606,-25.344903253 -70.582834439,-24.524834894 -70.058694938,-21.433377482 -70.3947027461,-18.3377462069 -69.510088752,-17.506588198 -68.989608521,-18.946490987 -68.496356975,-19.458397725 -68.7755389,-20.089677022 -68.207537395,-21.284332784 -67.87634314,-22.833592224 -67.193904175,-22.822223409</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CL</ogr:ISO2>
      <ogr:ISO3>CHL</ogr:ISO3>
      <ogr:ISONUM>152</ogr:ISONUM>
      <ogr:NAMEen>Chile</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.68">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-5.522578085,10.42548879 -4.681079061,9.682071635 -3.202564657,9.908233541 -2.689210978,9.488724263 -2.506328084,8.209267477 -3.262509318,6.617142436 -2.843698697,5.149115302 -3.995757616,5.231675523 -5.851307746,5.029974677 -7.5406661241,4.3528445816 -7.446543336,5.845949198 -8.618719849,6.492834778 -8.48544633,7.5579894 -8.228976196,7.544295146 -7.865380818,9.409917705 -7.989662639,10.161990662 -6.959389608,10.185503439 -6.245841431,10.720742086 -6.015932983,10.189870097 -5.522578085,10.42548879</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CI</ogr:ISO2>
      <ogr:ISO3>CIV</ogr:ISO3>
      <ogr:ISONUM>384</ogr:ISONUM>
      <ogr:NAMEen>Ivory Coast</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.69">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>15.481049439,7.523262838 14.584773396,5.92341217 14.717271769,4.622018738 15.171300904,3.758970642 16.092381633,2.86328888 16.196664673,2.236453756 16.15904423,1.73480479 14.266963338,2.152427877 13.294567912,2.161057841 11.322078491,2.165760396 9.7995711595,2.341742255 9.919688347,3.228094794 9.618907097,3.960353908 8.971202019,4.100775458 8.594167514,4.815293687 8.855872437,5.847499492 10.119464559,6.99440623 10.602535848,7.058071595 11.31949467,6.437282613 12.805708862,8.831503397 12.862036173,9.382890931 13.982329549,11.276263733 14.593765096,11.496431173 14.669936157,12.167423808 14.179836873,12.385601705 14.0665556526,13.0750351902 14.4578984438,13.0826216418 14.6935040769,12.5368490974 15.135644165,11.530821838 15.065880981,10.793114929 15.681243937,9.991277568 14.181697225,9.978177593 13.947602987,9.637759094 15.183703247,8.479147644 15.481049439,7.523262838</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CM</ogr:ISO2>
      <ogr:ISO3>CMR</ogr:ISO3>
      <ogr:ISONUM>120</ogr:ISONUM>
      <ogr:NAMEen>Cameroon</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.70">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>27.44130131,5.070725199 28.404136596,4.27782786 29.457612345,4.669535217 30.839543498,3.490201518 30.707665243,2.462279765 31.2693446377,2.170394737 31.1276079405,1.8187516415 30.4783817597,1.2387726624 29.92828129,0.785017802 29.6887608019,-0.0986732303 29.6410151842,-0.4850430547 29.57793851,-1.3930817714 29.2212526473,-1.6863271024 28.8744457681,-2.4770641795 29.015365438,-2.720711365 29.2066786417,-3.3344242464 29.0963633095,-5.072655832 29.4987881383,-6.7075625339 30.1831990747,-7.3737126287 30.5698657966,-8.2217699874 28.893485601,-8.481407219 28.8001333273,-8.7357104912 28.5160606604,-9.3791892099 28.634923543,-10.519460144 28.35700769,-11.446948751 29.030351603,-12.376194356 29.799296915,-12.15408905 29.79764327,-13.424244079 29.168947795,-13.433855896 28.339747762,-12.450505066 27.638188517,-12.293615417 27.180128621,-11.569628601 26.697057333,-12.017456563 25.351971477,-11.646109721 25.278797648,-11.199935404 24.285473266,-11.381216329 23.9676076164,-10.8770496782 22.2377848658,-11.2542913211 22.3135312065,-10.3733030991 21.8542185417,-9.622541295 21.9400907528,-8.5046678436 21.7850451703,-7.2880929033 20.520620974,-7.2910901553 20.6115674262,-6.9206712009 19.5219148285,-7.006661305 19.3556307093,-8.0067101558 17.5443642728,-8.0894963807 16.3157818715,-5.8593347537 13.1838927169,-5.861165405 12.210541212,-5.763441665 12.444387248,-5.055090841 13.07370284,-4.635323181 13.358750041,-4.794796651 14.368559204,-4.278445739 14.831166626,-4.815053812 16.227463827,-3.28987559 16.231287883,-2.129016215 16.839726196,-1.262505798 17.749541463,-0.523429463 18.072415812,2.160024312 18.626387166,3.476868998 18.537090291,4.306069031 19.719550415,5.135966695 20.603114054,4.409731954 22.422641235,4.134787496 22.898374471,4.823582663 23.388370402,4.587266337 25.3956123053,5.3292613374 26.4625765337,5.0549382287 27.44130131,5.070725199</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CD</ogr:ISO2>
      <ogr:ISO3>COD</ogr:ISO3>
      <ogr:ISONUM>180</ogr:ISONUM>
      <ogr:NAMEen>Congo-Kinshasa</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.71">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>18.626387166,3.476868998 18.072415812,2.160024312 17.749541463,-0.523429463 16.839726196,-1.262505798 16.231287883,-2.129016215 16.227463827,-3.28987559 14.831166626,-4.815053812 14.368559204,-4.278445739 13.358750041,-4.794796651 13.07370284,-4.635323181 12.854284709,-4.403089295 12.009607691,-5.019630836 11.1140163041,-3.9368561899 11.944366089,-3.30320811 11.9007915951,-2.4526288205 12.966112508,-2.366417745 13.5385407334,-2.1680043779 14.0603219595,-2.2887277819 14.463127075,-1.548689881 14.498990519,-0.630916442 13.831227661,-0.2054127 14.468088013,0.913227031 14.183867635,1.380847066 13.250229533,1.221787008 13.294567912,2.161057841 14.266963338,2.152427877 16.15904423,1.73480479 16.196664673,2.236453756 16.567701457,3.46438914 17.458913208,3.708276062 18.626387166,3.476868998</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CG</ogr:ISO2>
      <ogr:ISO3>COG</ogr:ISO3>
      <ogr:ISONUM>178</ogr:ISONUM>
      <ogr:NAMEen>Congo-Brazzaville</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.72">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-71.3275065336,11.8499976907 -71.971080282,11.661924948 -72.907560588,10.452463888 -73.009724895,9.295376892 -72.386765503,8.338613587 -72.451309367,7.440218811 -72.080996053,7.066598206 -70.096621054,6.94443512 -69.443637655,6.122237244 -67.573984335,6.266233622 -67.865077677,4.512077128 -67.304646769,3.425709331 -67.838619345,2.886129863 -67.197624878,2.402025045 -66.875060588,1.222510478 -67.5883731345,1.9598459941 -67.998247843,1.749971823 -69.856170614,1.707674663 -69.852191529,1.059419657 -69.1880284905,0.8297056584 -69.2621331282,0.5928460528 -70.054246379,0.588130595 -70.073805908,-0.124900818 -69.399454305,-1.182717387 -69.964949504,-4.236484477 -70.73412736,-3.782041931 -70.050629028,-2.71513031 -70.992716228,-2.197435812 -72.396584026,-2.446516215 -73.197775432,-2.213558858 -73.636560018,-1.255167745 -74.344423788,-0.858602803 -74.824652873,-0.170479431 -75.283487915,-0.107020772 -76.311590536,0.458526103 -77.424390829,0.40829661 -77.673316203,0.819641012 -78.828684049,1.434312242 -78.333972984,2.647045418 -77.777943489,2.577704169 -77.031564908,3.92206452 -77.435170051,4.155218817 -77.343006965,6.543768622 -77.8958391508,7.2350980564 -77.1690059,7.935072326 -77.373524543,8.664740302 -76.947173632,8.545477606 -75.620632773,9.452853128 -75.509836392,10.58584219 -74.844372315,11.109669657 -74.362172004,10.775702216 -74.187489387,11.316961981 -73.292388476,11.294012762 -72.1680730902,12.1180267224 -72.0649861058,12.3518191415 -71.697255012,12.464300848 -71.3146369268,12.246213077 -71.3275065336,11.8499976907</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CO</ogr:ISO2>
      <ogr:ISO3>COL</ogr:ISO3>
      <ogr:ISONUM>170</ogr:ISONUM>
      <ogr:NAMEen>Colombia</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.73">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-83.644357877,10.92593008 -82.573597786,9.576198635 -82.829022176,9.602722473 -82.8976292589,8.0347480201 -83.739898241,8.623806057 -83.6298722,9.03534577 -84.678374804,9.651027736 -85.117827929,9.555446682 -85.874989387,10.355047919 -85.7017355659,11.0808801812 -83.644357877,10.92593008</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CR</ogr:ISO2>
      <ogr:ISO3>CRI</ogr:ISO3>
      <ogr:ISONUM>188</ogr:ISONUM>
      <ogr:NAMEen>Costa Rica</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.74">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-75.0950058107,19.8972259627 -75.232858853,19.900051174 -77.737212694,19.85569896 -77.082427538,20.465277411 -78.065541145,20.711655992 -78.766509569,21.639715887 -79.895375129,21.698553778 -80.450917121,22.068508205 -81.824452278,22.188910223 -81.877500935,22.679730389 -82.780669726,22.696112372 -83.415472437,22.186093371 -84.521351692,21.786566473 -84.078277148,22.666205145 -82.219349739,23.194240627 -80.62222246,23.089544989 -78.676136848,22.357001044 -77.760894335,21.813299872 -76.002186653,21.07807038 -75.708851692,20.690578518 -74.771839973,20.625799872 -74.267404752,20.068304755 -75.0950058107,19.8972259627</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CU</ogr:ISO2>
      <ogr:ISO3>CUB</ogr:ISO3>
      <ogr:ISONUM>192</ogr:ISONUM>
      <ogr:NAMEen>Cuba</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.75">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>33.0151933697,34.5714646106 32.5833285011,34.6800107274 32.3805991804,34.9248308397 32.5839461182,35.2086491387 33.0100160094,35.2310920057 33.0834078914,35.4335532331 33.6492417758,35.3809441976 34.4881741881,35.6620791231 33.9067213262,35.1557834091 33.9059634349,35.1551223885 34.0329940884,34.9345975373 33.6583107365,34.8004617348 33.5245574525,34.6204133646 33.0151933697,34.5714646106</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CY</ogr:ISO2>
      <ogr:ISO3>CYP</ogr:ISO3>
      <ogr:ISONUM>196</ogr:ISONUM>
      <ogr:NAMEen>Cyprus</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.76">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>14.8103927,50.858447164 16.5785977055,50.2845831544 18.3248863178,50.1823334108 18.833196249,49.510260722 16.945042766,48.604166158 14.982061808,49.007914124 14.69567102,48.589541728 13.815724731,48.766430156 12.797750692,49.327842917 12.510223022,50.388760071 14.8103927,50.858447164</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CZ</ogr:ISO2>
      <ogr:ISO3>CZE</ogr:ISO3>
      <ogr:ISONUM>203</ogr:ISONUM>
      <ogr:NAMEen>Czechia</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.77">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>43.240733269,11.487860419 42.923715454,10.99878713 41.7858764944,11.0902686194 41.7852981941,11.2833486151 42.379459269,12.46590688 43.117686394,12.707912502 43.377126498,12.004828192 42.754079623,11.707953192 43.240733269,11.487860419</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>DJ</ogr:ISO2>
      <ogr:ISO3>DJI</ogr:ISO3>
      <ogr:ISONUM>262</ogr:ISONUM>
      <ogr:NAMEen>Djibouti</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.78">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-71.776234504,18.03925202 -71.9078776579,18.490400409 -72.006122552,18.6014749709 -71.757435676,19.710109768 -71.018422004,19.935492255 -69.897938606,19.635972398 -69.608469205,19.093451239 -68.356190559,18.656561591 -68.849598762,18.374823309 -70.703846809,18.430121161 -71.417225715,17.604803778 -71.776234504,18.03925202</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>DO</ogr:ISO2>
      <ogr:ISO3>DOM</ogr:ISO3>
      <ogr:ISONUM>214</ogr:ISONUM>
      <ogr:NAMEen>Dominican Republic</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.79">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>8.6025104286,36.9395107635 8.349236695,36.448784078 8.236478719,34.647653708 7.479832398,33.893901265 7.750720255,33.207664083 9.045008179,32.07184194 9.519707885,30.228905335 9.826149129,29.128533224 9.835760945,26.504223125 9.40116215,26.113394267 10.032028035,24.856339213 11.567128133,24.266840312 11.968860717,23.517351176 9.723313029,22.193426819 7.482726278,20.87257721 5.837607055,19.478631287 4.22860966,19.142243551 3.308355754,18.981684876 3.216785116,19.79406423 1.89138798,20.231789449 1.146523885,21.101710511 -2.523226278,23.500995585 -4.821613118,24.995064596 -8.6829954779,27.284959249 -8.6828343985,27.6761318694 -8.682385213,28.665899964 -7.619452678,29.389421692 -5.7561563712,29.6140708361 -4.3723676021,30.5086413535 -3.6455290567,30.7113174864 -3.659506721,31.6478209968 -2.516146606,32.132200013 -1.249557251,32.081660462 -1.047502401,32.517008566 -1.674234172,33.237972311 -1.769525513,34.741343079 -2.222564257,35.089300848 1.044769727,36.486883856 2.933116082,36.80857982 4.787119988,36.895412502 5.235850457,36.650946356 7.383474155,37.082993882 8.6025104286,36.9395107635</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>DZ</ogr:ISO2>
      <ogr:ISO3>DZA</ogr:ISO3>
      <ogr:ISONUM>12</ogr:ISONUM>
      <ogr:NAMEen>Algeria</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.80">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-75.283487915,-0.107020772 -75.560034343,-1.502594502 -76.684591025,-2.573640239 -77.849016073,-2.980643819 -78.361723796,-3.408524678 -78.672660889,-4.550987243 -79.063928996,-5.011372579 -80.481077637,-3.998772888 -80.3407286664,-3.3934976535 -79.953195767,-3.197442316 -79.9815280299,-2.7334027788 -80.320546028,-2.710625909 -80.74497919,-2.102914608 -80.916180218,-1.065524768 -80.066458957,0.052209779 -80.046213345,0.839667059 -78.991688606,1.119696356 -78.828684049,1.434312242 -77.673316203,0.819641012 -77.424390829,0.40829661 -76.311590536,0.458526103 -75.283487915,-0.107020772</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>EC</ogr:ISO2>
      <ogr:ISO3>ECU</ogr:ISO3>
      <ogr:ISONUM>218</ogr:ISONUM>
      <ogr:NAMEen>Ecuador</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.81">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>34.2002694411,31.3142666891 34.248350857,31.211448958 34.8867293625,29.490057684 34.078461134,27.80068594 33.239431186,28.556586005 32.570485873,29.955755927 32.337657097,29.599920966 32.868907097,28.578924872 33.512543165,27.959051825 34.014008009,26.611639716 35.513926629,23.977118231 35.695305231,22.932126497 36.883636915,21.995713609 33.1811382663,21.9954074694 28.290345093,21.994782613 24.981244751,21.995351054 24.981244751,25.205439352 24.981244751,29.181372376 24.688342732,30.144155986 25.150889519,31.65648021 27.342295769,31.368231512 29.028086785,30.827053127 30.36215254,31.508734442 31.917979363,31.523993231 32.4809028022,31.1999018197 33.133311394,31.045558986 34.2002694411,31.3142666891</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>EG</ogr:ISO2>
      <ogr:ISO3>EGY</ogr:ISO3>
      <ogr:ISONUM>818</ogr:ISONUM>
      <ogr:NAMEen>Egypt</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.82">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>43.117686394,12.707912502 42.379459269,12.46590688 40.833197062,14.105961812 39.075474894,14.637402242 38.426832316,14.417183126 37.891464478,14.879532166 37.564972778,14.116684672 37.293774862,14.457439067 36.526379842,14.263523254 36.423647095,15.111507671 36.944028768,16.252859192 37.000459432,17.072602437 38.209687948,17.522290751 38.601573113,18.004828192 39.235606316,16.108710028 39.718272332,15.263902085 41.156097852,14.641587632 41.676524285,13.940252997 43.117686394,12.707912502</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>ER</ogr:ISO2>
      <ogr:ISO3>ERI</ogr:ISO3>
      <ogr:ISONUM>232</ogr:ISONUM>
      <ogr:NAMEen>Eritrea</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.83">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>28.019053582,59.481756903 28.1800455088,59.3566509454 27.8426052139,59.1616595139 27.7152305574,58.9957844089 27.2703649905,58.7958158031 27.3380936388,58.1430650292 27.6414384538,58.0020489524 27.352934611,57.52760081 25.263501424,58.075138449 24.3061587342,57.8681862559 23.5526197001,58.3858951168 23.470876498,59.212144273 25.72535241,59.665838934 28.019053582,59.481756903</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>EE</ogr:ISO2>
      <ogr:ISO3>EST</ogr:ISO3>
      <ogr:ISONUM>233</ogr:ISONUM>
      <ogr:NAMEen>Estonia</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.84">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>42.379459269,12.46590688 41.7852981941,11.2833486151 41.7858764944,11.0902686194 42.923715454,10.99878713 42.647246541,10.632220358 43.419034057,9.41301829 44.023855021,8.985525004 46.979230184,7.996567281 47.979169149,7.996567281 46.423915242,6.496736348 44.941525106,4.911484273 43.96897465,4.953962301 41.885019165,3.977226054 40.763743937,4.28493337 39.848450969,3.867284444 39.536325317,3.40501292 38.10189091,3.612648824 36.844086548,4.432237041 35.920835409,4.619331563 35.809110962,5.309108581 35.098663371,5.622474467 34.7335177,6.637606303 33.716060425,7.657156474 33.0512948,7.801127014 33.174078003,8.4044752 33.970773559,8.445377096 34.070697863,9.454592111 34.587066691,10.87928538 34.950662069,10.869182638 35.048227173,11.77137563 35.616874633,12.575150859 36.099429159,12.695660299 36.526379842,14.263523254 37.293774862,14.457439067 37.564972778,14.116684672 37.891464478,14.879532166 38.426832316,14.417183126 39.075474894,14.637402242 40.833197062,14.105961812 42.379459269,12.46590688</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>ET</ogr:ISO2>
      <ogr:ISO3>ETH</ogr:ISO3>
      <ogr:ISONUM>231</ogr:ISONUM>
      <ogr:NAMEen>Ethiopia</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.85">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>28.954077189,69.027260641 28.663758993,68.204003398 30.00941329,67.685843812 29.089159383,66.837549337 29.900169311,66.108058981 29.588147013,64.991434632 30.558475382,64.219698792 29.980784546,63.741536764 31.56952478,62.905928854 29.203157593,61.245900981 27.807871941,60.553045966 23.247080925,59.922430731 21.379649285,60.647040106 21.226735873,62.858465887 23.372813347,63.900620835 25.351817254,65.484116929 24.16309655,65.822699286 23.498854614,67.882162578 20.62316451,69.036355693 21.5785150411,69.1261383161 24.860942016,68.563412984 26.031981649,69.696677145 27.897294149,70.070685324 29.344544311,69.464391582 28.954077189,69.027260641</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>FI</ogr:ISO2>
      <ogr:ISO3>FIN</ogr:ISO3>
      <ogr:ISONUM>246</ogr:ISONUM>
      <ogr:NAMEen>Finland</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.86">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>179.9888979356,-16.1737936533 179.9958605798,-16.7109442262 178.8636084213,-17.0587167201 178.6021970337,-16.66250139 179.9888979356,-16.1737936533</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>178.272715691,-17.351739191 178.6939175738,-17.7043503911 178.7654375502,-18.1578145149 178.3861250541,-18.4084317479 177.7593361195,-18.3718810641 177.2763311399,-18.0911977729 177.2276707772,-17.620102069 177.5761763198,-17.3029781591 178.272715691,-17.351739191</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>FJ</ogr:ISO2>
      <ogr:ISO3>FJI</ogr:ISO3>
      <ogr:ISONUM>242</ogr:ISONUM>
      <ogr:NAMEen>Fiji</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.87">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-59.2002944476,-51.3165537325 -60.6898708844,-52.2600741698 -60.2482799182,-51.0285129026 -59.2002944476,-51.3165537325</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-58.7825450682,-51.320631076 -57.4890258905,-51.39430623 -57.8315574331,-51.8373545719 -59.1395692115,-52.2127828999 -60.0192251877,-52.2197044851 -58.7825450682,-51.320631076</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>FK</ogr:ISO2>
      <ogr:ISO3>FLK</ogr:ISO3>
      <ogr:ISONUM>238</ogr:ISONUM>
      <ogr:NAMEen>Falkland Islands</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.88">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>13.294567912,2.161057841 13.250229533,1.221787008 14.183867635,1.380847066 14.468088013,0.913227031 13.831227661,-0.2054127 14.498990519,-0.630916442 14.463127075,-1.548689881 14.0603219595,-2.2887277819 13.5385407334,-2.1680043779 12.966112508,-2.366417745 11.9007915951,-2.4526288205 11.944366089,-3.30320811 11.1140163041,-3.9368561899 9.902437516,-2.700431046 9.03003991,-1.299086196 9.315928582,0.626166083 9.8043711812,0.9983539399 11.336341187,0.999164937 11.322078491,2.165760396 13.294567912,2.161057841</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GA</ogr:ISO2>
      <ogr:ISO3>GAB</ogr:ISO3>
      <ogr:ISONUM>266</ogr:ISONUM>
      <ogr:NAMEen>Gabon</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.89">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-6.269886848,54.097927151 -7.8771410548,54.5176808423 -7.24710039,55.069322007 -6.100982226,55.212388414 -5.536610481,54.657456773 -6.269886848,54.097927151</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-3.347889778,58.652044989 -4.077626106,57.943060614 -1.759348111,57.473578192 -3.178374804,56.058091539 -1.630848762,55.585109768 0.329844597,53.086493231 1.771169467,52.485907294 0.977061394,51.824611721 1.357188347,51.131008205 0.271006707,50.747381903 -1.02074134,50.84365469 -3.494862434,50.548163153 -3.64561927,50.226019598 -5.437977668,50.194322007 -3.539173957,51.39850495 -5.288929817,51.916937567 -4.197132942,52.279282945 -4.151519335,53.228094794 -3.185210741,53.377264716 -2.795969205,54.12518952 -5.170806444,55.008693752 -4.617787239,55.495591539 -5.5328783462,56.0701775276 -6.183059188,56.9117629111 -5.807362434,57.84393952 -4.988189257,58.628322658 -3.347889778,58.652044989</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GB</ogr:ISO2>
      <ogr:ISO3>GBR</ogr:ISO3>
      <ogr:ISONUM>826</ogr:ISONUM>
      <ogr:NAMEen>United Kingdom</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.90">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>46.430891561,41.89044159 46.496779012,41.04483429 45.002399944,41.290452373 43.4404281,41.106587626 42.819949178,41.572347311 41.520762566,41.5142276065 41.500173373,42.64057038 39.9859763554,43.3889896097 40.651916138,43.538971456 42.422867473,43.228990377 43.939725789,42.552209982 44.859359579,42.75950999 46.430891561,41.89044159</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GE</ogr:ISO2>
      <ogr:ISO3>GEO</ogr:ISO3>
      <ogr:ISONUM>268</ogr:ISONUM>
      <ogr:NAMEen>Georgia</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.91">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-0.166109171,11.134980367 0.3965955,10.283223572 0.230197388,9.575747376 0.645675903,7.323585104 0.51927535,6.832245585 1.185394727,6.100490627 -2.090565559,4.737127997 -3.119618293,5.091335354 -3.115305142,5.107814846 -2.843698697,5.149115302 -3.262509318,6.617142436 -2.506328084,8.209267477 -2.689210978,9.488724263 -2.750705933,10.985842184 -0.695999309,10.994032898 -0.166109171,11.134980367</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GH</ogr:ISO2>
      <ogr:ISO3>GHA</ogr:ISO3>
      <ogr:ISONUM>288</ogr:ISONUM>
      <ogr:NAMEen>Ghana</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.92">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-11.388421591,12.403895162 -10.4995113795,12.0438540216 -9.2862803666,12.3313548474 -8.847233033,11.657945862 -8.375323852,11.367653504 -7.989662639,10.161990662 -7.865380818,9.409917705 -8.228976196,7.544295146 -8.48544633,7.5579894 -9.125407268,7.190208232 -9.499131226,8.343471172 -10.28223588,8.484625346 -11.272666382,9.996005961 -12.508327393,9.860381165 -13.301096158,9.041489976 -13.594309049,9.774237372 -15.020985481,10.9674746765 -14.686773235,11.510719706 -13.729932414,11.709829 -13.7860969802,12.0269454498 -14.004229347,12.2165313603 -13.7581500333,12.3880417559 -13.728278768,12.673387757 -12.36092037,12.305606588 -11.388421591,12.403895162</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GN</ogr:ISO2>
      <ogr:ISO3>GIN</ogr:ISO3>
      <ogr:ISONUM>324</ogr:ISONUM>
      <ogr:NAMEen>Guinea</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.93">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-16.753651496,13.065008856 -16.5613991701,13.5869141589 -15.097704224,13.819984436 -14.2394964658,13.5829768153 -13.9662047098,13.4090589101 -14.30595433,13.3053416455 -15.137650106,13.589972636 -15.6552237486,13.470056408 -16.0972412049,13.1305108817 -16.753651496,13.065008856</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GM</ogr:ISO2>
      <ogr:ISO3>GMB</ogr:ISO3>
      <ogr:ISONUM>270</ogr:ISONUM>
      <ogr:NAMEen>The Gambia</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.94">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-15.020985481,10.9674746765 -15.551380989,11.733140367 -16.7284367771,12.332530837 -15.195114299,12.6794339 -13.728278768,12.673387757 -13.7581500333,12.3880417559 -14.004229347,12.2165313603 -13.7860969802,12.0269454498 -13.729932414,11.709829 -14.686773235,11.510719706 -15.020985481,10.9674746765</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GW</ogr:ISO2>
      <ogr:ISO3>GNB</ogr:ISO3>
      <ogr:ISONUM>624</ogr:ISONUM>
      <ogr:NAMEen>Guinea-Bissau</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.95">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>23.9013778,35.527167059 25.766368035,35.335679429 26.24097741,35.03904857 24.738536004,34.931626695 23.51823978,35.294134833 23.9013778,35.527167059</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>23.3945924328,39.0202150419 24.3059331441,38.5876067674 24.2567517164,38.2876940665 23.1246102897,38.8061357936 23.3945924328,39.0202150419</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>20.9645643201,40.841981383 22.916977986,41.335772604 24.510162395,41.561650289 25.28572229,41.239396057 26.333358602,41.713036397 26.636595907,41.378457337 26.0439559255,40.73847077 25.039073113,41.006048895 23.6628395977,40.6933797366 23.7052774311,40.3571650196 23.328753982,40.2249816872 22.821625196,40.502142645 22.571299675,40.054266669 23.343760613,39.17963288 22.769541863,38.784816799 23.9943179478,38.210878804 23.1240659958,37.3485975868 23.3695043854,36.6135093274 23.196055535,36.432521877 22.153168165,37.021185614 21.87403405,36.72671133 21.122080925,37.837388414 21.987640821,38.410589911 21.155609571,38.303900458 19.999847852,39.693508205 21.0212289216,40.6872807501 20.9645643201,40.841981383</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GR</ogr:ISO2>
      <ogr:ISO3>GRC</ogr:ISO3>
      <ogr:ISONUM>300</ogr:ISONUM>
      <ogr:NAMEen>Greece</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.96">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-52.728098111,69.928656317 -52.14159095,69.477280992 -53.2227918485,69.2945716946 -54.7423723185,69.6443144053 -54.453033007,70.313299872 -52.728098111,69.928656317</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-25.4453183621,70.6176588016 -27.3220428713,70.2035582498 -27.7720348468,70.406161237 -27.6379925077,70.6610005766 -25.4074525974,71.0080309779 -24.5850077886,70.9120118763 -24.3579793257,70.5151144212 -25.4453183621,70.6176588016</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-32.207875129,83.61347077 -21.339507616,82.626288153 -21.388417121,82.083441473 -21.256825325,81.517482815 -17.505930142,81.388169664 -15.792713996,81.83201732 -13.5405579234,81.2086793106 -15.789173957,80.404689846 -19.076726099,80.275736117 -18.955189582,79.148993231 -19.0567168931,78.1131913784 -18.324452278,77.208482164 -21.704497851,76.255601304 -19.937733528,76.25796133 -19.427235481,75.225531317 -21.771636523,74.438706773 -20.543283658,73.449042059 -22.314076301,73.250433661 -23.987782356,73.597398179 -26.150624153,73.240871486 -24.546376106,72.423407294 -21.749867317,71.490179755 -21.476796028,70.544867255 -23.345448371,70.440578518 -24.264881965,71.081366278 -25.580799934,71.188544012 -27.920887825,70.881293036 -28.232899543,70.372015692 -27.283680793,69.992010809 -25.305287239,70.413234768 -22.371652799,70.115057684 -26.285389778,68.69554271 -30.008168098,68.126044012 -31.995594856,68.050360419 -33.948068814,66.752142645 -36.073801236,65.935492255 -38.121449348,65.815863348 -41.057118293,65.099758205 -40.513295051,63.726019598 -42.426014778,62.838039455 -43.138172981,60.080755927 -44.515492317,60.038804429 -45.6330221165,60.6519825778 -47.0464899092,60.9001607363 -48.640614387,61.238959052 -51.056304491,63.184759833 -52.161476679,64.256348502 -53.2392472,65.686183986 -53.964914517,67.077704169 -52.616444465,68.525946356 -51.148833788,68.563910223 -50.9622966118,69.7853513301 -54.577504036,70.714178778 -53.8776959431,70.9849733462 -52.4222895608,70.7718358939 -52.6886996941,71.4267579154 -54.081613736,71.717352606 -55.904530403,71.682033596 -56.2745739393,72.7039545354 -56.0305312812,73.257144468 -56.7923383305,74.0794451977 -57.7690046067,74.8701301868 -59.8178492352,75.9064786153 -63.476918098,76.376898505 -68.432525194,76.079413153 -70.40746009,76.797796942 -71.2968307162,77.695896942 -72.895171679,78.153957424 -72.590199348,78.521226304 -67.2635027158,78.9890203036 -66.0285393696,79.3554882367 -68.6447398652,79.8029113481 -66.8240503703,80.1370100677 -61.0006710586,81.4897374294 -54.440744595,82.372707424 -50.510243293,81.789455471 -51.107248502,82.509914455 -45.156076627,81.789862372 -43.727202929,82.406887111 -32.207875129,83.61347077</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GL</ogr:ISO2>
      <ogr:ISO3>GRL</ogr:ISO3>
      <ogr:ISONUM>304</ogr:ISONUM>
      <ogr:NAMEen>Greenland</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.97">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-89.160496175,17.81431427 -89.234135092,15.95494456 -88.6941161154,15.8429139169 -88.220936653,15.725653387 -89.231447917,14.86731069 -89.36162085,14.415477804 -90.092981728,13.7289030479 -91.316461252,13.955679359 -92.246245898,14.546291408 -92.204651449,15.289507141 -91.723776409,16.06878774 -90.485738282,16.070699768 -90.379853272,16.367270813 -91.430771037,17.254968567 -90.990901246,17.801963603 -89.160496175,17.81431427</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GT</ogr:ISO2>
      <ogr:ISO3>GTM</ogr:ISO3>
      <ogr:ISONUM>320</ogr:ISONUM>
      <ogr:NAMEen>Guatemala</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.98">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-57.247670051,5.484930731 -58.067691203,4.151143087 -56.4944124319,2.0374662082 -57.104494182,2.021453959 -59.24214148,1.377798157 -59.74968156,1.851309306 -60.000079712,2.694048564 -59.5292299,3.931905823 -60.148778646,4.513007304 -59.983104005,5.085943909 -60.739853679,5.202138367 -61.379607911,5.905299581 -61.129829875,6.715844421 -60.292335775,7.105252177 -60.503278972,7.820867412 -59.815594849,8.287763977 -60.020985481,8.558010158 -59.16515052,8.05874258 -58.067863405,6.821702861 -57.167307095,6.085109768 -57.247670051,5.484930731</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>GY</ogr:ISO2>
      <ogr:ISO3>GUY</ogr:ISO3>
      <ogr:ISONUM>328</ogr:ISONUM>
      <ogr:NAMEen>Guyana</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.99">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-83.1304444725,14.9970120213 -84.482693848,14.61947052 -85.008517904,14.5113094451 -85.824162354,13.847683004 -86.727233847,13.768256327 -86.701860718,13.314201355 -87.314035611,12.981553453 -87.817168749,13.406561591 -87.703608358,13.814997661 -88.496815755,13.851197002 -89.36162085,14.415477804 -89.231447917,14.86731069 -88.220936653,15.725653387 -87.722157356,15.922919012 -86.338286913,15.78139883 -85.91917884,16.003729559 -84.294638383,15.811010146 -84.082508918,15.360093492 -83.1304444725,14.9970120213</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>HN</ogr:ISO2>
      <ogr:ISO3>HND</ogr:ISO3>
      <ogr:ISONUM>340</ogr:ISONUM>
      <ogr:NAMEen>Honduras</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.100">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>17.653330925,42.890936591 18.437354777,42.559212138 18.496429884,42.416327216 17.653330925,42.890936591</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>16.515301554,46.50171051 17.34532841,45.955697327 18.901305786,45.931202698 19.01582076,44.865634664 16.924372193,45.284523825 16.0143286918,45.0689690795 15.9833981709,44.5932791617 17.0680060084,43.5347114139 17.580658399,42.942084052 15.931162957,43.676499742 15.110362175,44.264349677 14.5430529039,45.1941602204 14.2437200969,45.2771217887 14.0808634866,44.8210378706 13.8959604187,44.8628054691 13.589528842,45.488836981 14.4520942552,45.598722106 15.3608683482,45.4768970263 15.409000313,45.8048974331 15.6345859905,45.9452217611 15.7021412095,46.2256765525 16.515301554,46.50171051</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>HR</ogr:ISO2>
      <ogr:ISO3>HRV</ogr:ISO3>
      <ogr:ISONUM>191</ogr:ISONUM>
      <ogr:NAMEen>Croatia</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.101">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-71.757435676,19.710109768 -72.006122552,18.6014749709 -71.9078776579,18.490400409 -71.776234504,18.03925202 -72.071766731,18.237534898 -73.646311002,18.258734442 -74.159982877,18.659165757 -73.1319747531,18.4910551162 -72.761092642,18.8797286218 -73.167103645,19.93768952 -71.757435676,19.710109768</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>HT</ogr:ISO2>
      <ogr:ISO3>HTI</ogr:ISO3>
      <ogr:ISONUM>332</ogr:ISONUM>
      <ogr:NAMEen>Haiti</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.102">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>22.132839803,48.404798483 22.877600546,47.946738587 21.988869263,47.492941997 21.134864542,46.27852 20.242825969,46.108091126 18.901305786,45.931202698 17.34532841,45.955697327 16.515301554,46.50171051 16.094035278,46.862773743 17.14833785,48.005443014 17.825712524,47.750006409 19.884294881,48.12962148 20.481674439,48.526083069 22.132839803,48.404798483</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>HU</ogr:ISO2>
      <ogr:ISO3>HUN</ogr:ISO3>
      <ogr:ISONUM>348</ogr:ISONUM>
      <ogr:NAMEen>Hungary</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.103">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>120.011729363,-9.357598566 120.9045030197,-9.5659590358 121.3781656926,-9.9768628434 120.6592638547,-10.1538118716 119.93157255,-9.8724788681 118.941579623,-9.570489191 120.011729363,-9.357598566</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>125.061615431,-9.485772394 124.418467644,-10.16383229 123.1589178782,-10.5342761419 122.9888335432,-9.9395229967 123.6361778499,-9.443525747 124.2663267197,-9.4799588898 124.4749225128,-8.9708519321 124.8711070826,-8.8668875148 125.061615431,-9.485772394</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>116.8220393006,-8.3094082173 116.5878729866,-8.8437389181 116.0597964755,-8.7470376448 116.2425350082,-8.2715223954 116.8220393006,-8.3094082173</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>117.971202019,-8.100355727 118.988291863,-8.309014581 119.041514519,-8.629815363 118.3240530087,-8.6652097526 117.4530050853,-8.8282260237 116.9768120581,-8.7361759482 117.1429527274,-8.2968667333 117.971202019,-8.100355727</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>124.0396213573,-7.9576655248 124.0382250872,-8.1698311081 122.9923471708,-8.454941538 122.80738366,-8.610935154 121.4523199097,-8.9854390002 119.919932488,-8.870782159 119.7413577617,-8.4218961518 120.212901238,-8.29273854 121.5454394141,-8.3556194866 124.0396213573,-7.9576655248</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>115.4945819273,-8.1509154603 115.904171452,-8.4326059926 115.5349949521,-8.6462177799 115.0756822696,-8.5339159711 114.7455164489,-8.3238220928 114.761840929,-8.1663034842 115.4945819273,-8.1509154603</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>138.524683893,-8.1540021443 137.4247996908,-8.4592834492 137.2308023723,-7.7657635599 137.7258830141,-7.2838068747 138.5411519578,-7.1296386173 138.8036047339,-7.5932902226 138.524683893,-8.1540021443</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>115.0004305672,-6.8905084416 114.6602269022,-7.1967395664 113.548984206,-7.233778154 113.0419858155,-6.907166788 115.0004305672,-6.8905084416</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>106.1591903,-6.009535415 107.3527192309,-6.082081685 108.4475821574,-6.3697732532 108.9999301014,-6.7998858712 110.472422722,-6.946384373 111.045415981,-6.5680611691 112.603770379,-6.904554946 113.2223920978,-7.612214994 114.467295769,-7.830987238 114.358653191,-8.409112238 114.597178582,-8.775567316 113.19792728,-8.2772763 112.672699415,-8.447035415 110.476735873,-8.111911717 109.2532341519,-7.729518572 108.326829456,-7.817471295 106.522662137,-7.410957331 106.537149257,-6.982961613 105.453623894,-6.808770441 105.3405580905,-6.4860698599 106.1591903,-6.009535415</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>134.581228061,-5.424248956 135.1326797359,-5.289621535 135.1968436142,-6.1406059336 135.1053809672,-6.6571383156 134.4078538016,-6.8193528947 134.4969495579,-6.1396887671 134.581228061,-5.424248956</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>127.0728399293,-3.1849267554 127.243418816,-3.606052342 126.742185315,-3.859378356 126.1148511258,-3.7562365395 125.991742403,-3.24819134 126.5009165999,-3.011460149 127.0728399293,-3.1849267554</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>129.1027576391,-2.8556457014 131.1018798655,-3.3835850213 130.841563347,-3.865004165 129.9073022644,-3.5322755978 129.0251339031,-3.403574328 128.1294097718,-3.43728767 127.7908118326,-2.9452356455 129.1027576391,-2.8556457014</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>107.848155144,-2.549899998 108.2352418629,-2.7201736024 108.2964344173,-3.0398468874 107.9073488446,-3.2105936749 107.4428729183,-3.05084923 107.4312590983,-2.6685683112 107.848155144,-2.549899998</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>124.529551629,-1.635674738 127.2127486716,-1.606493649 126.9386061434,-2.0461953028 124.406016472,-2.004082941 124.529551629,-1.635674738</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>135.477305535,-1.58993906 135.3121883572,-1.1260187943 136.0998124881,-1.3019478166 136.9971347938,-1.2391152269 136.9849510559,-1.6740080772 136.1701774255,-1.7051194852 135.477305535,-1.58993906</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>105.875743035,-1.489190363 106.4462602505,-2.3156317222 106.9252860531,-2.6152677606 106.8520812985,-2.8958004683 106.3234355671,-3.0630666178 106.1537256181,-2.7316453828 105.8074532962,-2.196508879 105.1421768827,-2.0965900716 105.0320983398,-1.646238679 105.349864129,-1.648695571 105.875743035,-1.489190363</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>98.8634406359,-0.7890127964 99.2678556631,-1.3143477613 99.4530374178,-1.7277054524 99.1354670139,-1.8096315617 98.7718058602,-1.514800823 98.4150010684,-1.0347139752 98.5057997463,-0.7272988787 98.8634406359,-0.7890127964</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>140.974457227,-2.600518488 140.977161906,-6.896632182 140.976980014,-9.106133722 139.93238366,-8.108575128 138.83855228,-8.138360284 139.093028191,-7.559991144 138.074880405,-5.419610284 135.970469597,-4.51962656 135.227793816,-4.461195571 133.8914561048,-3.8056091987 132.969411655,-4.111993097 132.931813998,-3.554131769 132.20191491,-2.676446222 132.9115392319,-2.3585273769 132.073415561,-2.105157159 131.811045769,-1.520440363 130.960297071,-1.446221613 131.243011915,-0.819431248 132.709157748,-0.360039972 133.977224155,-0.723239842 134.4638778,-2.862074477 135.470469597,-3.36305104 136.403819207,-2.219659113 137.226328972,-2.074395441 137.794444207,-1.48414479 139.864756707,-2.372002863 140.974457227,-2.600518488</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>97.4136980152,1.7200491332 97.939219597,0.986070054 97.704112175,0.572739976 96.9947557273,1.5159783697 97.4136980152,1.7200491332</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>125.061696811,1.674546617 125.3887999672,1.4091246306 124.321787957,0.398871161 123.074229363,0.516302802 120.7618138113,0.2892154189 120.4542678694,-0.3474546955 120.675954623,-1.394707941 121.500661655,-0.85930755 123.2593806208,-0.5054612683 124.0681040548,-0.5894456828 123.6607047191,-1.0248249187 122.3695523702,-1.3112195353 121.692149285,-1.908135675 122.312510613,-2.926853123 122.200531446,-3.556573175 122.907074415,-4.195977472 121.484629754,-4.656426691 121.62769616,-4.087090753 120.893809441,-3.53915781 121.080414259,-2.759047133 120.387868686,-3.21461354 120.3232528,-5.509535415 119.352793816,-5.355645441 119.626800977,-4.314548435 119.297618035,-3.427911066 118.764170769,-3.090915623 119.336436394,-1.970147394 119.328379754,-1.214450779 119.733653191,-0.633884373 120.062836134,0.742865302 120.3427084667,1.0843454301 120.9091903,1.353664455 121.480723504,1.120917059 123.7805209633,0.9581424688 125.061696811,1.674546617</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>128.1711790565,1.9159206868 127.8601626426,1.1588421193 128.7671442768,1.6418114367 129.1040057498,1.3898983414 128.2599383365,0.6879450699 129.4004083518,0.5665038449 129.2594276753,0.0887002723 128.2364263815,0.0300477703 128.6362681974,-0.6959794658 128.4181497387,-1.0724876392 127.4610034348,-0.3434792186 127.2098815755,0.4221962287 127.2107636389,1.1795134837 127.6571492473,2.2322579293 128.1711790565,1.9159206868</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>117.567149285,4.159654039 117.446543816,3.434759833 118.091481967,2.262030341 117.862559441,1.885931708 119.0029403,0.962469794 117.81128991,0.811753648 117.441416863,-0.525160415 116.379567905,-1.765313409 116.603282097,-2.224216404 115.967946811,-3.608819269 114.624766472,-4.170505467 114.5350377453,-3.7257150697 113.632497592,-3.45680104 113.1191597762,-3.2380021703 112.618011915,-3.423760675 111.822032097,-3.545098566 111.3476283274,-3.0434641002 110.263194207,-3.002862238 109.922699415,-1.103610935 109.273203972,-0.853610935 109.300466342,0.010484117 108.855479363,0.83222077 109.095957879,1.560614325 109.645274285,2.083238023 109.84283492,1.403274638 110.553902629,0.851370341 111.823075806,1.008466695 112.1800566,1.449034119 113.023415975,1.537013244 113.649527629,1.233259176 114.500638469,1.436037496 114.778761027,2.247202454 115.464093873,3.030823873 115.844122355,4.38921641 117.567149285,4.159654039</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>95.50269616,5.605129299 96.126231316,5.281805731 97.496836785,5.251898505 98.305674675,4.080308335 99.750743035,3.180487372 100.561045769,2.156805731 101.050303582,2.291489976 102.118174675,1.386542059 102.4638778,0.774115302 103.760020379,0.239488023 103.345550977,-0.695896092 104.377207879,-1.031670831 104.883311394,-2.28492604 105.62378991,-2.401788019 106.07300866,-3.255547784 105.782562696,-5.828545831 105.5211916841,-5.8892379744 105.1168532427,-5.5606868029 104.54175866,-5.841892185 103.692067905,-4.951918227 102.312510613,-3.991469008 101.104828321,-2.587090753 100.301442905,-0.8163388 99.610850457,0.098578192 99.13933353,0.273749091 98.535166863,1.936468817 97.658213738,2.411566473 97.602712436,2.866197007 95.426280144,4.827337958 95.0874460499,5.3899706436 95.50269616,5.605129299</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>ID</ogr:ISO2>
      <ogr:ISO3>IDN</ogr:ISO3>
      <ogr:ISONUM>360</ogr:ISONUM>
      <ogr:NAMEen>Indonesia</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.104">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>92.7883808127,13.3138525463 93.0652817296,13.9513424516 93.3370677793,13.5463446117 92.990570509,12.519232489 92.7172711563,11.3007962104 92.560313347,11.741359768 92.5414591913,12.1822966338 92.7883808127,13.3138525463</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>80.996016887,30.1969693 80.476151978,29.806140442 80.036385539,28.837026469 82.752137085,27.494963684 84.577038615,27.32903066 84.640238892,27.028377177 85.82161381,26.571712545 87.326224813,26.353327942 88.074189494,26.453941955 88.118217814,27.860884501 88.610487508,28.10583079 88.89233077,27.315543111 89.096504354,26.821413066 89.817287232,26.69620107 92.035859822,26.854847718 91.632887004,27.759443665 92.628485148,27.915764873 93.446213013,28.67189443 94.630430135,29.319451803 95.281553182,29.052672221 96.14196578,29.368466899 97.323495728,28.217477723 96.758879028,27.341743063 96.142585897,27.257510478 95.040637655,26.475594381 95.15122522,26.049935608 94.099713176,23.842628479 93.302965942,24.041143494 93.374899536,23.129726257 92.978954712,21.995351054 92.57587854,21.977574362 92.150788208,23.731653341 91.586068156,22.944466248 91.140824015,23.612099915 92.107586711,24.405979106 92.001753377,25.182960104 90.364644003,25.14999054 89.79501469,25.374162903 89.83439213,25.931751608 88.461142619,26.45389028 88.0743962,25.908135478 88.924163452,25.167870585 88.021789592,24.645602722 88.74980717,24.223251242 88.540104208,23.649952901 88.954704224,23.183805644 89.1214720516,21.5961373196 88.249278191,21.558294989 88.045146682,21.8664491806 86.837250196,21.174709377 86.99488366,20.670721747 86.2685653,19.91034577 85.336680535,19.575181382 84.077403191,18.271551825 82.299327019,17.030340887 82.30738366,16.579779364 81.248545769,16.320135809 80.99887129,15.846747137 80.263194207,15.674546617 80.054535352,15.014146226 80.347829623,13.349066473 79.861827019,12.022040106 79.851328972,10.282212632 79.262285305,10.0043319472 78.956797722,9.274847723 78.239756707,8.965562242 78.0463219136,8.39981611 77.510915561,8.075995184 76.53809655,8.939113674 75.530772332,11.693670966 74.817556186,12.861761786 74.263194207,14.701605536 73.447032097,16.068915106 72.650075717,19.841986395 72.879161004,20.512437242 72.542165561,22.156724351 72.128103061,21.983547268 72.104746941,21.205064195 70.982432488,20.710150458 70.0576278,21.149237372 68.944590691,22.295070705 70.17847741,22.561957098 68.622569207,23.19155508 68.183034701,23.842108466 68.725913127,24.289216207 69.972038615,24.165218608 71.063858277,24.682577209 70.064642782,25.980327454 70.158073771,26.530113017 69.465092814,26.807770487 70.341938517,28.011469625 70.831572713,27.701462707 71.860863892,27.950207215 72.901523885,29.022622376 73.370332479,29.927321676 74.658832641,31.083788554 74.489437297,31.711192118 75.359048299,32.261675314 74.306502726,32.809910584 73.774855591,34.37095225 74.285832153,34.768886617 75.777110637,34.503812358 77.2516900425,35.424740888 77.800346314,35.495405579 78.273185669,34.658867493 78.922138306,34.372295837 78.781371704,33.552785136 79.476419719,32.6454245 78.7887122705,32.2487005277 79.577808879,30.938371074 80.996016887,30.1969693</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>IN</ogr:ISO2>
      <ogr:ISO3>IND</ogr:ISO3>
      <ogr:ISONUM>356</ogr:ISONUM>
      <ogr:NAMEen>India</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.105">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-7.24710039,55.069322007 -7.8771410548,54.5176808423 -6.269886848,54.097927151 -5.996571418,52.9649112 -6.689683212,51.9640433145 -8.696156379,51.576646226 -10.381947395,51.877671617 -10.091436754,52.5541041108 -9.5600548398,53.146673895 -10.176503059,53.412665106 -9.843983528,54.328762111 -8.470285611,54.276597398 -8.27847246,55.160549221 -7.24710039,55.069322007</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>IE</ogr:ISO2>
      <ogr:ISO3>IRL</ogr:ISO3>
      <ogr:ISONUM>372</ogr:ISONUM>
      <ogr:NAMEen>Ireland</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.106">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>46.135870809,38.863701274 46.51403894,38.882175599 47.846877482,39.685279032 48.338940471,39.378941142 48.012965535,38.821559143 48.874278191,38.434068101 49.132497592,37.623358466 50.148773634,37.403876044 51.08863366,36.737005927 51.90902754,36.582709052 54.01433353,36.821112372 53.913747592,37.342759507 54.783663371,37.517452698 55.423107544,38.075894063 57.218346802,38.265081482 57.7902916814,37.88504314 58.80109257,37.694651184 60.342290487,36.637144674 61.075475708,36.647790019 61.269675741,35.61849884 60.511789185,33.638387146 60.821744425,31.494667868 61.661176391,31.381909892 61.785199829,30.831400859 60.844378703,29.85817861 61.892790161,28.542599997 62.739301799,28.258327942 62.800641723,27.225161031 63.141344441,26.625404359 61.857133423,26.242378642 61.588226759,25.202093817 59.903805956,25.329863349 57.326182488,25.777004299 57.024912957,26.850978908 56.353037957,27.201605536 54.801524285,26.498236395 53.716075066,26.708563544 52.423106316,27.646633205 51.380271138,27.991418381 50.073415561,30.195746161 48.948578321,30.401068427 48.531016472,29.961330471 47.672934611,30.994698385 47.831322876,31.761835022 47.343342326,32.458691712 46.273433472,32.959488017 45.380361369,33.973560486 45.417051635,34.444358623 46.281391642,35.828305156 45.359587443,35.976874899 44.766135295,37.141920065 44.221465698,37.968820496 44.061372111,39.400283508 44.8346988445,39.561142994 45.2491653187,38.9452682836 46.135870809,38.863701274</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>IR</ogr:ISO2>
      <ogr:ISO3>IRN</ogr:ISO3>
      <ogr:ISONUM>364</ogr:ISONUM>
      <ogr:NAMEen>Iran</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.107">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>44.766135295,37.141920065 45.359587443,35.976874899 46.281391642,35.828305156 45.417051635,34.444358623 45.380361369,33.973560486 46.273433472,32.959488017 47.343342326,32.458691712 47.831322876,31.761835022 47.672934611,30.994698385 48.531016472,29.961330471 47.94800866,29.994045315 47.110488322,29.960911357 46.53243575,29.095744527 44.691824585,29.201836243 42.075395142,31.079861145 40.424126424,31.920533345 39.14637496,32.118144023 38.774511352,33.371685079 40.690466756,34.331497294 41.195655558,34.768473206 41.414866984,36.527383932 42.357238403,37.109984029 42.722177368,37.358909404 44.766135295,37.141920065</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>IQ</ogr:ISO2>
      <ogr:ISO3>IRQ</ogr:ISO3>
      <ogr:ISONUM>368</ogr:ISONUM>
      <ogr:NAMEen>Iraq</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.108">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-16.0385105418,66.536607164 -14.055118716,66.2231532665 -13.3505551021,65.2726073668 -14.544911262,64.405096747 -16.197778422,63.7863471306 -18.732045051,63.396714585 -21.168324348,63.875555731 -22.053374729,64.7255270037 -23.9014390224,64.7491346385 -22.8594740911,65.2480485837 -24.539906379,65.50800202 -24.5077115773,66.2790028114 -22.9514264805,66.6859947673 -21.714235818,66.0441178154 -20.5221696773,65.6866923221 -19.9009905122,66.2490592523 -17.9635446548,66.0474954429 -16.0385105418,66.536607164</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>IS</ogr:ISO2>
      <ogr:ISO3>ISL</ogr:ISO3>
      <ogr:ISONUM>352</ogr:ISONUM>
      <ogr:NAMEen>Iceland</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.109">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>35.757590349,32.744346858 35.6320930748,32.3757741523 35.1057683822,32.2566098282 35.0794930423,31.7510099591 35.0857968532,31.4818723424 35.4497660796,31.4113397213 35.4010613942,31.2308702979 35.4312948719,31.0915048678 34.955577019,29.558986721 34.8867293625,29.490057684 34.248350857,31.211448958 34.5445930809,31.5182216314 34.481204125,31.583141323 35.105235222,33.089016018 35.821099894,33.4067217 35.757590349,32.744346858</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>IL</ogr:ISO2>
      <ogr:ISO3>ISR</ogr:ISO3>
      <ogr:ISONUM>376</ogr:ISONUM>
      <ogr:NAMEen>Israel</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.110">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-76.7034708945,18.454272251 -75.8865239825,18.2967442564 -75.1831962621,17.9904066292 -75.4966896776,17.7999943094 -76.1735955858,17.8498546616 -76.8975798464,17.7218074697 -77.5608941908,17.8723482329 -78.4783277625,18.2597648926 -77.790729114,18.4158567828 -76.7034708945,18.454272251</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>JM</ogr:ISO2>
      <ogr:ISO3>JAM</ogr:ISO3>
      <ogr:ISONUM>388</ogr:ISONUM>
      <ogr:NAMEen>Jamaica</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.111">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>39.14637496,32.118144023 36.959531698,31.49099884 37.981071411,30.499483134 36.756236613,29.865516663 36.016436808,29.189950664 34.9493851167,29.3516858265 34.955577019,29.558986721 35.4312948719,31.0915048678 35.4010613942,31.2308702979 35.4497660796,31.4113397213 35.5594024594,31.7653694425 35.6320930748,32.3757741523 35.757590349,32.744346858 36.819385213,32.316788229 38.774511352,33.371685079 39.14637496,32.118144023</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>JO</ogr:ISO2>
      <ogr:ISO3>JOR</ogr:ISO3>
      <ogr:ISONUM>400</ogr:ISONUM>
      <ogr:NAMEen>Jordan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.112">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>130.9813035177,33.7852630008 131.729537981,33.580236163 132.025474986,32.92359591 131.338226759,31.372626044 130.657722026,31.0031912 130.222204714,31.246299862 130.179860873,32.093451239 130.4303056674,32.3791388814 130.2203415316,32.833312771 129.834378031,32.694121637 129.564138217,33.21112702 130.9813035177,33.7852630008</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>134.161631707,34.362494208 134.8799162548,34.1393762803 134.190255131,33.248329294 133.535916772,33.4391359169 132.8307053199,32.8858625169 132.381114129,33.466050523 132.8313671297,33.9874007042 133.510996941,33.965236721 134.161631707,34.362494208</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>141.276095682,41.353195528 142.06934655,39.540472723 141.097829623,38.371527411 141.04184004,37.377142645 140.564107371,36.283095802 140.841644727,35.74241771 139.926395846,34.907356652 139.782153008,35.3141771 138.215989191,34.712282661 136.855967644,34.739813544 136.1118296563,33.7903614861 135.1863123858,33.8460215217 135.414379151,34.55812547 134.381358269,34.739813544 133.3731560864,34.3733408758 131.0470503731,34.0512764756 131.0199537041,34.4036562391 133.091261013,35.601484911 134.611686648,35.7350818704 135.810499536,35.526862684 136.7291878658,37.2793486342 137.295709888,37.531490165 137.454498748,36.9872317258 138.244894979,37.183789445 139.43238366,38.169134833 140.04857715,39.504669646 139.856781446,40.590155341 140.545975004,41.0692014442 141.276095682,41.353195528</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>142.017751498,45.455715236 142.9521029019,45.7033298223 143.728282097,44.11347077 145.4350127251,44.0575205995 145.361664259,43.301459052 143.638845248,42.661078192 143.226084832,41.932277736 141.6804755914,42.4033290249 140.8211602301,42.2027249836 141.0216983414,41.6829255132 140.208994988,41.401109117 139.876963738,42.663397528 141.169118686,43.14085521 142.017751498,45.455715236</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>JP</ogr:ISO2>
      <ogr:ISO3>JPN</ogr:ISO3>
      <ogr:ISONUM>392</ogr:ISONUM>
      <ogr:NAMEen>Japan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.113">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>87.323796021,49.085273743 85.783683309,48.40758901 85.498636109,47.051831971 84.767104533,46.818073629 83.150355672,47.211537985 82.291493368,45.533190817 80.061706991,45.018958639 80.787864217,43.128040467 80.21032841,42.189518941 79.148274374,42.790980937 75.178594198,42.849659526 74.178758585,43.261701558 73.505518026,42.420926005 71.847738078,42.834053243 70.947793009,42.248145854 69.031579224,41.366985168 68.593001343,40.599486796 67.937434123,41.200380351 66.688208049,41.199191793 66.504136597,41.993484395 66.017241251,41.99761851 65.795239298,42.877203065 64.956530803,43.697359721 63.8668029342,43.7543168338 62.026115357,43.480628765 61.036304972,44.382821758 60.0574978679,44.8477769646 59.9384183174,45.3664368028 60.4400627206,45.8377495941 60.4323324049,46.0920620042 60.1802851415,46.1677709675 59.7411264504,45.7152264177 59.1591200621,45.6857981258 58.5908979437,45.5445630245 55.978422486,44.996221008 55.978422486,41.321716614 55.429515421,41.290814107 54.195275513,42.318064067 52.978708944,42.126628723 52.4376706173,41.7488757414 52.712901238,42.730780341 51.932790561,42.834947007 50.299082879,44.655340887 51.39722741,45.332586981 52.566661004,45.400702216 53.188161655,46.718003648 51.212575717,47.120917059 49.2271305193,46.327879184 48.044488159,47.769695129 47.119480021,47.819769592 46.479312378,48.410224508 46.756988397,49.201494039 46.899906861,49.820319316 47.556921021,50.452580465 48.3054787052,50.1074706112 48.67339034,50.57954946 50.581697632,51.635298971 53.346335083,51.503033142 55.1045814792,50.763168457 56.508002564,51.066263937 58.308409465,51.150031434 58.92594283,50.678148092 61.37209843,50.782482808 61.66365686,51.258396912 60.138065226,51.888875224 61.039922323,52.334997864 61.058422485,52.922171326 61.007572876,53.635745342 61.60050826,53.950248108 65.212949259,54.34304067 68.166050659,54.956129863 68.943160848,55.434550273 70.820358928,55.294145406 71.182300659,54.101556702 73.485260864,53.874852193 73.424075968,53.432553609 76.85239384,54.461172995 76.9598554934,53.8425845084 77.866802206,53.272330832 79.990083456,50.78811554 80.682754354,51.30201182 81.460226277,50.730341289 83.433955933,50.992650859 85.26309493,49.581522522 86.591799357,49.58720693 87.323796021,49.085273743</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>KZ</ogr:ISO2>
      <ogr:ISO3>KAZ</ogr:ISO3>
      <ogr:ISONUM>398</ogr:ISONUM>
      <ogr:NAMEen>Kazakhstan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.114">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>35.920835409,4.619331563 36.844086548,4.432237041 38.10189091,3.612648824 39.536325317,3.40501292 39.848450969,3.867284444 40.763743937,4.28493337 41.885019165,3.977226054 40.965385376,2.814144593 40.979751424,-0.870798441 41.535085483,-1.696302993 40.174978061,-2.762627863 39.540049675,-4.430433852 39.190603061,-4.677504165 37.599079223,-3.513427836 37.644864542,-3.045962829 34.0741009683,-1.0524528975 34.2532441194,-0.2645195722 33.9956852793,0.2459167412 34.978670695,1.675945333 34.923583619,2.477317607 33.977078085,4.219691875 35.4115983372,5.0303758226 35.920835409,4.619331563</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>KE</ogr:ISO2>
      <ogr:ISO3>KEN</ogr:ISO3>
      <ogr:ISONUM>404</ogr:ISONUM>
      <ogr:NAMEen>Kenya</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.115">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>80.21032841,42.189518941 78.359898723,41.377527161 78.074954875,41.039511617 76.766817668,40.944685364 75.681819296,40.291701966 74.835359335,40.511636861 73.632642049,39.44834259 71.732913045,39.285096741 69.300348348,39.515625305 69.313990926,39.986914368 70.958955119,40.238371888 71.673071736,40.147886455 73.143291994,40.833852782 72.165134725,40.99935903 71.753170207,41.447290344 71.180130249,41.108137919 70.169287557,41.578341777 70.947793009,42.248145854 71.847738078,42.834053243 73.505518026,42.420926005 74.178758585,43.261701558 75.178594198,42.849659526 79.148274374,42.790980937 80.21032841,42.189518941</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>KG</ogr:ISO2>
      <ogr:ISO3>KGZ</ogr:ISO3>
      <ogr:ISONUM>417</ogr:ISONUM>
      <ogr:NAMEen>Kyrgyzstan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.116">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>104.451345248,10.419663804 103.62387129,10.500921942 103.67457116,11.063666083 103.095550977,10.933986721 102.913584832,11.645900783 102.332233928,13.564599508 103.085004517,14.295821025 105.184307903,14.345740458 105.924572795,13.917110291 106.512495565,14.590350851 106.946112508,14.323519592 107.5203927,14.704581605 107.514294882,12.343847148 106.435032593,11.677272848 106.015419962,11.770497131 105.752903687,11.015607808 105.0290719,10.914089457 104.451345248,10.419663804</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>KH</ogr:ISO2>
      <ogr:ISO3>KHM</ogr:ISO3>
      <ogr:ISONUM>116</ogr:ISONUM>
      <ogr:NAMEen>Cambodia</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.117">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>126.6674589269,37.8278101612 127.157488648,38.307223613 128.364919467,38.624335028 129.3310653,37.282171942 129.554794958,36.082477915 129.00040153,35.045950018 127.8206686059,34.636177542 126.603282097,34.300441799 126.268646681,35.137152411 126.7635135809,35.9526458904 126.356700066,36.788763739 126.8571127528,37.1276836335 126.6674589269,37.8278101612</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>KR</ogr:ISO2>
      <ogr:ISO3>KOR</ogr:ISO3>
      <ogr:ISONUM>410</ogr:ISONUM>
      <ogr:NAMEen>South Korea</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.118">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>21.56406571,42.246289302 20.567147258,41.873181662 20.064955688,42.546758118 20.34535201,42.82743866 20.8194316,43.257412415 21.76438684,42.669618836 21.56406571,42.246289302</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>XK</ogr:ISO2>
      <ogr:ISO3>KOS</ogr:ISO3>
      <ogr:ISONUM>0</ogr:ISONUM>
      <ogr:NAMEen>Kosovo</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.119">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>48.4327812271,28.5404797232 47.668128703,28.533504944 47.434086141,28.994587911 46.53243575,29.095744527 47.110488322,29.960911357 47.94800866,29.994045315 48.4327812271,28.5404797232</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>KW</ogr:ISO2>
      <ogr:ISO3>KWT</ogr:ISO3>
      <ogr:ISONUM>414</ogr:ISONUM>
      <ogr:NAMEen>Kuwait</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.120">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>102.118655233,22.397548726 102.974106893,21.575325012 103.115286906,20.868391419 104.056676473,20.958825175 104.956879924,20.091797994 103.848420451,19.299908346 105.451423381,18.192714946 105.735282024,17.664039205 107.298959188,16.064188538 107.657593628,15.28242747 107.5203927,14.704581605 106.946112508,14.323519592 106.512495565,14.590350851 105.924572795,13.917110291 105.184307903,14.345740458 105.650997762,15.634602356 104.754515015,16.528914693 104.816423381,17.372790833 104.000039103,18.318443705 103.386639852,18.441459452 102.667613973,17.850074362 102.078502645,18.21379893 101.13230717,17.461674296 101.030297892,18.427791036 101.246202026,19.570279439 100.46196049,19.53710317 100.548673544,20.158021342 100.099295288,20.31780487 101.159023885,21.552690735 101.7179045,21.134473369 101.654549195,22.446124573 102.118655233,22.397548726</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LA</ogr:ISO2>
      <ogr:ISO3>LAO</ogr:ISO3>
      <ogr:ISONUM>418</ogr:ISONUM>
      <ogr:NAMEen>Laos</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.121">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>35.821099894,33.4067217 35.105235222,33.089016018 35.9698996554,34.6498489555 36.7411761638,34.6251981176 36.5485591885,34.0779836581 35.821099894,33.4067217</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LB</ogr:ISO2>
      <ogr:ISO3>LBN</ogr:ISO3>
      <ogr:ISONUM>422</ogr:ISONUM>
      <ogr:NAMEen>Lebanon</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.122">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-8.48544633,7.5579894 -8.618719849,6.492834778 -7.446543336,5.845949198 -7.5406661241,4.3528445816 -9.278716601,5.145738023 -10.39561927,6.176988023 -11.476185676,6.919419664 -10.615187134,7.76903595 -10.28223588,8.484625346 -9.499131226,8.343471172 -9.125407268,7.190208232 -8.48544633,7.5579894</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LR</ogr:ISO2>
      <ogr:ISO3>LBR</ogr:ISO3>
      <ogr:ISONUM>430</ogr:ISONUM>
      <ogr:NAMEen>Liberia</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.123">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>25.150889519,31.65648021 24.688342732,30.144155986 24.981244751,29.181372376 24.981244751,25.205439352 24.981244751,21.995351054 24.980521281,20.00206187 23.981305786,19.995421448 23.981305786,19.496123759 21.63447229,20.654967754 19.164132121,21.87489329 15.985101359,23.444719951 14.979909027,22.99566376 14.231720011,22.617948711 13.482256713,23.17967153 11.968860717,23.517351176 11.567128133,24.266840312 10.032028035,24.856339213 9.40116215,26.113394267 9.835760945,26.504223125 9.826149129,29.128533224 9.519707885,30.228905335 10.270153036,30.915633443 10.108095744,31.411830547 11.5641309,32.465487163 11.505111803,33.1812253147 12.348317905,32.832668361 13.351735873,32.904242255 15.195974155,32.389797268 16.044606967,31.275539455 17.36589603,31.086615302 19.056813998,30.266180731 19.74887129,30.510931708 20.146657748,31.216782945 19.92066491,31.717718817 20.562673373,32.557847398 21.608653191,32.930731512 23.086436394,32.646470445 23.095550977,32.323553778 24.981700066,31.967922268 25.150889519,31.65648021</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LY</ogr:ISO2>
      <ogr:ISO3>LBY</ogr:ISO3>
      <ogr:ISONUM>434</ogr:ISONUM>
      <ogr:NAMEen>Libya</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.124">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>80.4093974923,9.7080948376 81.365733269,8.482163804 81.880707227,7.327093817 81.681488477,6.462144273 80.590830925,5.923732815 79.863047722,6.807196356 79.6312190726,9.1284358774 80.4093974923,9.7080948376</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LK</ogr:ISO2>
      <ogr:ISO3>LKA</ogr:ISO3>
      <ogr:ISONUM>144</ogr:ISONUM>
      <ogr:NAMEen>Sri Lanka</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.125">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>28.758636922,-28.700469258 29.435908244,-29.342393901 29.150654337,-29.911144714 27.743608439,-30.600301615 27.014867391,-29.62558075 27.747432495,-28.908621928 28.758636922,-28.700469258</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LS</ogr:ISO2>
      <ogr:ISO3>LSO</ogr:ISO3>
      <ogr:ISONUM>426</ogr:ISONUM>
      <ogr:NAMEen>Lesotho</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.126">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>26.594531291,55.666990866 26.585069889,55.2483949451 25.782694539,54.869675192 24.788698365,53.969678447 23.485625448,53.939292704 22.767219686,54.356269837 22.808870891,54.893756409 21.0364811833,55.3006228883 21.05339603,56.072617906 22.094082479,56.417410177 24.447220499,56.260520528 24.892257934,56.438726706 26.594531291,55.666990866</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LT</ogr:ISO2>
      <ogr:ISO3>LTU</ogr:ISO3>
      <ogr:ISONUM>440</ogr:ISONUM>
      <ogr:NAMEen>Lithuania</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.127">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>27.352934611,57.52760081 28.148906697,56.142414043 26.594531291,55.666990866 24.892257934,56.438726706 24.447220499,56.260520528 22.094082479,56.417410177 21.05339603,56.072617906 21.699229363,57.555324611 22.585785352,57.759711005 23.189601341,57.3156049681 23.89180841,57.2795303695 24.3061587342,57.8681862559 25.263501424,58.075138449 27.352934611,57.52760081</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>LV</ogr:ISO2>
      <ogr:ISO3>LVA</ogr:ISO3>
      <ogr:ISONUM>428</ogr:ISONUM>
      <ogr:NAMEen>Latvia</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.128">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-2.222564257,35.089300848 -1.769525513,34.741343079 -1.674234172,33.237972311 -1.047502401,32.517008566 -1.249557251,32.081660462 -2.516146606,32.132200013 -3.659506721,31.6478209968 -3.6455290567,30.7113174864 -4.3723676021,30.5086413535 -5.7561563712,29.6140708361 -7.619452678,29.389421692 -8.682385213,28.665899964 -8.6828343985,27.6761318694 -12.9749154211,27.9272019046 -11.4855734559,28.340492658 -10.5737561215,29.0053458059 -9.6550693221,30.1419244431 -9.8474923441,31.4175609109 -9.2598762553,32.592160932 -8.5290897307,33.2840484963 -6.8219168959,34.0550490556 -5.9078166961,35.8129879986 -5.3691729611,35.901092623 -4.3757149505,35.1674018576 -2.9473907671,35.3453610371 -2.9124758378,35.2924982301 -2.222564257,35.089300848</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MA</ogr:ISO2>
      <ogr:ISO3>MAR</ogr:ISO3>
      <ogr:ISONUM>504</ogr:ISONUM>
      <ogr:NAMEen>Morocco</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.129">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>28.199497925,45.461773987 28.234121134,46.662424215 26.617889038,48.258967591 27.751773315,48.451979066 29.236023803,47.870722555 29.928177938,46.809753723 29.84776941,46.341461894 28.94580896,46.45478831 28.636325653,45.7285548955 28.199497925,45.461773987</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MD</ogr:ISO2>
      <ogr:ISO3>MDA</ogr:ISO3>
      <ogr:ISONUM>498</ogr:ISONUM>
      <ogr:NAMEen>Moldova</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.130">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>49.351735873,-12.090508722 49.942149285,-13.033868097 50.48340905,-15.443454685 50.230153842,-15.970961196 49.638438347,-15.544610284 49.849457227,-16.552422784 49.497731967,-17.79680755 47.900645379,-22.481133722 47.126149936,-24.934340102 45.136078321,-25.584161066 44.028819207,-24.998955988 43.706716342,-24.40618255 43.757985873,-23.454034113 43.22543379,-22.233819269 43.507497592,-21.309502863 44.47934004,-19.912774347 43.943125847,-17.455743097 44.85425866,-16.225355727 46.219004754,-15.706719659 46.97144616,-15.198418878 48.747406446,-13.411553644 48.984629754,-12.333428644 49.351735873,-12.090508722</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MG</ogr:ISO2>
      <ogr:ISO3>MDG</ogr:ISO3>
      <ogr:ISONUM>450</ogr:ISONUM>
      <ogr:NAMEen>Madagascar</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.131">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-97.139271614,25.965806382 -97.651437955,24.51585521 -97.890980598,22.596096096 -97.150542773,20.647040106 -95.752756314,18.76581452 -94.466949023,18.144232489 -91.431187992,18.880117173 -90.730091926,19.375921942 -90.360096809,21.000392971 -89.785959439,21.284572658 -87.96206621,21.600083726 -86.827951627,21.433294989 -86.875314908,20.855047919 -87.742095507,19.614935614 -87.433013476,19.492010809 -87.8296610249,18.2453102094 -88.091542121,18.371730861 -88.303822395,18.481350002 -89.160496175,17.81431427 -90.990901246,17.801963603 -91.430771037,17.254968567 -90.379853272,16.367270813 -90.485738282,16.070699768 -91.723776409,16.06878774 -92.204651449,15.289507141 -92.246245898,14.546291408 -93.898101366,16.088934637 -94.852080858,16.428900458 -95.434478252,15.97537991 -96.556038426,15.65902517 -97.772718996,15.979454108 -98.856550207,16.528179282 -101.059028659,17.264237103 -101.811061035,17.89025992 -103.498399656,18.33348265 -103.979977027,18.874937644 -105.017119921,19.368475653 -105.698681425,20.406910593 -105.200062629,21.492865302 -105.800160286,22.638454494 -108.283802864,25.106838283 -109.440541145,25.793402411 -109.225412564,26.334458726 -110.615589973,27.812201239 -111.250662024,28.052012803 -112.152178958,28.987435522 -113.128840604,30.812439603 -113.048722937,31.156691667 -114.933827278,31.908880927 -114.660302305,30.183252241 -112.846304024,28.441077049 -112.773217563,27.863902157 -111.814584775,26.714577386 -110.350380957,24.114455978 -109.476458899,23.560204887 -109.895378363,22.874202959 -110.307362344,23.54103237 -112.088042773,24.77338288 -112.343495246,26.178127346 -113.163685676,26.78912995 -113.637137676,26.725530915 -115.05589759,27.860256252 -114.168324348,27.950832424 -114.042591926,28.458441473 -115.69756433,29.755825783 -116.068023241,30.813177802 -117.125121489,32.53166949 -114.724284628,32.712836405 -111.067117676,31.333644104 -108.214811158,31.327442932 -108.215121217,31.777751364 -106.51718868,31.773823954 -105.00849524,30.676991679 -104.530824138,29.667905986 -103.147988648,28.985105286 -102.321010702,29.8939387 -101.303668774,29.6314105479 -101.0390261447,29.4604523152 -100.284339153,28.296516825 -99.507203125,27.573770244 -99.4616351591,27.0568388944 -99.1715476129,26.5658300599 -98.22265621,26.075412089 -97.139271614,25.965806382</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MX</ogr:ISO2>
      <ogr:ISO3>MEX</ogr:ISO3>
      <ogr:ISONUM>484</ogr:ISONUM>
      <ogr:NAMEen>Mexico</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.132">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>22.345023234,42.313439026 22.8565652991,41.9077564398 22.916977986,41.335772604 20.9645643201,40.841981383 20.9410466833,40.906252751 20.7245659003,40.9084800643 20.633525624,41.0826440979 20.567147258,41.873181662 21.56406571,42.246289302 22.345023234,42.313439026</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MK</ogr:ISO2>
      <ogr:ISO3>MKD</ogr:ISO3>
      <ogr:ISONUM>807</ogr:ISONUM>
      <ogr:NAMEen>Macedonia</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.133">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>4.22860966,19.142243551 4.183961222,16.416053365 3.507103312,15.353973491 1.331525512,15.283616028 0.218466838,14.910977275 -0.75289506,15.069727274 -2.023411825,14.198643494 -2.840855469,14.04299408 -3.3208293581,13.5175966081 -3.971613322,13.469954122 -4.560466268,12.149492086 -5.28248938,11.836436259 -5.522578085,10.42548879 -6.015932983,10.189870097 -6.245841431,10.720742086 -6.959389608,10.185503439 -7.989662639,10.161990662 -8.375323852,11.367653504 -8.847233033,11.657945862 -9.2862803666,12.3313548474 -10.4995113795,12.0438540216 -11.388421591,12.403895162 -11.613110718,13.360813497 -12.264130412,14.774939067 -11.727057251,15.541171367 -10.915168823,15.102903544 -10.736368368,15.42262563 -9.349217896,15.49564443 -5.510950887,15.494197489 -5.963533081,19.620612285 -6.219383097,21.822855123 -6.593107056,24.99413442 -4.821613118,24.995064596 -2.523226278,23.500995585 1.146523885,21.101710511 1.89138798,20.231789449 3.216785116,19.79406423 3.308355754,18.981684876 4.22860966,19.142243551</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>ML</ogr:ISO2>
      <ogr:ISO3>MLI</ogr:ISO3>
      <ogr:ISONUM>466</ogr:ISONUM>
      <ogr:NAMEen>Mali</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.134">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>101.159023885,21.552690735 100.099295288,20.31780487 99.942043905,20.444024557 98.53262089,19.67585439 98.024538208,19.802978414 97.379099569,18.520782776 98.436192668,17.011572571 98.682379192,16.273478089 98.533551066,15.325964865 98.164994751,15.125796204 99.152531372,13.714874573 99.102095175,13.171341858 99.630021606,11.815765686 98.747406446,10.350531317 98.768077019,11.76194896 98.578461134,13.186753648 98.160411004,13.690252997 97.794769727,14.880316473 97.652842644,16.539862372 96.904551629,17.375311591 96.801036004,16.737372137 95.431976759,15.733628648 94.214610222,16.014797268 94.615000847,17.545558986 94.153086785,18.821030992 93.497813347,19.313910223 93.745371941,19.916571356 92.731211785,20.259182033 92.265147332,21.061102606 92.57587854,21.977574362 92.978954712,21.995351054 93.374899536,23.129726257 93.302965942,24.041143494 94.099713176,23.842628479 95.15122522,26.049935608 95.040637655,26.475594381 96.142585897,27.257510478 96.758879028,27.341743063 97.323495728,28.217477723 97.546221151,28.538465881 98.679278605,27.577335918 98.692404419,25.878989971 97.53609257,24.745028178 97.637068319,23.863557435 98.585227499,24.075715027 98.859009237,23.179387309 99.493079061,23.057379252 99.144469849,22.153532613 99.94240564,22.045528869 100.187145223,21.427892151 101.159023885,21.552690735</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MM</ogr:ISO2>
      <ogr:ISO3>MMR</ogr:ISO3>
      <ogr:ISONUM>104</ogr:ISONUM>
      <ogr:NAMEen>Myanmar</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.135">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>19.195344686,43.532796122 20.34535201,42.82743866 20.064955688,42.546758118 19.4004744743,42.3263247431 19.3710404475,42.0884163441 19.365082227,41.852362372 18.496429884,42.416327216 18.437354777,42.559212138 19.195344686,43.532796122</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>ME</ogr:ISO2>
      <ogr:ISO3>MNE</ogr:ISO3>
      <ogr:ISONUM>499</ogr:ISONUM>
      <ogr:NAMEen>Montenegro</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.136">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>116.684277792,49.823264873 115.514530071,48.12210256 115.852700643,47.705564678 117.5094003564,47.776900575 117.7416300051,47.9775440208 118.542252239,47.96624644 119.699959351,47.159525655 119.680115601,46.591627503 118.238291464,46.715392558 116.603559205,46.309319153 115.637830038,45.44435903 114.533711385,45.385499573 113.635058228,44.746262105 112.011488079,45.087481588 111.396435181,44.346596578 111.933353313,43.696636251 110.40672815,42.768605041 109.485130656,42.449296367 106.767828818,42.286618958 105.014809204,41.596144308 102.034164266,42.184609681 101.637599325,42.5154422 99.474475545,42.564198914 96.350635214,42.740906474 95.379428345,44.287117005 93.525277955,44.951262513 90.873243449,45.186183574 91.047496379,46.566409404 90.344800252,47.658642477 89.045551392,47.992988994 87.942828004,48.599489441 87.816324097,49.165837301 92.301683391,50.843357646 94.237585897,50.565235087 94.624539022,50.015191142 97.301688274,49.725544739 98.293462362,50.518622946 97.806360311,51.001125794 98.886397746,52.128550517 100.005967652,51.731727193 102.18387089,51.32389679 102.327634726,50.545546366 103.668069703,50.131204733 105.328640178,50.476454977 107.946516561,49.933490703 108.538056681,49.327429505 110.731359497,49.137673646 113.043673137,49.588602194 114.286284628,50.276880595 115.368699179,49.895405172 116.684277792,49.823264873</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MN</ogr:ISO2>
      <ogr:ISO3>MNG</ogr:ISO3>
      <ogr:ISONUM>496</ogr:ISONUM>
      <ogr:NAMEen>Mongolia</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.137">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>32.893077019,-26.846123956 32.113884318,-26.840014343 31.949243204,-25.95810435 31.986553589,-24.423107605 31.288921753,-22.397339783 32.408543335,-21.290327251 32.513136434,-20.564583435 33.00726648,-20.032006124 32.763353719,-19.46397878 33.034965047,-18.33288503 32.968509156,-16.681616312 31.259982951,-16.023465271 30.402567587,-16.001244405 30.396263061,-15.635995381 30.214465373,-14.981461691 33.202706747,-14.013872172 33.644850302,-14.601743266 34.344084106,-14.387389425 34.569083293,-15.27115977 34.233186483,-15.889830017 35.291933228,-17.129340922 35.3354014174,-16.6215708371 35.79567509,-16.004965108 35.853035929,-14.667475687 34.8572364092,-13.5137256274 34.6947903101,-12.1880329058 34.964614706,-11.57355601 35.82637089,-11.413462423 36.199681437,-11.701506856 37.427823527,-11.72259084 37.875238077,-11.319101257 38.492254679,-11.413462423 40.436859571,-10.474786066 40.539398634,-13.636407159 40.84253991,-14.464450779 40.588389519,-15.477634373 39.855967644,-16.42978281 37.086436394,-17.869073175 36.4795028,-18.576429946 34.743337436,-19.890069269 35.542246941,-22.40992604 35.106455925,-24.597914321 32.872731967,-25.543877863 32.516612175,-25.949965102 32.893077019,-26.846123956</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MZ</ogr:ISO2>
      <ogr:ISO3>MOZ</ogr:ISO3>
      <ogr:ISONUM>508</ogr:ISONUM>
      <ogr:NAMEen>Mozambique</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.138">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-12.264130412,14.774939067 -14.34325415,16.636660055 -16.1595803585,16.4882628454 -16.542347786,15.80882396 -16.0442444101,17.670681649 -16.2093181427,18.9792173663 -16.521839973,19.396429755 -16.194808647,20.215155341 -17.0071292065,21.1954084035 -16.958830933,21.332859192 -13.015247355,21.333427633 -13.015247355,23.018001811 -12.032723348,23.444978333 -12.01530839,25.994900208 -8.680809082,26.013141989 -8.6829954779,27.284959249 -4.821613118,24.995064596 -6.593107056,24.99413442 -6.219383097,21.822855123 -5.963533081,19.620612285 -5.510950887,15.494197489 -9.349217896,15.49564443 -10.736368368,15.42262563 -10.915168823,15.102903544 -11.727057251,15.541171367 -12.264130412,14.774939067</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MR</ogr:ISO2>
      <ogr:ISO3>MRT</ogr:ISO3>
      <ogr:ISONUM>478</ogr:ISONUM>
      <ogr:NAMEen>Mauritania</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.139">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>33.911862426,-9.717958679 34.270905967,-10.4406874472 34.3156493143,-11.6923237157 34.030116111,-12.1880329058 34.3250689664,-13.3958089194 34.5898375036,-13.5739957383 34.8572364092,-13.5137256274 35.853035929,-14.667475687 35.79567509,-16.004965108 35.3354014174,-16.6215708371 35.291933228,-17.129340922 34.233186483,-15.889830017 34.569083293,-15.27115977 34.344084106,-14.387389425 33.644850302,-14.601743266 33.202706747,-14.013872172 32.80779545,-13.699162699 33.252729533,-12.139516296 33.319082072,-10.818149922 33.674202515,-10.577027689 32.920863485,-9.407900086 33.911862426,-9.717958679</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MW</ogr:ISO2>
      <ogr:ISO3>MWI</ogr:ISO3>
      <ogr:ISONUM>454</ogr:ISONUM>
      <ogr:NAMEen>Malawi</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.140">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>102.07309004,6.257513739 103.120290561,5.381333726 103.448578321,4.795070705 103.434580925,2.961818752 104.294688347,1.446519273 103.367360873,1.538397528 101.286387566,2.849676825 100.720713738,3.868068752 100.349131707,6.012681382 100.127289259,6.442287502 101.081664266,6.246467387 101.105435426,5.6376415 101.800483439,5.739909159 102.07309004,6.257513739</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>117.567149285,4.159654039 115.844122355,4.38921641 115.464093873,3.030823873 114.778761027,2.247202454 114.500638469,1.436037496 113.649527629,1.233259176 113.023415975,1.537013244 112.1800566,1.449034119 111.823075806,1.008466695 110.553902629,0.851370341 109.84283492,1.403274638 109.645274285,2.083238023 110.214584819,1.6558130593 111.1475221577,1.9251429141 111.44027754,2.680121161 113.007823113,3.161688544 113.99878991,4.601141669 114.586628052,4.021435242 115.6069422041,4.6450282549 115.1117252181,4.9900154729 115.848643425,5.560003973 116.777354363,7.026760158 117.743825717,6.389878648 117.774261915,5.908026434 118.410655144,5.796128648 119.267100457,5.201076565 118.5739341706,4.8971412175 118.645274285,4.444037177 117.567149285,4.159654039</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MY</ogr:ISO2>
      <ogr:ISO3>MYS</ogr:ISO3>
      <ogr:ISONUM>458</ogr:ISONUM>
      <ogr:NAMEen>Malaysia</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.141">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>23.381652466,-17.641144307 24.220464314,-17.479500427 25.259780721,-17.794106547 24.183050578,-18.029441019 23.592182251,-18.478199157 23.31147587,-18.009803975 20.975081014,-18.319345805 20.971980428,-22.000671489 19.978345988,-22.000671489 19.981446574,-24.752493184 19.98165328,-28.4223467 19.081656535,-28.959368184 17.403619425,-28.704293315 16.892952921,-28.082625834 16.48707116,-28.5729305965 15.295258009,-27.322442316 14.473643425,-24.159112238 14.386485222,-22.276462498 13.387217644,-20.816094659 13.154633009,-20.154229425 11.849081614,-18.143183242 11.766123894,-17.252699477 13.166307006,-16.951057231 13.942745402,-17.408186951 18.453581177,-17.389893494 18.761986124,-17.747701111 20.806202433,-18.031404724 23.381652466,-17.641144307</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>NA</ogr:ISO2>
      <ogr:ISO3>NAM</ogr:ISO3>
      <ogr:ISONUM>516</ogr:ISONUM>
      <ogr:NAMEen>Namibia</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.142">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>14.979909027,22.99566376 15.180395955,21.507267151 15.953992147,20.374571432 15.736020955,19.903540751 15.452420695,16.876231994 14.368972615,15.749634095 13.449183797,14.380131124 13.6032181205,13.7057695706 12.472705932,13.064164937 10.674986206,13.37510203 9.64073409,12.82252594 8.679345743,12.923579204 7.75557784,13.327146302 6.90663741,13.006855774 6.368944133,13.62627533 5.554316854,13.873417867 4.125773559,13.472977194 3.645699503,12.528538716 3.596400187,11.69577301 3.1116627147,12.1491879924 2.6025122308,12.2310288425 2.390168904,11.89653595 2.109049113,12.705633851 0.971754191,13.0673172 0.152941121,14.546710103 0.218466838,14.910977275 1.331525512,15.283616028 3.507103312,15.353973491 4.183961222,16.416053365 4.22860966,19.142243551 5.837607055,19.478631287 7.482726278,20.87257721 9.723313029,22.193426819 11.968860717,23.517351176 13.482256713,23.17967153 14.231720011,22.617948711 14.979909027,22.99566376</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>NE</ogr:ISO2>
      <ogr:ISO3>NER</ogr:ISO3>
      <ogr:ISONUM>562</ogr:ISONUM>
      <ogr:NAMEen>Niger</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.143">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>14.0665556526,13.0750351902 14.179836873,12.385601705 14.669936157,12.167423808 14.593765096,11.496431173 13.982329549,11.276263733 12.862036173,9.382890931 12.805708862,8.831503397 11.31949467,6.437282613 10.602535848,7.058071595 10.119464559,6.99440623 8.855872437,5.847499492 8.594167514,4.815293687 8.279063347,4.54682038 7.312022332,4.607896226 6.188731316,4.280991929 5.594899936,4.636460679 4.885915561,6.006537177 4.405528191,6.358872789 2.7038412893,6.3683516726 2.722861776,8.772308045 3.837419067,10.599896749 3.596400187,11.69577301 3.645699503,12.528538716 4.125773559,13.472977194 5.554316854,13.873417867 6.368944133,13.62627533 6.90663741,13.006855774 7.75557784,13.327146302 8.679345743,12.923579204 9.64073409,12.82252594 10.674986206,13.37510203 12.472705932,13.064164937 13.6032181205,13.7057695706 14.0665556526,13.0750351902</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>NG</ogr:ISO2>
      <ogr:ISO3>NGA</ogr:ISO3>
      <ogr:ISONUM>566</ogr:ISONUM>
      <ogr:NAMEen>Nigeria</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.144">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-83.1304444725,14.9970120213 -83.570139127,13.287095445 -83.492298957,12.400336005 -83.868031379,11.37490469 -83.644357877,10.92593008 -85.7017355659,11.0808801812 -87.646514452,12.872381903 -87.314035611,12.981553453 -86.701860718,13.314201355 -86.727233847,13.768256327 -85.824162354,13.847683004 -85.008517904,14.5113094451 -84.482693848,14.61947052 -83.1304444725,14.9970120213</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>NI</ogr:ISO2>
      <ogr:ISO3>NIC</ogr:ISO3>
      <ogr:ISONUM>558</ogr:ISONUM>
      <ogr:NAMEen>Nicaragua</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.145">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>7.194590691,53.245021877 7.026320027,52.230637309 5.928040812,51.806735535 5.994910116,50.749926656 5.012127727,51.474326884 3.9028219865,51.4498969326 3.457530144,51.555080471 4.508148634,52.336371161 4.745453321,52.967596747 6.730235222,53.460638739 7.194590691,53.245021877</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs><gml:innerBoundaryIs><gml:LinearRing><gml:coordinates>5.0652747295,52.9229571027 5.1430106197,52.7036115474 5.3861957515,52.7942623757 5.4059467683,53.0249188203 5.0652747295,52.9229571027</gml:coordinates></gml:LinearRing></gml:innerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>NL</ogr:ISO2>
      <ogr:ISO3>NLD</ogr:ISO3>
      <ogr:ISONUM>528</ogr:ISONUM>
      <ogr:NAMEen>Netherlands</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.146">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>30.8409538907,69.8058419025 28.954077189,69.027260641 29.344544311,69.464391582 27.897294149,70.070685324 26.031981649,69.696677145 24.860942016,68.563412984 21.5785150411,69.1261383161 20.62316451,69.036355693 19.931010376,68.350196025 18.171841268,68.535921123 16.127108195,67.422759095 16.41556604,67.052704163 14.540538371,66.1254481 14.514286743,65.31808136 13.642763713,64.584017639 13.93943811,64.009530742 12.681892131,63.956355693 11.992425171,63.288902893 12.510946492,60.117985332 11.437510613,58.991725979 10.469574415,59.247788804 8.501231316,58.257228908 6.530528191,58.120550848 5.47795116,58.754747227 6.252126498,59.27724844 5.18230228,59.511216539 5.705577019,60.16030508 4.926768425,60.800116278 5.431162957,62.186183986 7.422699415,62.597967841 7.501149936,62.910834052 9.5967858469,63.9020251176 11.1735475585,65.1233519413 12.3661622556,65.4670264944 13.1436239451,66.8213547582 14.2981110218,67.444727192 15.4342010145,68.4351589636 17.4413072991,69.1096551719 18.6044920621,70.1025672293 22.9657239204,70.4929983479 24.8183233748,71.0714317048 27.7669932951,71.1854682047 31.07699629,70.284247137 30.8409538907,69.8058419025</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>22.8505039189,78.363951949 23.821847843,78.0715128562 22.4308910793,77.1124882485 20.921722852,77.442368882 20.3508674817,78.2583075281 21.8781829892,78.6111302836 22.8505039189,78.363951949</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>16.820078972,79.875799872 21.0128177785,78.7753978786 18.993011915,78.466986395 16.809580925,76.566839911 13.718760613,77.767889716 10.708018425,79.561428127 14.548594597,79.811468817 16.347911004,78.916245835 16.820078972,79.875799872</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>23.142425977,80.381170966 27.149668816,79.854966539 24.053070509,79.188869533 21.9692794211,79.1267540877 18.5986216075,80.1012594417 23.142425977,80.381170966</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>NO</ogr:ISO2>
      <ogr:ISO3>NOR</ogr:ISO3>
      <ogr:ISONUM>578</ogr:ISONUM>
      <ogr:NAMEen>Norway</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.147">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>88.118217814,27.860884501 88.074189494,26.453941955 87.326224813,26.353327942 85.82161381,26.571712545 84.640238892,27.028377177 84.577038615,27.32903066 82.752137085,27.494963684 80.036385539,28.837026469 80.476151978,29.806140442 80.996016887,30.1969693 82.088766724,30.330087789 83.517051636,29.191707662 84.099134969,29.247001445 85.080212036,28.318789368 85.980260458,27.885172424 88.118217814,27.860884501</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>NP</ogr:ISO2>
      <ogr:ISO3>NPL</ogr:ISO3>
      <ogr:ISONUM>524</ogr:ISONUM>
      <ogr:NAMEen>Nepal</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.148">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>172.904470248,-40.508477472 173.3243996278,-41.0790455495 174.0818245663,-40.9494579123 174.292165561,-41.730157159 172.417328321,-43.737481378 171.3460021856,-44.2786309125 170.700450066,-45.907810154 169.635101759,-46.578383071 168.419200066,-46.601983331 166.489756707,-45.807549738 167.1678405538,-44.3041323609 169.733653191,-43.565687758 171.122813347,-42.592380467 172.106781446,-40.886895441 172.904470248,-40.508477472</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>173.079274936,-34.411716404 174.569509311,-35.594333592 174.81910241,-36.823663019 175.997243686,-37.631768488 177.197032097,-37.995538019 177.992035352,-37.54306406 178.564300977,-37.717705988 177.86622155,-39.097344659 176.906260613,-39.447523696 176.837250196,-40.177911066 175.330332879,-41.609795831 174.7963093887,-41.3744981778 175.1321695213,-40.5367488832 174.8265772525,-39.9025219824 173.6903489852,-39.4818300564 174.578868035,-38.839450779 174.85035241,-37.764906508 174.024099155,-36.268161717 172.674082879,-34.479913019 173.079274936,-34.411716404</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>NZ</ogr:ISO2>
      <ogr:ISO3>NZL</ogr:ISO3>
      <ogr:ISONUM>554</ogr:ISONUM>
      <ogr:NAMEen>New Zealand</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.149">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>77.2516900425,35.424740888 75.777110637,34.503812358 74.285832153,34.768886617 73.774855591,34.37095225 74.306502726,32.809910584 75.359048299,32.261675314 74.489437297,31.711192118 74.658832641,31.083788554 73.370332479,29.927321676 72.901523885,29.022622376 71.860863892,27.950207215 70.831572713,27.701462707 70.341938517,28.011469625 69.465092814,26.807770487 70.158073771,26.530113017 70.064642782,25.980327454 71.063858277,24.682577209 69.972038615,24.165218608 68.725913127,24.289216207 68.183034701,23.842108466 67.63160241,23.803452867 67.156993035,24.662909247 66.251800977,25.47288646 63.500498894,25.193670966 61.588226759,25.202093817 61.857133423,26.242378642 63.141344441,26.625404359 62.800641723,27.225161031 62.739301799,28.258327942 61.892790161,28.542599997 60.844378703,29.85817861 62.477508993,29.407818502 64.086092977,29.386605326 66.195628296,29.835337627 66.366263876,30.922868144 68.159126018,31.825913798 69.298849731,31.937689922 69.547516724,33.075010682 70.294447876,33.31894928 70.002837769,34.043788758 71.062618042,34.054253235 71.633694296,35.203123678 71.16591923,36.045707906 72.565213664,36.820596008 74.542353963,37.021669006 75.976581665,36.462633362 76.166027466,35.806239319 76.777350741,35.646111714 77.2516900425,35.424740888</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PK</ogr:ISO2>
      <ogr:ISO3>PAK</ogr:ISO3>
      <ogr:ISONUM>586</ogr:ISONUM>
      <ogr:NAMEen>Pakistan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.150">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-77.373524543,8.664740302 -77.1690059,7.935072326 -77.8958391508,7.2350980564 -78.475176067,7.9018121419 -78.190940111,8.4240114191 -78.9233108395,8.7954105573 -79.7478058187,8.651556319 -80.470244921,8.220648505 -79.994658983,7.503444729 -80.6736723029,7.3504854641 -80.9869352746,7.674777347 -81.4365443076,7.9145856864 -82.5307180284,8.1505497186 -82.8976292589,8.0347480201 -82.829022176,9.602722473 -82.573597786,9.576198635 -82.245961067,9.014146226 -81.30446316,8.781882361 -80.0340165738,9.5551847667 -79.0090882292,9.5393414078 -78.02456621,9.22646719 -77.373524543,8.664740302</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PA</ogr:ISO2>
      <ogr:ISO3>PAN</ogr:ISO3>
      <ogr:ISONUM>591</ogr:ISONUM>
      <ogr:NAMEen>Panama</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.151">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-69.964949504,-4.236484477 -70.832235067,-4.179433695 -72.917947551,-5.132088725 -73.131784628,-6.435264995 -73.765492717,-6.90417694 -74.018474691,-7.543517761 -72.95939205,-9.085645854 -73.214983684,-9.409036967 -72.306770386,-9.540915222 -72.195666057,-10.005589701 -71.391425741,-10.006829935 -70.624418295,-9.565823263 -70.641342326,-11.010799662 -69.577634644,-10.952301941 -68.684252483,-12.502491557 -68.980952718,-12.867947286 -68.883723511,-14.211482849 -69.390669312,-14.964408467 -69.3689075755,-15.5197582472 -70.0147979905,-15.8555155657 -69.111242796,-16.231204529 -68.9623371317,-16.2216749995 -69.0377217651,-16.551258157 -69.510088752,-17.506588198 -70.3947027461,-18.3377462069 -71.385161913,-17.68726979 -71.514515754,-17.284600519 -73.70027773,-16.220696358 -75.189460982,-15.358371153 -76.291737434,-14.080987238 -76.221101527,-13.357555919 -77.647256706,-11.292316287 -78.985740012,-8.217420554 -79.964679566,-6.787355106 -81.101457036,-6.072068061 -81.252797004,-4.238702081 -80.3407286664,-3.3934976535 -80.481077637,-3.998772888 -79.063928996,-5.011372579 -78.672660889,-4.550987243 -78.361723796,-3.408524678 -77.849016073,-2.980643819 -76.684591025,-2.573640239 -75.560034343,-1.502594502 -75.283487915,-0.107020772 -74.824652873,-0.170479431 -74.344423788,-0.858602803 -73.636560018,-1.255167745 -73.197775432,-2.213558858 -72.396584026,-2.446516215 -70.992716228,-2.197435812 -70.050629028,-2.71513031 -70.73412736,-3.782041931 -69.964949504,-4.236484477</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PE</ogr:ISO2>
      <ogr:ISO3>PER</ogr:ISO3>
      <ogr:ISONUM>604</ogr:ISONUM>
      <ogr:NAMEen>Peru</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.152">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>125.6435653,9.611273505 126.2966297174,9.4028124364 126.463063998,8.229925848 126.610362175,7.277044989 126.2060653,6.299302476 125.9087938387,7.0783445697 125.388926629,6.768296617 125.706553582,6.149725653 125.387543165,5.573797919 124.7574960305,5.5801884273 123.8480691126,6.3795879505 123.7878046433,7.5502448675 123.2147088293,7.3224240353 122.5453882017,7.4428031319 121.937022332,6.978949286 122.292246941,8.009914455 123.758799675,8.607489325 124.1456058451,8.3930089687 124.780772332,8.94912344 125.526540561,9.026190497 125.6435653,9.611273505</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>123.269786004,10.977362372 123.575531446,10.825588283 123.033213738,9.03530508 122.395192905,9.836615302 122.878916863,10.118068752 123.269786004,10.977362372</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>123.999522332,11.077337958 124.1515525062,10.266830021 123.5355034086,9.7090304167 123.999522332,11.077337958</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>119.8173816398,11.474708091 119.973706306,10.6382385291 118.990314348,9.8128616059 118.6090660029,9.209255234 117.19800866,8.334784247 118.822276238,10.194525458 119.224594286,10.5680089282 119.8173816398,11.474708091</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>124.443125847,11.446926174 124.984141472,11.381333726 125.22925866,10.254339911 124.780446811,10.151922919 124.443125847,11.446926174</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>122.300140821,11.76194896 123.2467481824,11.6593393459 122.6961464585,10.5790858774 121.949717644,10.433172919 122.300140821,11.76194896</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>124.918955925,12.562241929 125.500498894,12.248602606 125.566172722,11.268133856 125.246836785,11.092189846 124.27621504,12.533270575 124.918955925,12.562241929</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>121.1739491587,13.3770924556 121.7517639888,12.7825364025 121.24496504,12.214422919 120.356618686,13.518377997 121.1739491587,13.3770924556</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>120.9091903,18.567206122 122.046919633,18.5457329302 122.529063347,17.090521552 122.231944207,16.319037177 121.577810092,15.932074286 121.379161004,15.308172919 121.731618686,14.195054429 122.3113161303,14.0530061458 122.470957879,14.345892645 123.3210262735,14.1726195195 123.972666863,13.729315497 123.6330267233,13.5096169576 124.4381476369,12.9042950985 123.5653689618,12.8169812509 123.0018236052,13.4163325985 122.690684441,13.228664455 121.8336528618,13.6829419232 121.430023634,13.656927802 120.628103061,13.810858466 120.6324679739,14.3962812198 120.079925977,14.803941148 119.812510613,16.367499091 120.299082879,16.017401434 120.333832227,17.556382554 120.9091903,18.567206122</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PH</ogr:ISO2>
      <ogr:ISO3>PHL</ogr:ISO3>
      <ogr:ISONUM>608</ogr:ISONUM>
      <ogr:NAMEen>Philippines</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.153">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>154.810801629,-5.483575128 155.91675866,-6.517510675 155.71778405,-6.872816665 154.755869988,-5.947849217 154.810801629,-5.483575128</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>152.23340905,-4.190362238 152.098887566,-5.455743097 151.1962840725,-6.1407966735 149.629405144,-6.299248956 148.386241082,-5.775079034 148.429942254,-5.444756769 150.1236942065,-5.5308122515 151.695648634,-4.818780206 151.540293816,-4.176690363 152.23340905,-4.190362238</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>140.976980014,-9.106133722 140.977161906,-6.896632182 140.974457227,-2.600518488 144.025066527,-3.463118745 145.811859571,-4.861016534 145.727386915,-5.422458592 147.449066602,-5.961602472 147.854014519,-6.691013279 146.977305535,-6.740411066 147.188487175,-7.462579034 148.114024285,-8.055352472 148.559255405,-9.032484633 149.141856316,-8.974541925 149.226573113,-9.486748956 150.055918816,-9.715020441 149.939463738,-10.06243255 150.692881707,-10.556735935 147.977386915,-10.166273696 147.052744988,-9.460219008 146.079356316,-8.087497654 143.956797722,-7.972263279 142.980479363,-8.335625909 143.405528191,-8.962172133 142.652598504,-9.330254816 140.976980014,-9.106133722</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>151.043630405,-2.710625909 152.1340476963,-3.0473657915 153.0415969584,-4.0367768299 152.897715691,-4.848321222 152.6465802059,-4.0239327893 152.011949685,-3.4112695729 151.2259973399,-3.1172158548 151.043630405,-2.710625909</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PG</ogr:ISO2>
      <ogr:ISO3>PNG</ogr:ISO3>
      <ogr:ISONUM>598</ogr:ISONUM>
      <ogr:NAMEen>Papua New Guinea</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.154">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>19.3094839524,54.588041797 19.7579288966,54.4342658307 22.767219686,54.356269837 23.485625448,53.939292704 23.868961222,52.670042013 23.165644979,52.289393413 23.606238241,51.517399191 24.10770634,50.540843811 22.640922485,49.528760885 22.539636678,49.072199606 21.81957727,49.377245586 19.747765747,49.205886536 18.833196249,49.510260722 18.3248863178,50.1823334108 16.5785977055,50.2845831544 14.8103927,50.858447164 14.644821411,52.576921082 14.123922973,52.850651144 14.2620399341,54.1549113173 16.339610995,54.6251439864 18.316905144,54.838324286 19.3094839524,54.588041797</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PL</ogr:ISO2>
      <ogr:ISO3>POL</ogr:ISO3>
      <ogr:ISONUM>616</ogr:ISONUM>
      <ogr:NAMEen>Poland</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.155">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-67.1123529402,18.5531984128 -65.4755635124,18.4018341195 -65.2806438915,18.1550054859 -65.5702772068,17.8596035031 -67.1362014505,17.9588114535 -67.286528571,18.3549275785 -67.1123529402,18.5531984128</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PR</ogr:ISO2>
      <ogr:ISO3>PRI</ogr:ISO3>
      <ogr:ISONUM>630</ogr:ISONUM>
      <ogr:NAMEen>Puerto Rico</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.156">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>130.530771119,42.530480042 130.699961785,42.295111395 129.648797907,41.549402728 129.716557947,40.834585581 127.520843946,39.746975002 127.452240431,39.165961005 128.364919467,38.624335028 127.157488648,38.307223613 126.6674589269,37.8278101612 124.677093946,38.115383205 125.444916212,39.310614325 124.36996504,40.098293361 126.015336142,40.909131979 126.617883342,41.66593333 127.8440018872,41.4335661479 128.034592733,41.993742778 129.703328085,42.442371724 129.851742798,42.961900736 130.530771119,42.530480042</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>KP</ogr:ISO2>
      <ogr:ISO3>PRK</ogr:ISO3>
      <ogr:ISONUM>408</ogr:ISONUM>
      <ogr:NAMEen>North Korea</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.157">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-7.414418098,37.192816473 -8.997873502,37.021470445 -8.795070659,38.359227269 -9.491688606,38.707586981 -8.655100064,40.993801174 -8.750803189,41.96898021 -6.567630575,41.92607249 -6.205947225,41.570280253 -6.942491415,41.01599884 -7.359210164,38.446362407 -7.023985149,38.022563985 -7.414418098,37.192816473</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PT</ogr:ISO2>
      <ogr:ISO3>PRT</ogr:ISO3>
      <ogr:ISONUM>620</ogr:ISONUM>
      <ogr:NAMEen>Portugal</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.158">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-58.158796753,-20.165124613 -57.81757727,-20.953603617 -57.986817586,-22.035294698 -55.874388387,-22.317344665 -55.398035034,-23.976829936 -54.2666745135,-24.0662345087 -54.6094558586,-25.4316939044 -54.600202613,-25.574944884 -54.793059042,-26.644987488 -55.754731608,-27.443698425 -57.180096802,-27.487313334 -58.653288534,-27.156274109 -57.556921346,-25.45984019 -60.033669393,-24.007008972 -61.00634904,-23.805470886 -62.650357219,-22.234455668 -62.277305054,-20.579776306 -61.761212525,-19.657765401 -60.006384237,-19.298097432 -59.089540975,-19.286728617 -58.175281535,-19.821372985 -58.158796753,-20.165124613</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PY</ogr:ISO2>
      <ogr:ISO3>PRY</ogr:ISO3>
      <ogr:ISONUM>600</ogr:ISONUM>
      <ogr:NAMEen>Paraguay</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.159">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>34.248350857,31.211448958 34.2002694411,31.3142666891 34.481204125,31.583141323 34.5445930809,31.5182216314 34.248350857,31.211448958</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>35.6320930748,32.3757741523 35.5594024594,31.7653694425 35.4497660796,31.4113397213 35.0857968532,31.4818723424 35.0794930423,31.7510099591 35.1057683822,32.2566098282 35.6320930748,32.3757741523</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>PS</ogr:ISO2>
      <ogr:ISO3>PSE</ogr:ISO3>
      <ogr:ISONUM>275</ogr:ISONUM>
      <ogr:NAMEen>Palestine</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.160">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>51.2152582947,24.6258503609 50.807871941,24.746649481 50.7747813164,25.5712169028 51.4139191573,26.3645657251 52.1444789786,26.1298318498 51.968261838,25.0645346991 51.2152582947,24.6258503609</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>QA</ogr:ISO2>
      <ogr:ISO3>QAT</ogr:ISO3>
      <ogr:ISONUM>634</ogr:ISONUM>
      <ogr:NAMEen>Qatar</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.161">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>28.199497925,45.461773987 29.65902754,45.215887762 28.640879754,44.328558661 28.578379754,43.741278387 27.027476441,44.177046204 25.359619588,43.654287415 23.325150732,43.886592281 22.691640373,44.228434539 21.368545369,44.864859517 20.242825969,46.108091126 21.134864542,46.27852 21.988869263,47.492941997 22.877600546,47.946738587 24.896598755,47.710060527 26.617889038,48.258967591 28.234121134,46.662424215 28.199497925,45.461773987</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>RO</ogr:ISO2>
      <ogr:ISO3>ROU</ogr:ISO3>
      <ogr:ISONUM>642</ogr:ISONUM>
      <ogr:NAMEen>Romania</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.162">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>30.471785843,-1.066836592 30.831016887,-1.59416514 30.55459965,-2.400627543 29.931691935,-2.316911723 29.697546021,-2.808251241 29.015365438,-2.720711365 28.8744457681,-2.4770641795 29.2212526473,-1.6863271024 29.57793851,-1.3930817714 30.471785843,-1.066836592</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>RW</ogr:ISO2>
      <ogr:ISO3>RWA</ogr:ISO3>
      <ogr:ISONUM>646</ogr:ISONUM>
      <ogr:NAMEen>Rwanda</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.163">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-8.6828343985,27.6761318694 -8.6829954779,27.284959249 -8.680809082,26.013141989 -12.01530839,25.994900208 -12.032723348,23.444978333 -13.015247355,23.018001811 -13.015247355,21.333427633 -16.958830933,21.332859192 -16.7817356159,21.7602629087 -15.9410683848,23.7436017102 -14.504787129,26.1042730358 -13.5957450375,26.6916078648 -12.9749154211,27.9272019046 -8.6828343985,27.6761318694</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>EH</ogr:ISO2>
      <ogr:ISO3>SAH</ogr:ISO3>
      <ogr:ISONUM>732</ogr:ISONUM>
      <ogr:NAMEen>Western Sahara</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.164">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>46.53243575,29.095744527 47.434086141,28.994587911 47.668128703,28.533504944 48.4327812271,28.5404797232 48.873301629,27.612494208 50.001963738,26.816961981 50.144704623,25.733343817 50.807871941,24.746649481 51.2152582947,24.6258503609 51.56934655,24.256170966 52.583074178,22.93110789 55.186842895,22.703576559 55.637564738,21.978969625 54.978380168,19.995421448 51.97861495,18.995637513 49.128814738,18.612095032 48.16194869,18.148919169 47.427574911,17.09182607 45.165387411,17.428394674 43.165044393,17.325920308 42.789480014,16.370957749 42.301524285,17.453599351 41.719248894,17.909247137 40.522634311,19.972479559 39.646494988,20.461574611 39.08073978,21.315008856 39.081517394,22.546792489 38.452647332,23.784002997 37.522720274,24.267731705 37.230479363,25.193670966 36.663422071,25.85565827 35.216319207,28.054388739 34.64714603,28.099107164 34.9493851167,29.3516858265 36.016436808,29.189950664 36.756236613,29.865516663 37.981071411,30.499483134 36.959531698,31.49099884 39.14637496,32.118144023 40.424126424,31.920533345 42.075395142,31.079861145 44.691824585,29.201836243 46.53243575,29.095744527</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SA</ogr:ISO2>
      <ogr:ISO3>SAU</ogr:ISO3>
      <ogr:ISONUM>682</ogr:ISONUM>
      <ogr:NAMEen>Saudi Arabia</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.165">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>36.883636915,21.995713609 37.113617384,21.278062242 37.333506707,19.159654039 37.551036004,18.709947007 38.601573113,18.004828192 38.209687948,17.522290751 37.000459432,17.072602437 36.944028768,16.252859192 36.423647095,15.111507671 36.526379842,14.263523254 36.099429159,12.695660299 35.616874633,12.575150859 35.048227173,11.77137563 34.950662069,10.869182638 34.587066691,10.87928538 34.070697863,9.454592111 33.902095581,10.192040507 33.18208785,10.843241069 33.209217977,12.210366923 32.082206665,11.9998113 32.414072713,11.050851135 31.234816528,9.792323304 30.749264771,9.735763448 30.012978963,10.270485332 28.843840924,9.324544836 27.895072062,9.595410258 26.556859172,9.520453593 25.843052612,10.417814839 25.084080851,10.293222962 24.558376505,8.886745504 24.170328031,8.68932733 23.482318156,8.783392639 23.624014934,9.907768453 22.861064087,10.919153747 22.914807576,11.396101379 21.935125773,13.059152323 22.531471802,14.122627462 23.094641561,15.704262187 23.984406372,15.721160381 23.981305786,19.496123759 23.981305786,19.995421448 24.980521281,20.00206187 24.981244751,21.995351054 28.290345093,21.994782613 33.1811382663,21.9954074694 36.883636915,21.995713609</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SD</ogr:ISO2>
      <ogr:ISO3>SDN</ogr:ISO3>
      <ogr:ISONUM>729</ogr:ISONUM>
      <ogr:NAMEen>Sudan</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.166">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>34.070697863,9.454592111 33.970773559,8.445377096 33.174078003,8.4044752 33.0512948,7.801127014 33.716060425,7.657156474 34.7335177,6.637606303 35.098663371,5.622474467 35.809110962,5.309108581 35.920835409,4.619331563 35.4115983372,5.0303758226 33.977078085,4.219691875 33.53260909,3.774292705 32.174552449,3.520897318 31.780984741,3.815814718 30.839543498,3.490201518 29.457612345,4.669535217 28.404136596,4.27782786 27.44130131,5.070725199 27.123801311,5.768744608 26.481049846,6.104951477 26.378007039,6.6532901 25.360032999,7.335574036 24.170328031,8.68932733 24.558376505,8.886745504 25.084080851,10.293222962 25.843052612,10.417814839 26.556859172,9.520453593 27.895072062,9.595410258 28.843840924,9.324544836 30.012978963,10.270485332 30.749264771,9.735763448 31.234816528,9.792323304 32.414072713,11.050851135 32.082206665,11.9998113 33.209217977,12.210366923 33.18208785,10.843241069 33.902095581,10.192040507 34.070697863,9.454592111</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SS</ogr:ISO2>
      <ogr:ISO3>SSD</ogr:ISO3>
      <ogr:ISONUM>728</ogr:ISONUM>
      <ogr:NAMEen>South Sudan</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.167">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-12.264130412,14.774939067 -11.613110718,13.360813497 -11.388421591,12.403895162 -12.36092037,12.305606588 -13.728278768,12.673387757 -15.195114299,12.6794339 -16.7284367771,12.332530837 -16.753651496,13.065008856 -16.0972412049,13.1305108817 -15.6552237486,13.470056408 -15.137650106,13.589972636 -14.30595433,13.3053416455 -13.9662047098,13.4090589101 -14.2394964658,13.5829768153 -15.097704224,13.819984436 -16.5613991701,13.5869141589 -17.178212043,14.653143622 -16.542347786,15.80882396 -16.1595803585,16.4882628454 -14.34325415,16.636660055 -12.264130412,14.774939067</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SN</ogr:ISO2>
      <ogr:ISO3>SEN</ogr:ISO3>
      <ogr:ISONUM>686</ogr:ISONUM>
      <ogr:NAMEen>Senegal</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.168">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>161.6911158236,-10.0392086359 162.113617384,-10.456475519 161.9147680078,-10.7237775948 161.4621071738,-10.5388576024 161.3053229011,-10.1782775918 161.6911158236,-10.0392086359</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>159.6175514515,-9.3771085016 160.0909048409,-9.2281311882 160.7865962363,-9.6050073251 160.9232172042,-10.00409519 160.402137312,-10.0783048147 159.835622592,-9.793877863 159.6175514515,-9.3771085016</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>160.800466342,-8.358819269 161.2101170662,-8.5658739397 161.381114129,-9.509047133 160.867930535,-9.15211354 160.800466342,-8.358819269</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>158.595957879,-7.58587005 160.2429488908,-8.2784932419 160.2477488718,-8.7042709402 158.8595300429,-8.0624301052 158.595957879,-7.58587005</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SB</ogr:ISO2>
      <ogr:ISO3>SLB</ogr:ISO3>
      <ogr:ISONUM>90</ogr:ISONUM>
      <ogr:NAMEen>Solomon Islands</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.169">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-10.28223588,8.484625346 -10.615187134,7.76903595 -11.476185676,6.919419664 -12.506581184,7.389837958 -13.157704231,8.171291408 -13.301096158,9.041489976 -12.508327393,9.860381165 -11.272666382,9.996005961 -10.28223588,8.484625346</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SL</ogr:ISO2>
      <ogr:ISO3>SLE</ogr:ISO3>
      <ogr:ISONUM>694</ogr:ISONUM>
      <ogr:NAMEen>Sierra Leone</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.170">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-89.36162085,14.415477804 -88.496815755,13.851197002 -87.703608358,13.814997661 -87.817168749,13.406561591 -88.785674608,13.245266018 -90.092981728,13.7289030479 -89.36162085,14.415477804</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SV</ogr:ISO2>
      <ogr:ISO3>SLV</ogr:ISO3>
      <ogr:ISONUM>222</ogr:ISONUM>
      <ogr:NAMEen>El Salvador</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.171">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>20.242825969,46.108091126 21.368545369,44.864859517 22.691640373,44.228434539 22.349467407,43.807921448 22.981366822,43.198992208 22.345023234,42.313439026 21.56406571,42.246289302 21.76438684,42.669618836 20.8194316,43.257412415 20.34535201,42.82743866 19.195344686,43.532796122 19.3904035405,44.0055586499 19.240471937,44.4457522097 19.36866744,44.88713206 19.01582076,44.865634664 18.901305786,45.931202698 20.242825969,46.108091126</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>RS</ogr:ISO2>
      <ogr:ISO3>SRB</ogr:ISO3>
      <ogr:ISONUM>688</ogr:ISONUM>
      <ogr:NAMEen>Serbia</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.172">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-54.170969205,5.348374742 -54.482121949,4.912802022 -54.003029745,3.455397441 -54.615292115,2.326267396 -54.978577434,2.543050029 -56.116802531,2.333088684 -56.4944124319,2.0374662082 -58.067691203,4.151143087 -57.247670051,5.484930731 -57.0246599988,6.040526734 -54.0511833664,5.7888870089 -54.170969205,5.348374742</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SR</ogr:ISO2>
      <ogr:ISO3>SUR</ogr:ISO3>
      <ogr:ISONUM>740</ogr:ISONUM>
      <ogr:NAMEen>Suriname</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.173">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>22.539636678,49.072199606 22.132839803,48.404798483 20.481674439,48.526083069 19.884294881,48.12962148 17.825712524,47.750006409 17.14833785,48.005443014 16.945042766,48.604166158 18.833196249,49.510260722 19.747765747,49.205886536 21.81957727,49.377245586 22.539636678,49.072199606</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SK</ogr:ISO2>
      <ogr:ISO3>SVK</ogr:ISO3>
      <ogr:ISONUM>703</ogr:ISONUM>
      <ogr:NAMEen>Slovakia</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.174">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>16.515301554,46.50171051 15.7021412095,46.2256765525 15.6345859905,45.9452217611 15.409000313,45.8048974331 15.3608683482,45.4768970263 14.4520942552,45.598722106 13.589528842,45.488836981 13.7051558128,45.593207098 13.7097930591,45.9008391125 13.5331741824,46.2217184825 13.6943058283,46.519745586 14.540331665,46.378643087 16.094035278,46.862773743 16.515301554,46.50171051</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SI</ogr:ISO2>
      <ogr:ISO3>SVN</ogr:ISO3>
      <ogr:ISONUM>705</ogr:ISONUM>
      <ogr:NAMEen>Slovenia</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.175">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>24.16309655,65.822699286 21.853526238,65.53534577 20.786468946,63.878607489 19.280772332,63.459418036 17.508636915,62.218410549 17.167735222,60.99217357 19.0420028,59.784979559 18.414317254,59.140041408 16.789317254,58.607163804 16.688975457,57.471747137 15.851735873,56.086371161 14.685801629,56.147406317 14.363047722,55.52362702 13.280528191,55.345445054 11.231700066,58.339667059 11.437510613,58.991725979 12.510946492,60.117985332 11.992425171,63.288902893 12.681892131,63.956355693 13.93943811,64.009530742 13.642763713,64.584017639 14.514286743,65.31808136 14.540538371,66.1254481 16.41556604,67.052704163 16.127108195,67.422759095 18.171841268,68.535921123 19.931010376,68.350196025 20.62316451,69.036355693 23.498854614,67.882162578 24.16309655,65.822699286</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SE</ogr:ISO2>
      <ogr:ISO3>SWE</ogr:ISO3>
      <ogr:ISONUM>752</ogr:ISONUM>
      <ogr:NAMEen>Sweden</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.176">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>31.949243204,-25.95810435 32.113884318,-26.840014343 31.968260132,-27.316264343 31.157043497,-27.205573426 30.7343610625,-26.7092737533 30.8000898689,-26.1715482936 31.426897827,-25.743647155 31.949243204,-25.95810435</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SZ</ogr:ISO2>
      <ogr:ISO3>SWZ</ogr:ISO3>
      <ogr:ISONUM>748</ogr:ISONUM>
      <ogr:NAMEen>Swaziland</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.177">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>42.357238403,37.109984029 41.414866984,36.527383932 41.195655558,34.768473206 40.690466756,34.331497294 38.774511352,33.371685079 36.819385213,32.316788229 35.757590349,32.744346858 35.821099894,33.4067217 36.5485591885,34.0779836581 36.7411761638,34.6251981176 35.9698996554,34.6498489555 35.9113054189,35.9177504328 36.664252563,36.229004211 36.658568156,36.827520651 37.446116984,36.634199117 38.190050903,36.905526225 39.765251913,36.742151184 40.708966919,37.100475566 42.357238403,37.109984029</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SY</ogr:ISO2>
      <ogr:ISO3>SYR</ogr:ISO3>
      <ogr:ISONUM>760</ogr:ISONUM>
      <ogr:NAMEen>Syria</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.178">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>23.981305786,19.496123759 23.984406372,15.721160381 23.094641561,15.704262187 22.531471802,14.122627462 21.935125773,13.059152323 22.914807576,11.396101379 22.861064087,10.919153747 22.460468384,11.000828349 20.435165649,9.138125509 19.100570109,9.015264791 18.589283488,8.047881979 17.67977828,7.985198466 16.768619425,7.550237936 16.54868453,7.870011699 15.481049439,7.523262838 15.183703247,8.479147644 13.947602987,9.637759094 14.181697225,9.978177593 15.681243937,9.991277568 15.065880981,10.793114929 15.135644165,11.530821838 14.6935040769,12.5368490974 14.4578984438,13.0826216418 14.0665556526,13.0750351902 13.6032181205,13.7057695706 13.449183797,14.380131124 14.368972615,15.749634095 15.452420695,16.876231994 15.736020955,19.903540751 15.953992147,20.374571432 15.180395955,21.507267151 14.979909027,22.99566376 15.985101359,23.444719951 19.164132121,21.87489329 21.63447229,20.654967754 23.981305786,19.496123759</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TD</ogr:ISO2>
      <ogr:ISO3>TCD</ogr:ISO3>
      <ogr:ISONUM>148</ogr:ISONUM>
      <ogr:NAMEen>Chad</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.179">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>0.901474243,10.992740987 0.768769164,10.367094421 1.331008748,9.996471049 1.601173136,9.049526266 1.619639519,6.213893947 1.185394727,6.100490627 0.51927535,6.832245585 0.645675903,7.323585104 0.230197388,9.575747376 0.3965955,10.283223572 -0.166109171,11.134980367 0.901474243,10.992740987</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TG</ogr:ISO2>
      <ogr:ISO3>TGO</ogr:ISO3>
      <ogr:ISONUM>768</ogr:ISONUM>
      <ogr:NAMEen>Togo</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.180">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>100.099295288,20.31780487 100.548673544,20.158021342 100.46196049,19.53710317 101.246202026,19.570279439 101.030297892,18.427791036 101.13230717,17.461674296 102.078502645,18.21379893 102.667613973,17.850074362 103.386639852,18.441459452 104.000039103,18.318443705 104.816423381,17.372790833 104.754515015,16.528914693 105.650997762,15.634602356 105.184307903,14.345740458 103.085004517,14.295821025 102.332233928,13.564599508 102.913584832,11.645900783 101.830251498,12.672796942 100.837412957,12.707912502 100.963389519,13.471380927 100.038828972,13.402736721 100.020030144,12.192694403 99.159922722,10.128322658 99.255056186,9.232489325 99.853526238,9.294663804 100.271494988,8.317084052 100.4034894539,7.5379581379 100.997573081,6.856675229 101.566254102,6.83222077 102.07309004,6.257513739 101.800483439,5.739909159 101.105435426,5.6376415 101.081664266,6.246467387 100.127289259,6.442287502 98.655446811,8.379624742 98.199473504,8.534369208 98.747406446,10.350531317 99.630021606,11.815765686 99.102095175,13.171341858 99.152531372,13.714874573 98.164994751,15.125796204 98.533551066,15.325964865 98.682379192,16.273478089 98.436192668,17.011572571 97.379099569,18.520782776 98.024538208,19.802978414 98.53262089,19.67585439 99.942043905,20.444024557 100.099295288,20.31780487</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TH</ogr:ISO2>
      <ogr:ISO3>THA</ogr:ISO3>
      <ogr:ISONUM>764</ogr:ISONUM>
      <ogr:NAMEen>Thailand</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.181">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>70.958955119,40.238371888 69.313990926,39.986914368 69.300348348,39.515625305 71.732913045,39.285096741 73.632642049,39.44834259 73.797386515,38.602838644 74.776344849,38.510673727 74.892306763,37.231113587 73.276074667,37.459471741 71.611060018,36.7048408 71.597727499,37.898359681 70.76108606,38.443520203 70.157867065,37.541430562 69.528654826,37.586027324 68.011124715,36.930873516 67.780544475,37.188868103 68.360664103,38.174053447 68.085642131,38.993770854 67.350079794,39.219829407 68.517450399,39.54843984 69.435843953,40.802678529 70.445704793,41.025920716 70.353824097,40.456136373 70.958955119,40.238371888</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TJ</ogr:ISO2>
      <ogr:ISO3>TJK</ogr:ISO3>
      <ogr:ISONUM>762</ogr:ISONUM>
      <ogr:NAMEen>Tajikistan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.182">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>66.51958785,37.3641804 65.761442912,37.578379212 65.063087606,37.233232321 64.444572388,36.249984843 63.342934204,35.856262106 62.302015828,35.147519837 61.269675741,35.61849884 61.075475708,36.647790019 60.342290487,36.637144674 58.80109257,37.694651184 57.7902916814,37.88504314 57.218346802,38.265081482 55.423107544,38.075894063 54.783663371,37.517452698 53.913747592,37.342759507 53.977549675,38.901760158 53.567067905,39.949530341 52.738454623,40.053615627 52.850626343,41.069344576 53.721039259,40.625677802 54.716075066,41.115179755 53.896657748,42.078843492 53.3883454888,42.0518562957 52.8633801047,41.8176312082 52.808278209,41.1371947361 52.4376706173,41.7488757414 52.978708944,42.126628723 54.195275513,42.318064067 55.429515421,41.290814107 55.978422486,41.321716614 57.010194132,41.254123841 57.0678011871,41.9264799805 57.3585332315,41.7137378972 57.6460428773,41.5818655748 57.8881172646,41.7677933092 57.6438448365,42.1517623718 58.612266887,42.780852356 60.028201131,42.199518332 60.094243612,41.389516093 61.877907349,41.124984436 62.452807658,40.009238586 64.120612834,38.961679789 65.604139852,38.237408753 66.554159384,38.026853129 66.51958785,37.3641804</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TM</ogr:ISO2>
      <ogr:ISO3>TKM</ogr:ISO3>
      <ogr:ISONUM>795</ogr:ISONUM>
      <ogr:NAMEen>Turkmenistan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.183">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-60.2208175163,10.800746984 -60.5242114293,9.8654905174 -61.2595093492,10.2400614612 -61.3936382625,10.9107963664 -60.2208175163,10.800746984</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TT</ogr:ISO2>
      <ogr:ISO3>TTO</ogr:ISO3>
      <ogr:ISONUM>780</ogr:ISONUM>
      <ogr:NAMEen>Trinidad and Tobago</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.184">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>11.505111803,33.1812253147 11.5641309,32.465487163 10.108095744,31.411830547 10.270153036,30.915633443 9.519707885,30.228905335 9.045008179,32.07184194 7.750720255,33.207664083 7.479832398,33.893901265 8.236478719,34.647653708 8.349236695,36.448784078 8.6025104286,36.9395107635 9.9317372161,37.3556819345 11.3067396837,36.999521317 10.9848302788,36.0596545195 11.160781762,35.23823214 10.126719597,34.325628973 10.330251498,33.702826239 11.505111803,33.1812253147</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TN</ogr:ISO2>
      <ogr:ISO3>TUN</ogr:ISO3>
      <ogr:ISONUM>788</ogr:ISONUM>
      <ogr:NAMEen>Tunisia</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.185">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>28.016774936,41.97256094 28.5649604107,41.3893845085 29.1370488388,41.2238341077 29.1290810713,41.0075173081 27.524180535,40.989203192 26.828949415,40.601996161 26.2158644583,40.4066923807 26.0439559255,40.73847077 26.636595907,41.378457337 26.333358602,41.713036397 27.273352906,42.091747132 28.016774936,41.97256094</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>41.520762566,41.5142276065 42.819949178,41.572347311 43.4404281,41.106587626 43.665427287,40.110162659 44.774558553,39.702797343 44.8346988445,39.561142994 44.061372111,39.400283508 44.221465698,37.968820496 44.766135295,37.141920065 42.722177368,37.358909404 42.357238403,37.109984029 40.708966919,37.100475566 39.765251913,36.742151184 38.190050903,36.905526225 37.446116984,36.634199117 36.658568156,36.827520651 36.664252563,36.229004211 35.9113054189,35.9177504328 36.020274285,36.926336981 35.347992384,36.544378973 34.554698113,36.767645575 33.685313347,36.143215236 32.80372155,36.027167059 32.02605228,36.543443101 30.68653405,36.891180731 30.400401238,36.248114325 29.672373894,36.123358466 28.938975457,36.751288153 27.671153191,36.657782294 27.8845116578,37.0155558825 27.263194207,36.963364976 27.1172740121,37.7777320419 26.4472254948,38.1216010052 26.1680597776,38.5717596401 26.7031522424,38.9754551408 26.074229363,39.474514065 26.735606316,40.403550523 29.151540561,40.434068101 29.231781446,41.240708726 31.231211785,41.091986395 33.324473504,42.019029039 35.956797722,41.736273505 36.451019727,41.240423895 38.33090254,40.91787344 40.142751498,40.922796942 41.520762566,41.5142276065</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TR</ogr:ISO2>
      <ogr:ISO3>TUR</ogr:ISO3>
      <ogr:ISONUM>792</ogr:ISONUM>
      <ogr:NAMEen>Turkey</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.186">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>121.635996941,25.22280508 121.808848504,24.805161851 121.5628161436,23.1703344586 121.0742603766,21.9416664402 120.5955862961,21.8922591271 120.059418165,23.151027736 120.189219597,23.774807033 121.059336785,25.050238348 121.635996941,25.22280508</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TW</ogr:ISO2>
      <ogr:ISO3>TWN</ogr:ISO3>
      <ogr:ISONUM>158</ogr:ISONUM>
      <ogr:NAMEen>Taiwan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.187">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>31.7827295994,-1.002573344 31.6110317142,-2.0389465306 31.8265062553,-2.6971447188 33.2214978538,-2.5181713295 34.0741009683,-1.0524528975 37.644864542,-3.045962829 37.599079223,-3.513427836 39.190603061,-4.677504165 38.778005405,-6.030694269 39.464528842,-6.857679946 39.28003991,-8.309258722 39.763194207,-9.982842706 40.436859571,-10.474786066 38.492254679,-11.413462423 37.875238077,-11.319101257 37.427823527,-11.72259084 36.199681437,-11.701506856 35.82637089,-11.413462423 34.964614706,-11.57355601 34.917072388,-11.418836771 34.894128052,-11.395995789 34.7416643137,-11.2686444765 34.719771769,-11.234558614 34.288066853,-9.708450216 34.1903125879,-9.606524565 34.089319296,-9.522208354 34.078490688,-9.510185831 33.911862426,-9.717958679 32.920863485,-9.407900086 31.1666602765,-8.5890077003 30.5834065464,-7.5079376485 30.5645672423,-6.9562992743 29.7503560666,-6.2713139505 29.9461082112,-5.9177826338 29.6543531249,-4.4505910788 30.003005411,-4.271934509 30.825487508,-2.978576761 30.55459965,-2.400627543 30.831016887,-1.59416514 30.471785843,-1.066836592 31.7827295994,-1.002573344</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TZ</ogr:ISO2>
      <ogr:ISO3>TZA</ogr:ISO3>
      <ogr:ISONUM>834</ogr:ISONUM>
      <ogr:NAMEen>Tanzania</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.188">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>33.9956852793,0.2459167412 33.270656663,0.3863195129 31.9198196836,-0.1341162639 31.7827295994,-1.002573344 30.471785843,-1.066836592 29.57793851,-1.3930817714 29.6410151842,-0.4850430547 29.6887608019,-0.0986732303 29.92828129,0.785017802 30.4783817597,1.2387726624 31.1276079405,1.8187516415 31.2693446377,2.170394737 30.707665243,2.462279765 30.839543498,3.490201518 31.780984741,3.815814718 32.174552449,3.520897318 33.53260909,3.774292705 33.977078085,4.219691875 34.923583619,2.477317607 34.978670695,1.675945333 33.9956852793,0.2459167412</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>UG</ogr:ISO2>
      <ogr:ISO3>UGA</ogr:ISO3>
      <ogr:ISONUM>800</ogr:ISONUM>
      <ogr:NAMEen>Uganda</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.189">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>38.216644727,47.103257554 35.901621941,46.652736721 34.81128991,46.166245835 35.332204623,45.37124258 36.2612047858,45.3797036399 36.0571274955,45.0897417379 33.957855665,44.38300202 32.868174675,45.630072333 33.777028842,45.92963288 31.186859571,46.62913646 29.589691602,45.559068101 29.65902754,45.215887762 28.199497925,45.461773987 28.636325653,45.7285548955 28.94580896,46.45478831 29.84776941,46.341461894 29.928177938,46.809753723 29.236023803,47.870722555 27.751773315,48.451979066 26.617889038,48.258967591 24.896598755,47.710060527 22.877600546,47.946738587 22.132839803,48.404798483 22.539636678,49.072199606 22.640922485,49.528760885 24.10770634,50.540843811 23.606238241,51.517399191 24.390789836,51.880012716 25.76791508,51.928511047 27.25402592,51.595378927 30.148629598,51.484429627 30.959329467,52.074677836 31.76434493,52.100567729 33.804065389,52.35460907 34.185954224,51.248914286 35.099180135,51.183181865 35.696869751,50.345145162 37.435264933,50.424933573 39.182755168,49.858508199 40.141663045,49.245780741 39.681122681,49.020316468 39.759050741,47.832947083 38.830942017,47.848243306 38.216644727,47.103257554</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>UA</ogr:ISO2>
      <ogr:ISO3>UKR</ogr:ISO3>
      <ogr:ISONUM>804</ogr:ISONUM>
      <ogr:NAMEen>Ukraine</ogr:NAMEen>
      <ogr:UNRegion>Europe</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.190">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-53.3790945694,-33.7406759724 -53.764881965,-34.39039479 -54.939320442,-34.969903253 -56.311268684,-34.90618255 -57.120025194,-34.462985935 -57.855354162,-34.470967085 -58.388824023,-33.942071222 -58.2001118521,-32.4471299123 -57.611698365,-30.182962748 -56.831280885,-30.102037455 -56.011356771,-30.798222351 -54.591520956,-31.471049499 -53.1724546853,-32.6592425794 -53.5367920278,-33.5597688778 -53.3790945694,-33.7406759724</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>UY</ogr:ISO2>
      <ogr:ISO3>URY</ogr:ISO3>
      <ogr:ISONUM>858</ogr:ISONUM>
      <ogr:NAMEen>Uruguay</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.191">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-155.7286750347,20.1914139212 -154.9917607147,19.8119678601 -154.0011474991,19.2182769231 -154.6289157004,18.9415301746 -155.356381876,19.3503960947 -156.015147019,19.7188038047 -157.0486693146,20.263576209 -155.7286750347,20.1914139212</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-89.5817526941,47.9963331198 -91.012379962,47.4931163875 -92.0953455857,46.8040099661 -91.5844188642,46.6004446766 -90.8843315668,46.9685595131 -90.435279091,46.5764664959 -88.2879335198,47.6571945852 -88.0448985329,47.4561896511 -88.1030850409,47.0051828717 -87.1512158525,46.5388740762 -84.9527472241,46.7863481185 -84.4910523084,46.4576578772 -84.1059436185,46.3463741605 -84.734476224,45.8570405694 -86.9994609998,45.909437384 -87.636612153,45.0072113346 -87.3279713658,44.8035113587 -87.907279968,43.2672249796 -87.8225030995,42.2793389692 -87.2919117605,41.6279111561 -86.6565267922,41.8760601152 -86.2223397046,42.9643242929 -86.542902239,43.6275266712 -86.2695851468,44.688414985 -85.2487420846,45.3709737054 -84.5431119253,45.6255190391 -83.5102158195,45.3586821023 -83.3533197398,44.3295851142 -82.6893814512,43.92130207 -82.4163685665,43.0174198005 -82.6446981164,42.5575330121 -83.4591436437,41.7215189485 -82.5048151437,41.3956578598 -81.6722062102,41.5222344344 -79.4708040857,42.4070930004 -78.8675048072,42.8456955497 -78.9269663609,42.9457793529 -79.0652311503,43.105730209 -79.0586315217,43.2782003383 -76.7127593969,43.3387554625 -75.7914962913,44.4965126518 -74.7129614499,44.9992536226 -71.5148352757,45.0150542586 -70.4073514996,45.7315249384 -70.0077634866,46.7040753931 -69.2676277858,47.4398444359 -67.805184752,47.035631383 -67.8108158023,45.7624138603 -67.4409387966,45.604585751 -67.1760148371,45.1786562916 -67.9230355717,44.5430556063 -69.2592911177,44.4845658232 -70.5816544846,43.2748883891 -70.7740603337,42.7710032507 -70.6333497412,42.1737332353 -69.939443925,41.7537124695 -70.0067099135,41.5789198853 -71.4808260244,41.4817979233 -72.8924267533,41.2449747186 -73.6502580002,40.9965680767 -73.8632079403,40.6620018633 -71.9180326946,41.029992458 -71.6468170497,40.7255563625 -73.9483186434,40.0585110468 -73.7835064968,39.6655075656 -74.6471110991,38.8345242018 -75.2700127247,39.1868168091 -74.8817244381,38.4438413926 -74.8737006896,37.6637396817 -75.4141546787,37.2496799394 -75.7269497271,37.86087675 -76.3793701984,38.6964558945 -76.110045855,37.7152453196 -75.9543602316,37.0849561864 -75.7082030231,36.7547404001 -76.065093612,35.3841820098 -76.5849503829,35.5497093538 -76.522775903,34.7319196409 -77.1368709559,34.682359094 -78.0323380778,33.8922793411 -78.7633357988,33.7785505001 -79.1834611247,33.1837832472 -80.3312068927,32.4863955523 -81.3333658716,31.5443965045 -81.5223283116,30.8544375446 -80.7382706948,28.3734805139 -80.038238143,26.8111839641 -80.506174341,25.2005068813 -81.086537297,25.1214053193 -81.7184953039,25.9081077932 -82.0570369708,26.8657900841 -82.8355607337,27.886175826 -82.6310929607,28.8729922328 -84.0240372965,30.1065941207 -84.8866268144,29.7300478967 -86.3648169182,30.3807640426 -88.859364444,30.4081077926 -89.479074731,30.0799827927 -89.722238793,29.6398786257 -89.4710344592,29.0844900428 -90.2620821891,29.0317272872 -91.3279923739,29.2948672328 -91.8475236238,29.8312441857 -92.2764931898,29.5338364148 -93.1995930067,29.7728111657 -94.8888240796,29.3759626098 -95.6019181546,28.7638613729 -96.4448136626,28.5973574669 -97.5502010326,27.0091820111 -97.139271614,25.965806382 -98.22265621,26.075412089 -99.1715476129,26.5658300599 -99.4616351591,27.0568388944 -99.507203125,27.573770244 -100.284339153,28.296516825 -101.0390261447,29.4604523152 -101.303668774,29.6314105479 -102.321010702,29.8939387 -103.147988648,28.985105286 -104.530824138,29.667905986 -105.00849524,30.676991679 -106.51718868,31.773823954 -108.215121217,31.777751364 -108.214811158,31.327442932 -111.067117676,31.333644104 -114.724284628,32.712836405 -117.125121489,32.53166949 -118.0905362668,33.7309771841 -119.2963627273,34.2760359137 -120.4726814864,34.450272949 -120.6448869012,35.1393903439 -121.2883128551,35.6648294928 -122.4044570306,37.1945259515 -122.6734582432,37.9314261099 -123.726242286,38.9185760621 -123.8540188557,39.8335142449 -124.4092020225,40.4438176408 -124.0621554092,41.4358759616 -124.5477189297,42.8454450292 -124.1510311045,43.881740602 -123.8999963225,46.7474064231 -124.7531550298,48.1694041629 -122.2127986813,47.9868024497 -122.7530123738,48.9925148664 -119.3560433034,48.9925145204 -114.5202661233,48.9925145204 -110.5637117631,48.9926178734 -107.2666261907,48.9926178734 -102.4307456586,48.9926178734 -98.0346057254,48.9926695504 -95.1771057269,48.9926695504 -93.7567789853,48.5165487406 -92.6486037335,48.5362632995 -91.4279288888,48.0364488477 -89.5817526941,47.9963331198</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-163.7565405297,55.0603701549 -163.3694962591,54.764553098 -164.958241376,54.5851504291 -163.7565405297,55.0603701549</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-133.5296027453,56.5924441619 -132.402257715,56.1500479092 -131.5600134909,55.5386335126 -131.6732657991,55.1973876063 -132.9431758368,55.8414102822 -133.5296027453,56.5924441619</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-135.6667231565,57.3591832802 -134.5484523975,57.1150368445 -133.5562684247,56.0368930717 -135.6667231565,57.3591832802</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-153.0127661152,57.9291038774 -152.9733780947,57.5178896856 -154.1226293973,56.741196977 -154.7268774433,57.4285342166 -153.0127661152,57.9291038774</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-135.7149959376,58.2297223672 -134.8195695055,57.4860700236 -136.4172257548,57.8350283564 -135.7149959376,58.2297223672</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-135.4346551747,58.3343470039 -134.3629026577,57.9925672538 -133.2033914181,56.9737261689 -133.9628610533,57.0181493805 -135.4346551747,58.3343470039</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-166.0936024146,60.4580846858 -165.3115315865,59.8583836225 -166.2072540143,59.7083690523 -167.7545562515,60.4041105373 -166.0936024146,60.4580846858</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-171.6725968281,63.7963320632 -168.5320194101,63.2884345258 -168.5210561798,62.6055436895 -170.7924027833,63.1874484376 -171.6725968281,63.7963320632</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-141.0055639467,69.6509463146 -141.0042309407,66.8811383701 -141.0022930822,62.6535928011 -141.0011562046,60.3210736778 -139.1821457895,60.073388538 -137.4231058744,58.9077232558 -135.4827591939,59.7924754522 -133.392240804,58.4038780411 -131.5858911152,56.5950478831 -130.0196184876,55.9079518201 -129.9579158627,55.2735049208 -130.9598045864,55.282731628 -131.351934377,55.8772761664 -132.2664384531,56.4495246709 -134.241607266,58.2143008172 -135.7943763605,58.6833010133 -136.8652801472,58.3675750857 -138.2879126019,59.0807558957 -140.3227433296,59.7012392933 -142.7984920263,60.112372105 -143.9186092141,59.9970156601 -147.0472306308,61.0098330424 -148.3747045887,60.7796084335 -148.4353735358,59.9592959341 -149.3889054365,59.9975039411 -151.1616105151,59.2077090206 -151.8828833001,59.7865257512 -151.5667618794,60.9945335634 -153.0552872718,59.7101504263 -154.145253092,59.3811709345 -153.2891333009,58.8441429398 -154.1657202155,58.2167829142 -156.0204565438,57.5768089556 -156.5497941104,56.9828555059 -158.4310196965,56.4380557012 -158.712025556,55.9540469124 -159.8303930688,55.8527285535 -162.2020971701,55.0398623429 -163.3345434598,55.1195335669 -161.8262833673,55.8798688525 -160.5799047875,55.9897321344 -157.7045792653,57.6376406615 -157.0844620758,58.8866640988 -158.1536759439,58.6139997109 -159.940193759,58.8568777615 -161.3638876679,58.6596473379 -162.5258276326,59.9975039411 -163.6149389606,59.8008486682 -165.4312231388,60.5530459337 -164.6691381775,60.8257510115 -166.1999405847,61.5945498389 -166.3717023081,63.0952254933 -164.145375152,63.2621523766 -163.3505346578,63.0308291348 -160.7915746972,63.7465273762 -161.1825659043,64.9395205391 -163.1349991738,64.4125430006 -166.1896866723,64.5851911125 -168.0810033999,65.5914980775 -164.7180883595,66.5563418265 -163.6804907053,66.078599314 -162.179432763,66.075913767 -161.9335596418,66.7504983474 -163.6883032023,67.1032168259 -164.6994846926,67.7895946692 -166.5481664778,68.3588320583 -166.236765109,68.8748232687 -164.3464249407,68.9293886986 -161.9057104183,70.3206240486 -158.043039519,70.8368593988 -156.8172094395,71.30634182 -151.979685032,70.4487164964 -149.488514786,70.5230166263 -144.5901586707,69.9828148041 -143.3002823688,70.1166445559 -141.0055639467,69.6509463146</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>US</ogr:ISO2>
      <ogr:ISO3>USA</ogr:ISO3>
      <ogr:ISONUM>840</ogr:ISONUM>
      <ogr:NAMEen>United States of America</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.192">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>60.0574978679,44.8477769646 61.036304972,44.382821758 62.026115357,43.480628765 63.8668029342,43.7543168338 64.956530803,43.697359721 65.795239298,42.877203065 66.017241251,41.99761851 66.504136597,41.993484395 66.688208049,41.199191793 67.937434123,41.200380351 68.593001343,40.599486796 69.031579224,41.366985168 70.947793009,42.248145854 70.169287557,41.578341777 71.180130249,41.108137919 71.753170207,41.447290344 72.165134725,40.99935903 73.143291994,40.833852782 71.673071736,40.147886455 70.958955119,40.238371888 70.353824097,40.456136373 70.445704793,41.025920716 69.435843953,40.802678529 68.517450399,39.54843984 67.350079794,39.219829407 68.085642131,38.993770854 68.360664103,38.174053447 67.780544475,37.188868103 66.51958785,37.3641804 66.554159384,38.026853129 65.604139852,38.237408753 64.120612834,38.961679789 62.452807658,40.009238586 61.877907349,41.124984436 60.094243612,41.389516093 60.028201131,42.199518332 58.612266887,42.780852356 57.6438448365,42.1517623718 57.3784177926,42.1809383742 57.0678011871,41.9264799805 57.010194132,41.254123841 55.978422486,41.321716614 55.978422486,44.996221008 58.5908979437,45.5445630245 58.7425749644,45.4725188329 59.1469282788,45.280348556 59.4439560554,45.1392957925 59.1932447906,44.7390456402 59.3646445595,44.2712917219 59.9132594456,44.2253802383 60.0574978679,44.8477769646</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>UZ</ogr:ISO2>
      <ogr:ISO3>UZB</ogr:ISO3>
      <ogr:ISONUM>860</ogr:ISONUM>
      <ogr:NAMEen>Uzbekistan</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.193">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-60.020985481,8.558010158 -59.815594849,8.287763977 -60.503278972,7.820867412 -60.292335775,7.105252177 -61.129829875,6.715844421 -61.379607911,5.905299581 -60.739853679,5.202138367 -60.612626303,4.900580546 -61.567270875,4.248527324 -62.76621578,4.020711772 -62.931011923,3.563762919 -63.42540035,3.968363546 -64.58967037,4.118871155 -64.202975627,3.594717102 -64.047972169,2.47132314 -63.384834351,2.420576884 -64.080864218,1.647394104 -66.156344767,0.733031311 -66.875060588,1.222510478 -67.197624878,2.402025045 -67.838619345,2.886129863 -67.304646769,3.425709331 -67.865077677,4.512077128 -67.573984335,6.266233622 -69.443637655,6.122237244 -70.096621054,6.94443512 -72.080996053,7.066598206 -72.451309367,7.440218811 -72.386765503,8.338613587 -73.009724895,9.295376892 -72.907560588,10.452463888 -71.971080282,11.661924948 -71.3275065336,11.8499976907 -71.960519986,11.591253973 -71.6067718311,10.7147395761 -72.124379036,9.826076565 -71.514800585,9.048976955 -71.041859504,9.760891018 -71.5165013838,10.809230861 -70.0887373652,11.457750066 -69.9059043713,11.6450175023 -70.2881459923,11.7837194357 -70.3553734606,12.0212045797 -70.1107759561,12.1529377554 -69.7380336194,12.0166749572 -69.7087029495,11.5051125359 -68.863189257,11.452866929 -67.941232877,10.466457424 -66.251779752,10.64858633 -65.827504036,10.23444245 -64.748117642,10.106878973 -64.131214973,10.619696356 -62.719634569,10.759995835 -62.3122743483,10.4480402473 -62.6153068742,9.743181367 -61.636734699,9.898770728 -60.783802864,9.338609117 -61.0497022505,8.5726326047 -60.020985481,8.558010158</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>VE</ogr:ISO2>
      <ogr:ISO3>VEN</ogr:ISO3>
      <ogr:ISONUM>862</ogr:ISONUM>
      <ogr:NAMEen>Venezuela</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.194">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>107.99122155,21.485663153 106.785411004,21.013373114 106.569614893,20.231993895 106.025157097,19.999172268 105.614268425,18.998602606 106.434825066,18.123521226 106.634613477,17.470404364 108.772959832,15.3867862 109.4362521656,14.102754545 109.465017123,12.913316148 109.2934091215,12.3091270009 109.018077019,11.355902411 108.2254648771,10.7116009877 107.271983269,10.378485419 106.8888270153,10.3504578895 106.484873894,9.54710521 104.752207879,8.590765692 104.892789234,9.85109514 104.451345248,10.419663804 105.0290719,10.914089457 105.752903687,11.015607808 106.015419962,11.770497131 106.435032593,11.677272848 107.514294882,12.343847148 107.5203927,14.704581605 107.657593628,15.28242747 107.298959188,16.064188538 105.735282024,17.664039205 105.451423381,18.192714946 103.848420451,19.299908346 104.956879924,20.091797994 104.056676473,20.958825175 103.115286906,20.868391419 102.974106893,21.575325012 102.118655233,22.397548726 102.44271814,22.765174866 103.9727918576,22.8292514013 105.312155396,23.365810039 105.853879435,22.904649556 106.74664148,22.744349263 106.648197877,21.995506083 107.99122155,21.485663153</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>VN</ogr:ISO2>
      <ogr:ISO3>VNM</ogr:ISO3>
      <ogr:ISONUM>704</ogr:ISONUM>
      <ogr:NAMEen>Vietnam</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.195">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>166.9507029374,-15.0235336548 167.4236301561,-15.752110662 167.7984221323,-16.2041131029 167.2362613373,-16.1510339006 166.9696351784,-15.6936517802 166.5936558487,-15.496426848 166.4188973221,-14.8723151819 166.9507029374,-15.0235336548</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>VU</ogr:ISO2>
      <ogr:ISO3>VUT</ogr:ISO3>
      <ogr:ISONUM>548</ogr:ISONUM>
      <ogr:NAMEen>Vanuatu</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.196">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>53.090342644,16.642401434 52.292735222,16.263820705 52.228363477,15.616115627 49.578135613,14.737290757 48.681488477,14.043605861 48.016856316,14.057277736 46.700694207,13.430324611 45.665782097,13.341986395 44.881358269,12.729885158 43.946299675,12.598049221 43.24887129,13.212713934 42.699229363,15.717433986 42.789480014,16.370957749 43.165044393,17.325920308 45.165387411,17.428394674 47.427574911,17.09182607 48.16194869,18.148919169 49.128814738,18.612095032 51.97861495,18.995637513 53.090342644,16.642401434</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>YE</ogr:ISO2>
      <ogr:ISO3>YEM</ogr:ISO3>
      <ogr:ISONUM>887</ogr:ISONUM>
      <ogr:NAMEen>Yemen</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.197">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>31.288921753,-22.397339783 31.986553589,-24.423107605 31.949243204,-25.95810435 31.426897827,-25.743647155 30.8000898689,-26.1715482936 30.7343610625,-26.7092737533 31.157043497,-27.205573426 31.968260132,-27.316264343 32.113884318,-26.840014343 32.893077019,-26.846123956 32.379405144,-28.552829685 31.186859571,-29.560316665 30.392344597,-30.847100519 28.548594597,-32.56243255 27.100922071,-33.525323175 25.679047071,-33.795179946 24.857920769,-34.186944269 22.563975457,-33.997247003 20.913422071,-34.360446873 19.953461134,-34.80868906 18.488780144,-33.862969659 17.843923373,-32.814629816 18.273122592,-32.647556248 18.172862175,-31.663262628 17.281993035,-30.34775156 16.48707116,-28.5729305965 16.892952921,-28.082625834 17.403619425,-28.704293315 19.081656535,-28.959368184 19.98165328,-28.4223467 19.981446574,-24.752493184 20.84144576,-26.131323751 20.690757283,-26.891794128 21.687182251,-26.855207214 22.719367309,-25.984252625 23.006998332,-25.310805359 24.798620239,-25.829223327 25.587254272,-25.619520365 25.868374064,-24.748152364 26.849709513,-24.248131205 27.00417037,-23.645842387 28.338559204,-22.584615173 29.350073689,-22.186706645 31.288921753,-22.397339783</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs><gml:innerBoundaryIs><gml:LinearRing><gml:coordinates>28.758636922,-28.700469258 27.747432495,-28.908621928 27.014867391,-29.62558075 27.743608439,-30.600301615 29.150654337,-29.911144714 29.435908244,-29.342393901 28.758636922,-28.700469258</gml:coordinates></gml:LinearRing></gml:innerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>ZA</ogr:ISO2>
      <ogr:ISO3>ZAF</ogr:ISO3>
      <ogr:ISONUM>710</ogr:ISONUM>
      <ogr:NAMEen>South Africa</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.198">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>31.1666602765,-8.5890077003 32.920863485,-9.407900086 33.674202515,-10.577027689 33.319082072,-10.818149922 33.252729533,-12.139516296 32.80779545,-13.699162699 33.202706747,-14.013872172 30.214465373,-14.981461691 30.396263061,-15.635995381 29.406969442,-15.7142335 28.761274487,-16.531943312 27.9135682357,-16.8636698287 27.0222407437,-17.9580343552 25.259780721,-17.794106547 24.220464314,-17.479500427 23.381652466,-17.641144307 22.108138469,-16.543950297 21.983804972,-16.165885519 21.979877563,-13.001479187 24.000632772,-13.001479187 23.9676076164,-10.8770496782 24.285473266,-11.381216329 25.278797648,-11.199935404 25.351971477,-11.646109721 26.697057333,-12.017456563 27.180128621,-11.569628601 27.638188517,-12.293615417 28.339747762,-12.450505066 29.168947795,-13.433855896 29.79764327,-13.424244079 29.799296915,-12.15408905 29.030351603,-12.376194356 28.35700769,-11.446948751 28.634923543,-10.519460144 28.5160606604,-9.3791892099 28.8001333273,-8.7357104912 28.893485601,-8.481407219 30.5698657966,-8.2217699874 31.1666602765,-8.5890077003</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>ZM</ogr:ISO2>
      <ogr:ISO3>ZMB</ogr:ISO3>
      <ogr:ISONUM>894</ogr:ISONUM>
      <ogr:NAMEen>Zambia</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.199">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>30.396263061,-15.635995381 30.402567587,-16.001244405 31.259982951,-16.023465271 32.968509156,-16.681616312 33.034965047,-18.33288503 32.763353719,-19.46397878 33.00726648,-20.032006124 32.513136434,-20.564583435 32.408543335,-21.290327251 31.288921753,-22.397339783 29.350073689,-22.186706645 29.038723186,-21.797893168 28.032893107,-21.577854919 27.698133179,-20.509082947 26.130270223,-19.501082459 25.259780721,-17.794106547 27.0222407437,-17.9580343552 27.9135682357,-16.8636698287 28.761274487,-16.531943312 29.406969442,-15.7142335 30.396263061,-15.635995381</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>ZW</ogr:ISO2>
      <ogr:ISO3>ZWE</ogr:ISO3>
      <ogr:ISONUM>716</ogr:ISONUM>
      <ogr:NAMEen>Zimbabwe</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.200">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>125.061615431,-9.485772394 124.8711070826,-8.8668875148 125.144297722,-8.631442967 126.9074455555,-8.1189695954 127.7594363482,-8.3011635904 126.5279772605,-8.7658194452 125.061615431,-9.485772394</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>123.6361778499,-9.443525747 123.8793276515,-9.1110718104 124.4749225128,-8.9708519321 124.2663267197,-9.4799588898 123.6361778499,-9.443525747</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>TL</ogr:ISO2>
      <ogr:ISO3>TLS</ogr:ISO3>
      <ogr:ISONUM>626</ogr:ISONUM>
      <ogr:NAMEen>East Timor</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.201">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>53.090342644,16.642401434 51.97861495,18.995637513 54.978380168,19.995421448 55.637564738,21.978969625 55.186842895,22.703576559 55.755697062,24.230330912 55.788666626,24.855202332 56.383311394,24.978216864 57.151540561,23.953558661 58.786143425,23.512111721 59.79175866,22.198065497 58.5185653,20.416815497 58.103526238,20.575140692 57.698903842,19.754380601 57.840098504,19.015326239 56.915049675,18.810288804 56.344899936,17.937811591 55.445160352,17.841009833 55.026866082,17.011135158 54.023448113,16.985337632 53.090342644,16.642401434</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>55.8863373911,25.884154699 56.0805912149,26.1080321476 56.37956648,26.0603791898 56.2790552346,25.6274456978 56.1159005342,25.6215553345 55.8863373911,25.884154699</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>OM</ogr:ISO2>
      <ogr:ISO3>OMN</ogr:ISO3>
      <ogr:ISONUM>512</ogr:ISONUM>
      <ogr:NAMEen>Oman</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.202">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>42.923715454,10.99878713 43.240733269,11.487860419 44.274261915,10.456732489 44.962008688,10.415799432 45.753591342,10.871730861 46.447764519,10.693101304 47.366872592,11.172796942 48.9391119999,11.2491299763 50.26832116,11.589300848 50.797863585,11.989118646 51.292698162,11.833107906 51.176117384,10.562811591 50.840342644,9.456122137 49.842051629,7.962713934 49.036143425,6.144232489 47.948496941,4.4570987 46.027028842,2.438137111 44.550059441,1.559068101 43.46762129,0.620550848 42.08090254,-0.862888279 41.535085483,-1.696302993 40.979751424,-0.870798441 40.965385376,2.814144593 41.885019165,3.977226054 43.96897465,4.953962301 44.941525106,4.911484273 46.423915242,6.496736348 47.979169149,7.996567281 46.979230184,7.996567281 44.023855021,8.985525004 43.419034057,9.41301829 42.647246541,10.632220358 42.923715454,10.99878713</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>SO</ogr:ISO2>
      <ogr:ISO3>SOM</ogr:ISO3>
      <ogr:ISONUM>706</ogr:ISONUM>
      <ogr:NAMEen>Somalia</ogr:NAMEen>
      <ogr:UNRegion>Africa</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.203">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-83.8374484026,46.1487283334 -81.8644401349,45.9159572296 -81.8843968296,45.3902173523 -83.9979469975,46.0680297394 -83.8374484026,46.1487283334</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-64.3375891176,47.0533612591 -63.2801238527,46.5747171192 -61.976958848,46.4546572682 -62.5452368429,45.9718284924 -64.0988149102,46.4168549253 -64.3375891176,47.0533612591</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-60.5011287703,47.001206747 -59.8105363223,46.1698672293 -60.3953751892,45.6425234795 -60.9063971586,45.5247392525 -61.541127142,46.0404726973 -60.5011287703,47.001206747</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-64.1328019467,49.950140665 -61.8826391871,49.3544782303 -62.248199083,49.0679385174 -63.5867814388,49.3899600012 -64.1328019467,49.950140665</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-55.7001072842,51.3169592633 -55.2276376194,50.8595025814 -55.6803575311,50.051275124 -55.6890941794,49.4291445712 -55.0700185603,49.2987226224 -54.5447485635,49.5291201572 -53.4536841107,49.2421735433 -53.9034318315,48.5681826575 -53.2331678458,48.4884582943 -53.2660118378,47.948614837 -52.9746250343,47.6564133254 -52.9412736285,46.7913271901 -53.5546769484,46.6183535572 -54.2600702902,47.140497 -55.2508846302,46.9188499761 -55.950306831,46.9043642991 -55.7556849904,47.5397377308 -59.1116430935,47.5607770589 -59.3988338485,47.8803164468 -58.6853735627,48.6017519935 -57.3924321203,50.458448348 -56.6256565783,50.9652376568 -55.7001072842,51.3169592633</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-81.4342143997,53.3739544333 -80.5115360192,52.7768741291 -81.0650763539,52.6377354792 -82.0626522037,53.0227724998 -81.4342143997,53.3739544333</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-132.6943993822,53.9336698587 -131.8502769678,53.8507755695 -130.913150502,53.1309897129 -130.0779922546,52.4637641273 -131.2577535913,52.87623461 -131.8577850039,53.2020428559 -132.6943993822,53.9336698587</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-81.7353521799,63.0619333839 -82.7618150666,62.2682881353 -83.9069718608,62.4914004243 -82.8138463378,63.0855460465 -81.7353521799,63.0619333839</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-85.4882706856,65.7966168923 -82.0286085892,64.8792341763 -80.1929826032,63.8078066732 -81.0188696472,63.4502627275 -82.4817602715,63.6852073893 -83.0137426929,64.1915550448 -84.0224570852,63.9865028937 -84.9114601432,63.0496690999 -85.6170141774,63.6748721023 -86.6932473038,63.9297099218 -85.953827438,64.4657194831 -85.4882706856,65.7966168923</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-75.4360674678,68.7141818636 -74.9659212501,68.1627121698 -75.0538144338,67.6218668842 -76.131513814,67.6862375168 -77.0343711557,68.1822133526 -77.0362883014,68.8352871818 -76.6274173833,69.1464679276 -75.4360674678,68.7141818636</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-99.030725263,70.1854686382 -95.696354009,69.4938726975 -97.4327640483,68.9187187449 -99.5908097378,69.0148379175 -99.030725263,70.1854686382</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-75.7914962913,44.4965126518 -77.0364127546,43.9710496074 -79.0884250846,43.826516821 -79.7747350469,43.3293358104 -79.0586315217,43.2782003383 -79.0652311503,43.105730209 -78.9269663609,42.9457793529 -81.359149961,42.6493546769 -82.6227079766,42.037960385 -82.6446981164,42.5575330121 -82.4163685665,43.0174198005 -81.7306374893,43.3823213533 -81.2801131927,44.6065817577 -81.607446102,45.2521222883 -80.108691149,44.4752953571 -79.7825356962,44.8211732063 -80.7526126769,45.9268048675 -84.1059436185,46.3463741605 -84.4910523084,46.4576578772 -84.8435381328,47.9170007304 -85.8592415533,47.9849988438 -86.4336931472,48.7529948512 -88.2711140284,48.9896636093 -89.5817526941,47.9963331198 -91.4279288888,48.0364488477 -92.6486037335,48.5362632995 -93.7567789853,48.5165487406 -95.1771057269,48.9926695504 -98.0346057254,48.9926695504 -102.4307456586,48.9926178734 -107.2666261907,48.9926178734 -110.5637117631,48.9926178734 -114.5202661233,48.9925145204 -119.3560433034,48.9925145204 -122.7530123738,48.9925148664 -122.9142665798,48.9921467625 -125.3627117424,50.5455707193 -126.229501784,50.4947689653 -127.7974031898,51.2405177179 -127.8607478972,52.2160098052 -128.8754777133,53.3062197657 -130.4582413842,54.3486188532 -129.9579158627,55.2735049208 -130.0196184876,55.9079518201 -131.5858911152,56.5950478831 -133.392240804,58.4038780411 -135.4827591939,59.7924754522 -137.4231058744,58.9077232558 -139.1821457895,60.073388538 -141.0011562046,60.3210736778 -141.0022930822,62.6535928011 -141.0042309407,66.8811383701 -141.0055639467,69.6509463146 -135.8684789906,68.9069277616 -132.9668660241,70.1237317783 -127.8350037865,70.2373907813 -125.9386287339,69.4140078389 -125.0184121252,70.05145901 -124.1685501437,69.4541553661 -122.9509985262,69.8385683853 -121.4278458572,69.7668317314 -118.0408829709,69.0246035425 -115.0349829077,68.8751487897 -113.9053849273,68.3998069933 -115.5338028965,67.9343935829 -113.8587540698,67.6962344032 -109.0745743839,67.7219912391 -107.5635473685,66.5945498344 -108.2808325205,68.621568061 -106.2721248388,68.9069277616 -104.4838761434,68.0339215778 -102.3058976289,67.7232526321 -98.6982384497,67.7623139262 -98.7180883844,68.3676211213 -97.0195879931,68.3249447779 -96.4595841559,67.4747988564 -93.5462133865,68.5642763941 -94.3221736716,69.4529889579 -96.3210157906,69.9515319083 -96.8774714643,71.0147554146 -94.5486954757,72.0021425998 -92.9906306993,71.3571230699 -91.9429419007,70.02411526 -92.2248055849,69.481997505 -90.4411515385,68.8701032167 -88.9419653416,69.2335879172 -88.0226131288,68.8086611598 -88.2486059691,67.7759870071 -86.5019425584,67.3793805625 -85.3201798604,69.8469912363 -82.6164445101,69.6467145436 -81.2665096162,68.638739285 -82.4700415169,68.4848086212 -81.2379451647,67.4605166305 -81.527414566,66.996039092 -83.6907853349,66.1992047829 -85.8566619811,66.1628297099 -87.3807674303,65.3296979477 -89.6879777147,65.9468447571 -89.0398657367,65.3281924137 -86.9382218577,65.1419538069 -87.9816788891,64.1915143548 -89.7863663884,64.2502301748 -90.2593888498,63.6078555013 -93.2171932104,63.9109560871 -90.7847387848,63.3976504235 -90.6436255041,63.0689150718 -92.4539282377,62.793931348 -93.9849747882,61.457993849 -94.8213598799,59.9481061551 -94.4368790867,58.7238223019 -93.1557511571,58.7443708039 -92.4235734229,57.3544375367 -92.704904804,56.9553896859 -91.0311173693,57.2646344767 -88.879221211,56.859930701 -87.5790096227,56.0462099984 -84.6131486216,55.2451846078 -82.2522680882,55.1179059629 -82.3011775937,52.9675967188 -80.3851212794,51.3413760165 -79.7471411365,51.1955019926 -78.4995825426,52.3558210031 -78.6829366083,52.9802745664 -79.3148411557,54.1902990847 -79.7656144429,54.6527773821 -78.3922420472,55.0275332409 -76.6586808494,56.0729840874 -76.5893449121,57.2713076537 -77.0793351458,57.9614932003 -78.5733130102,58.6754824579 -77.2363175671,60.0049502301 -78.1655167855,60.8683535505 -77.5454809784,61.485337599 -78.1548966678,62.2973086274 -77.4908341679,62.5883242522 -74.770334494,62.1575381195 -73.6707251193,62.4821230803 -71.3714494045,61.1495221703 -69.7352185854,60.7998721045 -69.7749638701,60.3083858842 -69.5824833445,59.4926353628 -68.4826207125,58.550556111 -67.0296484669,58.1842584368 -65.7514984036,58.6071549862 -64.0716187263,60.4538003248 -62.5866674811,58.5925255409 -61.1787704267,56.9274622868 -60.5208600316,55.8003838507 -58.9197892528,54.855454791 -57.3531795522,54.5667585021 -58.8531388618,53.9419619524 -57.4107462742,54.0800505728 -56.6394587583,53.4678439134 -55.8120825475,53.3300641667 -55.6848039015,52.1116803782 -56.9665421822,51.4252383205 -58.4536841098,51.3165957425 -59.8272599555,50.3280703529 -61.8631893171,50.2301699619 -66.4130753842,50.2642275789 -67.3763322201,49.3392194413 -69.0695695238,48.7562116295 -69.0615937539,48.4992360313 -66.7442315486,49.1267269608 -65.9487443479,49.4123602068 -65.2744479584,49.5050651765 -64.5574735197,49.2473784876 -64.2713299764,48.7835369535 -64.5191238422,48.3579288342 -65.1055472033,47.9302464096 -65.2360704536,47.0228823799 -64.5140275326,46.2394066173 -62.4704484309,45.6144879975 -61.9167399804,45.915461607 -60.9986466741,45.3331566176 -63.1706821992,44.5781348121 -64.3055314385,44.5659853938 -65.4748429623,43.4709333101 -66.0281469983,43.702297243 -65.9987687433,44.5796572688 -64.3446261883,45.3165674644 -64.7562557225,45.6277936615 -65.9094132743,45.2102725026 -67.1760148371,45.1786562916 -67.4409387966,45.604585751 -67.8108158023,45.7624138603 -67.805184752,47.035631383 -69.2676277858,47.4398444359 -70.0077634866,46.7040753931 -70.4073514996,45.7315249384 -71.5148352757,45.0150542586 -74.7129614499,44.9992536226 -75.7914962913,44.4965126518</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-114.1966446782,73.3080508002 -110.57657773,72.9346430434 -106.8336968231,73.3039662458 -106.5995987825,73.7106386903 -104.86895783,73.1314786228 -104.6016724534,72.2076038176 -103.5377091463,70.5995140222 -102.1794327807,69.9017601162 -101.8112687208,69.0062523055 -103.3530981475,68.7902285428 -106.4120987961,69.1880556902 -110.9800919593,68.5484072541 -113.3504939761,68.591538764 -114.3925709949,69.2271652184 -115.9748429322,69.3001976171 -117.4420467056,69.9894066011 -114.1847224874,70.3157412356 -111.5486547809,70.2699241787 -113.4907120698,70.681830102 -117.5854386308,70.6063499591 -118.3864640191,71.0222028235 -116.1034236552,71.3766543199 -119.0508927277,71.6267763894 -119.1307694617,71.9914140126 -116.7897335844,72.6620514015 -114.1966446782,73.3080508002</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-81.0629108826,73.8466282367 -78.3141473641,73.8616129847 -76.6519538394,73.0530851504 -78.0690929199,73.1719900091 -80.1034832709,72.864305097 -81.0629108826,73.8466282367</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-86.5584204104,73.85529201 -84.9519750991,73.6676699404 -86.6985571313,72.8161074422 -85.9874975637,72.0314394747 -84.3606880345,73.309100602 -81.5283911172,73.7162132343 -80.4828588946,72.1807314664 -77.6010229581,72.7558047083 -75.1983536892,72.4976259978 -73.6397204676,71.825782576 -72.4726049944,71.6472842024 -68.3622534352,70.5842959232 -67.1154679559,69.7286644135 -66.6687719926,69.1845563413 -65.9141736285,68.1926204813 -64.0762833881,67.6178245723 -61.8921142619,66.8782011545 -62.5941870359,65.6640078434 -64.0446058648,65.2417942938 -65.3931372306,65.9822451471 -66.8615617087,66.5427106415 -67.273142112,65.6452090154 -64.9028255375,64.1400549773 -64.6277563722,62.9110781579 -66.4184057855,63.0075137048 -68.1697598947,63.3292600115 -64.5364072009,61.7419432723 -65.3410721413,61.5183741269 -68.9827907939,62.411763224 -71.835183043,63.4839477052 -73.2014276296,64.2157582019 -74.8117179211,64.2673229561 -76.0792849983,64.2005753129 -78.0181779166,64.4427757476 -78.4823712515,65.2330888703 -77.4356583841,65.4596214496 -75.2154435421,65.2541364238 -73.9614237553,65.4021028274 -74.4721574088,66.1485862929 -72.3509008979,67.1194521778 -72.9946183446,68.2359072545 -75.6874487461,69.2870547141 -79.2259985703,70.3773684608 -81.7624406038,70.1228701419 -82.1435441201,69.8248965103 -86.2697241305,70.1134707279 -88.6940812246,70.4650332274 -90.1046850616,71.9163271709 -89.0512182616,73.2516950063 -86.5584204104,73.85529201</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-99.8309539723,73.8969179869 -97.2603566442,73.8612327659 -97.5092116021,73.1570546807 -96.6161102283,72.7520205283 -96.5620426078,71.9131865031 -98.7178761823,71.2716738511 -101.8611818283,72.3944743939 -100.0497039755,72.9636904499 -101.6256317076,73.4913597198 -99.8309539723,73.8969179869</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-92.7470597284,74.0851097184 -90.1957088188,73.9022483909 -90.8879356514,72.8469189204 -92.758727455,72.4767296357 -93.1287897391,71.6155209577 -94.626793081,72.2021575326 -95.248646641,74.0099144056 -92.7470597284,74.0851097184</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-121.5807999402,74.5558535323 -116.8670141389,74.0875511244 -115.3205460437,73.4806582218 -120.2612198737,72.2418480033 -120.6352433132,71.4914411037 -123.0999243032,71.0846214424 -125.7904353666,71.9491640849 -123.7737524168,73.7656110212 -124.7556860071,74.3485781418 -121.5807999402,74.5558535323</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-94.393910307,75.6042340635 -93.0969134471,74.7065302908 -94.3868334137,74.6297651701 -96.1769307388,75.1391269703 -97.0387644419,76.1440117963 -94.393910307,75.6042340635</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-98.4080297641,76.6676699322 -97.3775121923,75.6798362763 -98.0350235879,75.0262718251 -100.3301896013,75.0140647941 -102.6334122542,75.4981142718 -103.2745605378,76.4588076279 -101.3409328228,76.8137098827 -98.4080297641,76.6676699322</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-108.6673884784,76.8248558037 -105.3904923292,75.6596539853 -106.0089005349,75.056626643 -108.8242081497,75.071519221 -113.0237931111,74.3959414227 -114.4281922967,74.509951478 -117.5100805385,75.2011172026 -118.0391242539,75.7511890102 -115.0016400844,76.4190512144 -112.9942113945,76.2732607535 -111.2508438874,75.5218772927 -109.9318349624,75.8041122594 -110.3836156934,76.3005231234 -108.6673884784,76.8248558037</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-95.2387589308,77.013657887 -91.4410701339,76.6936709091 -88.4077364183,75.8037272884 -83.7362361603,75.8266054818 -79.6498103839,75.4697939589 -79.3951717141,74.8762881015 -81.7886857108,74.4584007325 -89.9486385048,74.5327822433 -91.9195733294,74.9535452675 -92.9864355511,75.8436574926 -95.7215758664,76.5023996016 -95.2387589308,77.013657887</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-116.1255997298,77.4723981193 -115.8928116501,76.6984316511 -119.8629451157,75.8591168747 -122.4258927041,75.9328066535 -119.2897029185,77.28880437 -116.1255997298,77.4723981193</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-109.6036677648,78.073919927 -109.142384057,77.4846840335 -112.1092423126,77.3257509849 -113.2412816948,77.9049746156 -109.6036677648,78.073919927</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-96.2252003219,78.6366425017 -94.2526260994,77.557016316 -97.7527345485,77.852291952 -98.7897621418,78.6861283721 -96.2252003219,78.6366425017</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-111.3647008882,79.2631571086 -109.8986876154,78.547517753 -112.9543556139,78.2554759361 -111.3647008882,79.2631571086</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-103.6569717946,79.3412945961 -99.5579320921,78.5987001977 -99.0172419944,77.8937848367 -103.9465225858,78.2428245482 -103.6569717946,79.3412945961</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-94.7475303726,82.1202372037 -87.8942830521,79.8437564593 -89.4551895926,78.1644960986 -92.0043839257,78.2128766324 -96.6161189317,79.8849957641 -97.2296384977,81.5599890546 -94.7475303726,82.1202372037</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-69.6875300582,83.1165224297 -64.6966853445,82.9097760132 -61.3124080157,82.1972109168 -64.6921280714,81.3908144389 -73.1738582197,79.53880436 -75.170803849,79.4078083091 -75.1076961163,78.3754742877 -78.1569486444,77.5478868901 -77.7707820596,76.6642926532 -84.6612690294,76.8180292695 -85.4162920179,76.3204113462 -88.9106339395,76.410467785 -89.9658817652,77.1739652645 -86.9129125826,77.2670351641 -87.4878637487,78.1271832727 -86.6098526767,78.8092714867 -85.9559489766,79.3677203763 -87.7429096027,80.5289123212 -90.8138278667,81.7218490609 -82.7115779012,82.381455706 -81.5761612285,82.7912457406 -69.6875300582,83.1165224297</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>-127.8094230492,50.4355984753 -127.3951243651,50.6815898071 -125.9789097509,50.1533643736 -124.979035702,50.0054242048 -123.5126939215,49.0893168626 -123.0688925834,48.3696402954 -124.2476657697,48.4667569292 -125.4606906264,48.9391293918 -126.7321341943,49.7177842145 -127.8094230492,50.4355984753</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CA</ogr:ISO2>
      <ogr:ISO3>CAN</ogr:ISO3>
      <ogr:ISONUM>124</ogr:ISONUM>
      <ogr:NAMEen>Canada</ogr:NAMEen>
      <ogr:UNRegion>America</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.204">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>114.082367384,22.529364325 114.229828321,22.555812893 114.4435103707,22.4145729779 114.3669456223,22.2012808964 114.1122597996,22.1197769759 113.8940024942,22.2035183029 113.9182854933,22.3685316062 114.082367384,22.529364325</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>HK</ogr:ISO2>
      <ogr:ISO3>HKG</ogr:ISO3>
      <ogr:ISONUM>344</ogr:ISONUM>
      <ogr:NAMEen>Hong Kong</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.205">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>163.5240971628,-20.0348134713 164.0626980791,-20.0465019718 165.3329029057,-20.7605165583 165.7242265464,-21.2885639979 167.1982054025,-22.1771310839 167.0274739618,-22.5429591083 164.7832659829,-21.4001874788 163.5240971628,-20.0348134713</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>NC</ogr:ISO2>
      <ogr:ISO3>NCL</ogr:ISO3>
      <ogr:ISONUM>540</ogr:ISONUM>
      <ogr:NAMEen>New Caledonia</ogr:NAMEen>
      <ogr:UNRegion>Oceania</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.206">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>113.5772768352,21.9988542662 113.6359924872,22.173592026 113.7277723573,22.0517442071 113.5772768352,21.9988542662</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>MO</ogr:ISO2>
      <ogr:ISO3>MAC</ogr:ISO3>
      <ogr:ISONUM>446</ogr:ISONUM>
      <ogr:NAMEen>Macau</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:world fid="world.207">
      <ogr:geometryProperty><gml:MultiPolygon srsName="EPSG:4326"><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>113.6359924872,22.173592026 113.5772768352,21.9988542662 112.9801503679,21.7888173936 111.8118584713,21.4985833368 110.5524725459,21.1724120316 110.5341903,20.478257554 109.914561394,20.248480536 109.741465691,21.474025783 108.559825066,21.698553778 107.99122155,21.485663153 106.648197877,21.995506083 106.74664148,22.744349263 105.853879435,22.904649556 105.312155396,23.365810039 103.9727918576,22.8292514013 102.44271814,22.765174866 102.118655233,22.397548726 101.654549195,22.446124573 101.7179045,21.134473369 101.159023885,21.552690735 100.187145223,21.427892151 99.94240564,22.045528869 99.144469849,22.153532613 99.493079061,23.057379252 98.859009237,23.179387309 98.585227499,24.075715027 97.637068319,23.863557435 97.53609257,24.745028178 98.692404419,25.878989971 98.679278605,27.577335918 97.546221151,28.538465881 97.323495728,28.217477723 96.14196578,29.368466899 95.281553182,29.052672221 94.630430135,29.319451803 93.446213013,28.67189443 92.628485148,27.915764873 91.632887004,27.759443665 90.2255906943,28.3583989308 89.561488891,28.134640401 88.89233077,27.315543111 88.610487508,28.10583079 88.118217814,27.860884501 85.980260458,27.885172424 85.080212036,28.318789368 84.099134969,29.247001445 83.517051636,29.191707662 82.088766724,30.330087789 80.996016887,30.1969693 79.577808879,30.938371074 78.7887122705,32.2487005277 79.476419719,32.6454245 78.781371704,33.552785136 78.922138306,34.372295837 78.273185669,34.658867493 77.800346314,35.495405579 77.2516900425,35.424740888 76.777350741,35.646111714 76.166027466,35.806239319 75.976581665,36.462633362 74.542353963,37.021669006 74.892306763,37.231113587 74.776344849,38.510673727 73.797386515,38.602838644 73.632642049,39.44834259 74.835359335,40.511636861 75.681819296,40.291701966 76.766817668,40.944685364 78.074954875,41.039511617 78.359898723,41.377527161 80.21032841,42.189518941 80.787864217,43.128040467 80.061706991,45.018958639 82.291493368,45.533190817 83.150355672,47.211537985 84.767104533,46.818073629 85.498636109,47.051831971 85.783683309,48.40758901 87.323796021,49.085273743 87.816324097,49.165837301 87.942828004,48.599489441 89.045551392,47.992988994 90.344800252,47.658642477 91.047496379,46.566409404 90.873243449,45.186183574 93.525277955,44.951262513 95.379428345,44.287117005 96.350635214,42.740906474 99.474475545,42.564198914 101.637599325,42.5154422 102.034164266,42.184609681 105.014809204,41.596144308 106.767828818,42.286618958 109.485130656,42.449296367 110.40672815,42.768605041 111.933353313,43.696636251 111.396435181,44.346596578 112.011488079,45.087481588 113.635058228,44.746262105 114.533711385,45.385499573 115.637830038,45.44435903 116.603559205,46.309319153 118.238291464,46.715392558 119.680115601,46.591627503 119.699959351,47.159525655 118.542252239,47.96624644 117.7416300051,47.9775440208 117.5094003564,47.776900575 115.852700643,47.705564678 115.514530071,48.12210256 116.684277792,49.823264873 117.758837525,49.512741191 119.316210165,50.092654114 119.141233765,50.37661611 120.779169963,52.117595114 120.03296228,52.760656637 120.874254598,53.280159811 122.581510365,53.6845503734 124.5287569115,53.7331411849 125.9497198547,53.1685824973 126.531170288,52.152657572 126.931765992,51.063783468 128.092470338,49.54157664 129.502410116,49.41078359 130.822122843,48.333769226 131.023350871,47.682284445 132.524654582,47.707528381 134.386349732,48.381337383 134.772579387,47.710732321 134.154115845,47.257891744 133.90245162,46.258986308 133.2575604354,45.5403816751 131.9919443364,45.2293538981 130.933433879,44.841708476 131.28090621,43.380221456 130.530771119,42.530480042 129.851742798,42.961900736 129.703328085,42.442371724 128.034592733,41.993742778 127.8440018872,41.4335661479 126.617883342,41.66593333 126.015336142,40.909131979 124.36996504,40.098293361 122.8631974362,39.5740093937 121.8551405562,38.8697883979 121.153086785,38.727606512 121.779795769,39.371486721 121.223399285,39.528631903 122.301849806,40.502346096 121.175791863,40.922308661 120.436045769,40.194484768 119.535592388,39.890825588 119.015635613,39.189764716 117.757334832,39.114447333 117.543549024,38.62132396 118.08480879,38.138739325 118.840098504,38.15257396 118.972422722,37.280666408 119.441172722,37.120550848 120.738047722,37.833970445 121.4265765028,37.503542026 122.1954601953,37.5400903409 122.688243035,37.409816799 121.032481316,36.589504299 119.647959832,35.583929755 119.192230665,34.718207098 120.257090691,34.311835028 121.5088334231,32.7891320068 121.9373988943,31.3883430972 120.3633424751,31.1979861531 121.977382923,30.914923436 120.684941141,30.271780919 121.377384147,30.325063579 121.98303901,29.823175763 121.525889519,29.277777411 121.626522728,28.5441094814 121.1771051866,28.1271249629 120.237396681,26.927232164 119.8443714354,26.5186716905 119.628021681,25.461371161 119.2241029997,25.2195132691 118.646576368,24.568426825 117.1185500843,23.5674845525 116.494687913,22.939352413 114.784759962,22.815863348 114.229828321,22.555812893 114.082367384,22.529364325 113.35043379,22.889715887 113.587654701,22.237882255 113.6359924872,22.173592026</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>110.685069207,20.153306382 111.2416479439,19.9315364706 110.7586603057,19.3306129229 110.6227926064,18.6869924383 109.6560017213,18.1084737976 108.694997592,18.504828192 108.626963738,19.274969794 109.3709232087,19.7901186756 110.0563213554,19.9946305723 110.685069207,20.153306382</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon></ogr:geometryProperty>
      <ogr:ISO2>CN</ogr:ISO2>
      <ogr:ISO3>CHN</ogr:ISO3>
      <ogr:ISONUM>156</ogr:ISONUM>
      <ogr:NAMEen>China</ogr:NAMEen>
      <ogr:UNRegion>Asia</ogr:UNRegion>
    </ogr:world>
  </gml:featureMember>
</ogr:FeatureCollection>
